from datetime import timedelta, date, datetime
from flask import Flask, render_template, request, jsonify, g
import pymysql
from flask_cors import CORS 
import bcrypt
import json
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt

app = Flask(__name__)
CORS(app, 
     origins=["http://localhost:5000", "http://127.0.0.1:5000"],
     supports_credentials=True,
     allow_headers=["Content-Type", "Authorization"]
)
app.config["JWT_SECRET_KEY"] = "ilder123"
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(minutes=60)
app.config["JWT_TOKEN_LOCATION"] = ["headers"]
app.config["JWT_HEADER_NAME"] = "Authorization"
app.config["JWT_HEADER_TYPE"] = "Bearer"
jwt = JWTManager(app)

from dbutils.pooled_db import PooledDB

pool = PooledDB(
    creator=pymysql,
    maxconnections=10,
    mincached=3,
    blocking=True,
    host='localhost',
    user='root',
    password='sbarman',
    db='sistema_solicitudes',
    cursorclass=pymysql.cursors.DictCursor
)

def get_db():
    if 'db' not in g:
        g.db = pool.connection()
    return g.db

@app.teardown_appcontext
def close_db(error):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def serializar_registro(row):
    result = {}
    for k, v in row.items():
        if isinstance(v, (date, datetime)):
            result[k] = v.isoformat()
        else:
            result[k] = v
    return result

#Auditoría
def registrar_auditoria(usuario, accion, id_solicitud=None, detalle=None):
    try:
        cursor = get_db().cursor()
        cursor.execute(
            "INSERT INTO auditoria (usuario, accion, id_solicitud, detalle) VALUES (%s, %s, %s, %s)",
            (usuario, accion, id_solicitud, detalle)
        )
        get_db().commit()
        cursor.close()
    except Exception as e:
        print("Error auditoria:", e)

@app.route("/api/auditoria", methods=["GET"])
@jwt_required()
def obtener_auditoria():
    if not es_admin():
        return jsonify({"error": "No autorizado"}), 403
    cursor = get_db().cursor()
    cursor.execute("SELECT * FROM auditoria ORDER BY fecha DESC LIMIT 200")
    registros = cursor.fetchall()
    cursor.close()
    return jsonify({"registros": [serializar_registro(r) for r in registros]}), 200

#Es administrador
def es_admin():
    claims = get_jwt()
    return int(claims.get("tipo", 0)) == 1

# ─── Páginas HTML ───────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/login")
def login_page():
    return render_template("login.html")

@app.route("/register", methods=["GET"])
def register_page():
    return render_template("login.html")  # o simplemente elimínala

@app.route("/dashboard")
def dashboard_page():
    return render_template("index.html")

# ─── Solicitudes ─────────────────────────────────────────────────────────────

@app.route("/api/solicitudes", methods=["GET"])
@jwt_required()
def obtener_solicitudes():
    cursor = get_db().cursor()
    cursor.execute("SELECT * FROM solicitudes ORDER BY fecha_reporte DESC")
    registros = cursor.fetchall()
    cursor.close()
    return jsonify({"registros": [serializar_registro(r) for r in registros]}), 200

@app.route("/api/solicitudes", methods=["POST"])
@jwt_required()
def agregar_solicitud():
    claims = get_jwt()
    nombre = claims.get("nombre")
    try:
        cursor = get_db().cursor()
        data = request.get_json(force=True)

        cliente         = data.get("cliente")
        persona_reporta = data.get("persona_reporta")
        tipo_soporte    = data.get("tipo_soporte")
        descripcion     = data.get("descripcion")
        prioridad       = data.get("prioridad")
        fecha_reporte   = data.get("fecha_reporte")
        estado          = data.get("estado")

        cursor.execute(
            """INSERT INTO solicitudes 
               (cliente, persona_reporta, tipo_soporte, descripcion, prioridad, fecha_reporte, estado) 
               VALUES (%s, %s, %s, %s, %s, %s, %s)""",
            (cliente, persona_reporta, tipo_soporte, descripcion, prioridad, fecha_reporte, estado)
        )
        get_db().commit()
        claims = get_jwt() if request.headers.get("Authorization") else {}
        registrar_auditoria(nombre or "Sistema", "crear_solicitud", cursor.lastrowid)
        cursor.close()
        return jsonify({"message": "Solicitud agregada exitosamente"}), 201

    except Exception as e:
        print("ERROR:", e)
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/solicitudes/<int:id_solicitud>", methods=["GET"])
def obtener_solicitud(id_solicitud):
    cursor = get_db().cursor()
    cursor.execute("SELECT * FROM solicitudes WHERE id=%s", (id_solicitud,))
    solicitud = cursor.fetchone()
    cursor.close()
    if not solicitud:
        return jsonify({"error": "Solicitud no encontrada"}), 404
    return jsonify({"solicitud": serializar_registro(solicitud)}), 200

@app.route("/api/editar_solicitud/<int:id_solicitud>", methods=["PUT"])
def editar_estado(id_solicitud):
    try:
        cursor = get_db().cursor()
        data = request.get_json(force=True)
        estado = data.get("estado")
        cursor.execute(
            "UPDATE solicitudes SET estado=%s WHERE id=%s",
            (estado, id_solicitud)
        )
        get_db().commit()
        registrar_auditoria("Sistema", "editar_estado", id_solicitud, f"nuevo estado: {estado}")


        if cursor.rowcount == 0:
            return jsonify({"error": "Solicitud no encontrada"}), 404

        cursor.close()
        return jsonify({"message": "Solicitud actualizada exitosamente"}), 200

    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/solicitudes/<int:id_solicitud>", methods=["DELETE"])
@jwt_required()
def delete_solicitud(id_solicitud):
    if not es_admin():
        return jsonify({"error": "No autorizado"}), 403
    try:
        cursor = get_db().cursor()
        cursor.execute("DELETE FROM solicitudes WHERE id=%s", (id_solicitud,))
        get_db().commit()
        claims = get_jwt()
        registrar_auditoria(claims.get("nombre"), "eliminar", id_solicitud) 
        if cursor.rowcount == 0:
            return jsonify({"error": "Solicitud no encontrada"}), 404

        cursor.close()
        return jsonify({"message": "Solicitud eliminada exitosamente"}), 200

    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/resolver/<int:id_solicitud>", methods=["PUT"])
def resolver_solicitud(id_solicitud):
    try:
        data = request.get_json(force=True)
        asignado_a = data.get("asignado_a")

        if not asignado_a:
            return jsonify({"error": "El campo 'asignado_a' es obligatorio"}), 400

        cursor = get_db().cursor()
        cursor.execute(
            "UPDATE solicitudes SET estado=%s, fecha_resuelto=NOW(), asignado_a=%s WHERE id=%s",
            ("resuelto", asignado_a, id_solicitud)
        )
        get_db().commit()
        registrar_auditoria(asignado_a, "resolver", id_solicitud)

        if cursor.rowcount == 0:
            return jsonify({"error": "Solicitud no encontrada"}), 404

        cursor.close()
        return jsonify({"message": "Solicitud resuelta exitosamente"}), 200

    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/asignar/<int:id>", methods=["PUT"])
@jwt_required()
def asignar_solicitud(id):
    claims = get_jwt()
    data = request.get_json()
    asignado_a = data.get("asignado_a")

    if not asignado_a:
        return jsonify({"error": "Falta el campo asignado_a"}), 400

    if not es_admin() and asignado_a != claims.get("nombre"):
        return jsonify({"error": "No autorizado"}), 403

    try:
        cursor = get_db().cursor()

        # Verificar si ya tiene alguien asignado
        cursor.execute("SELECT asignado_a FROM solicitudes WHERE id=%s", (id,))
        solicitud = cursor.fetchone()
        if not solicitud:
            return jsonify({"error": "Solicitud no encontrada"}), 404
        if solicitud["asignado_a"]:
            return jsonify({"error": "Esta solicitud ya tiene un responsable asignado"}), 409

        cursor.execute("UPDATE solicitudes SET asignado_a=%s WHERE id=%s", (asignado_a, id))
        get_db().commit()
        registrar_auditoria(claims.get("nombre"), "asignar", id, f"asignado a: {asignado_a}")
        cursor.close()
        return jsonify({"message": "Asignado correctamente"}), 200

    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

    
@app.route("/api/mis-solicitudes", methods=["GET"])
@jwt_required()
def mis_solicitudes():
    claims = get_jwt()
    nombre_usuario = claims.get("nombre")
    cursor = get_db().cursor()
    cursor.execute(
        "SELECT * FROM solicitudes WHERE asignado_a=%s ORDER BY fecha_reporte DESC",
        (nombre_usuario,)
    )
    solicitudes = cursor.fetchall()
    cursor.close()
    return jsonify({"solicitudes": [serializar_registro(s) for s in solicitudes]}), 200

# ─── Usuarios ────────────────────────────────────────────────────────────────

@app.route("/api/usuarios", methods=["POST"])
@jwt_required()
def register():
    if not es_admin():
        return jsonify({"error": "No autorizado"}), 403
    try:
        data = request.get_json(force=True)
        usuario  = data.get("usuario")
        password = data.get("password")
        nombre   = data.get("nombre")
        tipo     = int(data.get("tipo", 2))

        if not usuario or not password:
            return jsonify({"error": "Usuario y contraseña son obligatorios"}), 400
        if not nombre:
            return jsonify({"error": "El nombre es obligatorio"}), 400

        cursor = get_db().cursor()
        cursor.execute("SELECT * FROM usuarios WHERE usuario = %s", (usuario,))
        if cursor.fetchone():
            cursor.close()
            return jsonify({"error": "El usuario ya existe"}), 400

        hashed_password = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(rounds=10))
        cursor.execute(
            "INSERT INTO usuarios (usuario, password, tipo, nombre) VALUES (%s, %s, %s, %s)",
            (usuario, hashed_password.decode("utf-8"), tipo, nombre)
        )
        get_db().commit()
        registrar_auditoria(get_jwt().get("nombre"), "crear_usuario", detalle=f"usuario creado: {usuario}")
        cursor.close()
        return jsonify({"message": "Usuario registrado exitosamente"}), 201

    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500
    
@app.route("/api/usuarios", methods=["GET"])
@jwt_required()
def obtener_usuarios():
    if not es_admin():
        return jsonify({"error": "No autorizado"}), 403
    cursor = get_db().cursor()
    cursor.execute("SELECT id, nombre, usuario, tipo FROM usuarios")  # nunca devolver el hash
    usuarios = cursor.fetchall()
    cursor.close()
    return jsonify({"usuarios": usuarios}), 200

@app.route("/api/usuarios/<int:id_usuario>", methods=["PUT"])
def actualizar_usuario(id_usuario):
    try:
        data    = request.get_json(force=True)
        tipo    = data.get("tipo")
        nombre  = data.get("nombre")
        usuario = data.get("usuario")

        if tipo is None or not nombre or not usuario:
            return jsonify({"error": "tipo, nombre y usuario son obligatorios"}), 400

        cursor = get_db().cursor()
        cursor.execute(
            "UPDATE usuarios SET tipo=%s, nombre=%s, usuario=%s WHERE id=%s",
            (tipo, nombre, usuario, id_usuario)
        )
        get_db().commit()

        if cursor.rowcount == 0:
            return jsonify({"error": "Usuario no encontrado"}), 404

        cursor.close()
        return jsonify({"message": "Usuario actualizado exitosamente"}), 200

    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/usuarios/<int:id_usuario>", methods=["DELETE"])
@jwt_required()
def eliminar_usuario(id_usuario):
    if not es_admin():
        return jsonify({"error": "No autorizado"}), 403
    try:
        cursor = get_db().cursor()
        
        # Obtener nombre del usuario antes de eliminarlo
        cursor.execute("SELECT nombre, usuario FROM usuarios WHERE id=%s", (id_usuario,))
        usuario_obj = cursor.fetchone()
        if not usuario_obj:
            return jsonify({"error": "Usuario no encontrado"}), 404

        cursor.execute("DELETE FROM usuarios WHERE id=%s", (id_usuario,))
        get_db().commit()

        claims = get_jwt()
        registrar_auditoria(
            claims.get("nombre"),
            "eliminar_usuario",
            detalle=f"usuario eliminado: {usuario_obj['usuario']} ({usuario_obj['nombre']})"
        )

        cursor.close()
        return jsonify({"message": "Usuario eliminado exitosamente"}), 200

    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/login", methods=["POST"])
def login():
    try:
        cursor = get_db().cursor()
        data     = request.get_json(force=True)
        usuario  = data.get("usuario")
        password = data.get("password")

        if not usuario or not password:
            return jsonify({"error": "Credenciales obligatorias"}), 400

        cursor.execute("SELECT * FROM usuarios WHERE usuario = %s", (usuario,))
        user = cursor.fetchone()
        cursor.close()

        if user and bcrypt.checkpw(password.encode("utf-8"), user["password"].encode("utf-8")):
            token = create_access_token(
                identity=usuario,
                additional_claims={
                    "tipo": user["tipo"],
                    "nombre": user["nombre"]
                }
            )
            return jsonify({"token": token, "nombre": user["nombre"], "tipo": user["tipo"]}), 200

        return jsonify({"error": "Usuario o contraseña incorrecto"}), 401

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)