import os
from datetime import timedelta, date, datetime
from flask import Flask, render_template, request, jsonify, g
import pymysql
from flask_cors import CORS
import bcrypt
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt
from dbutils.pooled_db import PooledDB

app = Flask(__name__)
CORS(app,
     origins=["http://localhost:5000", "http://127.0.0.1:5000"],
     supports_credentials=True,
     allow_headers=["Content-Type", "Authorization"]
)

app.config["JWT_SECRET_KEY"]            = os.environ.get("JWT_SECRET_KEY", "cambia-esto-en-produccion")
app.config["JWT_ACCESS_TOKEN_EXPIRES"]  = timedelta(minutes=60)
app.config["JWT_TOKEN_LOCATION"]        = ["headers"]
app.config["JWT_HEADER_NAME"]           = "Authorization"
app.config["JWT_HEADER_TYPE"]           = "Bearer"
jwt = JWTManager(app)

pool = PooledDB(
    creator=pymysql,
    maxconnections=10,
    mincached=3,
    blocking=True,
    host=os.environ.get("DB_HOST", "localhost"),
    user=os.environ.get("DB_USER", "root"),
    password=os.environ.get("DB_PASSWORD", "sbarman"),
    db=os.environ.get("DB_NAME", "sistema_solicitudes"),
    cursorclass=pymysql.cursors.DictCursor
)

# ─── DB ───────────────────────────────────────────────────────────────────────

def get_db():
    if 'db' not in g:
        g.db = pool.connection()
    return g.db

@app.teardown_appcontext
def close_db(error):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def serializar_registro(row):
    result = {}
    for k, v in row.items():
        if isinstance(v, (date, datetime)):
            result[k] = v.isoformat()
        else:
            result[k] = v
    return result

# ─── HELPERS ──────────────────────────────────────────────────────────────────

def es_admin():
    claims = get_jwt()
    return int(claims.get("tipo", 0)) == 1

def registrar_auditoria(usuario, accion, id_solicitud=None, detalle=None):
    try:
        cursor = get_db().cursor()
        cursor.execute(
            "INSERT INTO auditoria (usuario, accion, id_solicitud, detalle) VALUES (%s, %s, %s, %s)",
            (usuario, accion, id_solicitud, detalle)
        )
        get_db().commit()
        cursor.close()
    except Exception as e:
        print("Error auditoria:", e)

def insertar_notificacion(usuario, id_solicitud, mensaje):
    """Inserta una notificación en BD para el usuario asignado."""
    try:
        cursor = get_db().cursor()
        cursor.execute(
            "INSERT INTO notificaciones (usuario, id_solicitud, mensaje) VALUES (%s, %s, %s)",
            (usuario, id_solicitud, mensaje)
        )
        get_db().commit()
        cursor.close()
    except Exception as e:
        print("Error insertar_notificacion:", e)

def auto_asignar(tipo_soporte):
    """Retorna el nombre del usuario con menos solicitudes activas en la categoría."""
    try:
        cursor = get_db().cursor()
        cursor.execute("""
            SELECT u.nombre, COUNT(s.id) as activas
            FROM usuarios u
            LEFT JOIN solicitudes s ON s.asignado_a = u.nombre AND s.estado != 'resuelto'
            WHERE u.categoria = %s
            GROUP BY u.nombre
            ORDER BY activas ASC
            LIMIT 1
        """, (tipo_soporte,))
        resultado = cursor.fetchone()
        cursor.close()
        return resultado["nombre"] if resultado else None
    except Exception as e:
        print("Error auto_asignar:", e)
        return None

# ─── PÁGINAS HTML ─────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/login")
def login_page():
    return render_template("login.html")

@app.route("/dashboard")
def dashboard_page():
    return render_template("index.html")

@app.route("/nueva-solicitud")
def solicitud_page():
    return render_template("nueva_solicitud.html")

# ─── SOLICITUDES ──────────────────────────────────────────────────────────────

@app.route("/api/solicitudes", methods=["GET"])
@jwt_required()
def obtener_solicitudes():
    claims = get_jwt()
    cursor = get_db().cursor()
    if es_admin():
        cursor.execute("SELECT * FROM solicitudes ORDER BY fecha_reporte DESC")
    else:
        nombre_usuario = claims.get("nombre")
        cursor.execute(
            "SELECT * FROM solicitudes WHERE asignado_a=%s ORDER BY fecha_reporte DESC",
            (nombre_usuario,)
        )
    registros = cursor.fetchall()
    cursor.close()
    return jsonify({"registros": [serializar_registro(r) for r in registros]}), 200

@app.route("/api/solicitudes", methods=["POST"])
@jwt_required()
def agregar_solicitud():
    claims = get_jwt()
    nombre = claims.get("nombre")
    try:
        cursor = get_db().cursor()
        data = request.get_json(force=True)

        cliente         = data.get("cliente")
        persona_reporta = data.get("persona_reporta")
        tipo_soporte    = data.get("tipo_soporte")
        descripcion     = data.get("descripcion")
        prioridad       = data.get("prioridad")
        fecha_reporte   = data.get("fecha_reporte")
        estado          = data.get("estado")

        cursor.execute(
            """INSERT INTO solicitudes
               (cliente, persona_reporta, tipo_soporte, descripcion, prioridad, fecha_reporte, estado)
               VALUES (%s, %s, %s, %s, %s, %s, %s)""",
            (cliente, persona_reporta, tipo_soporte, descripcion, prioridad, fecha_reporte, estado)
        )
        get_db().commit()
        nueva_id = cursor.lastrowid
        registrar_auditoria(nombre or "Sistema", "crear_solicitud", nueva_id)

        asignado = auto_asignar(tipo_soporte)
        if asignado:
            cursor2 = get_db().cursor()
            cursor2.execute("UPDATE solicitudes SET asignado_a=%s WHERE id=%s", (asignado, nueva_id))
            get_db().commit()
            cursor2.close()
            registrar_auditoria(asignado, "asignar", nueva_id, "auto-asignado por categoría")
            insertar_notificacion(
                asignado,
                nueva_id,
                f"Nueva solicitud asignada: {cliente} ({tipo_soporte} · {prioridad})"
            )

        cursor.close()
        return jsonify({
            "message":      "Solicitud agregada exitosamente",
            "id":           nueva_id,
            "asignado_a":   asignado,
            "cliente":      cliente,
            "tipo_soporte": tipo_soporte,
            "prioridad":    prioridad,
        }), 201

    except Exception as e:
        print("ERROR:", e)
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/solicitud-publica", methods=["POST"])
def crear_solicitud_publica():
    try:
        cursor = get_db().cursor()
        data = request.get_json(force=True)

        cliente         = data.get("cliente")
        persona_reporta = data.get("persona_reporta")
        tipo_soporte    = data.get("tipo_soporte")
        descripcion     = data.get("descripcion")
        prioridad       = data.get("prioridad")
        fecha_reporte   = data.get("fecha_reporte")

        if not cliente or not tipo_soporte or not prioridad or not fecha_reporte:
            return jsonify({"error": "Completa todos los campos obligatorios"}), 400

        cursor.execute(
            """INSERT INTO solicitudes
               (cliente, persona_reporta, tipo_soporte, descripcion, prioridad, fecha_reporte, estado)
               VALUES (%s, %s, %s, %s, %s, %s, %s)""",
            (cliente, persona_reporta, tipo_soporte, descripcion, prioridad, fecha_reporte, "pendiente")
        )
        get_db().commit()
        nueva_id = cursor.lastrowid
        registrar_auditoria(persona_reporta or "Público", "crear_solicitud", nueva_id)

        asignado = auto_asignar(tipo_soporte)
        if asignado:
            cursor2 = get_db().cursor()
            cursor2.execute("UPDATE solicitudes SET asignado_a=%s WHERE id=%s", (asignado, nueva_id))
            get_db().commit()
            cursor2.close()
            registrar_auditoria(asignado, "asignar", nueva_id, "auto-asignado por categoría")
            insertar_notificacion(
                asignado,
                nueva_id,
                f"Nueva solicitud asignada: {cliente} ({tipo_soporte} · {prioridad})"
            )

        cursor.close()
        return jsonify({"message": "Solicitud enviada exitosamente"}), 201

    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/solicitudes/<int:id_solicitud>", methods=["GET"])
def obtener_solicitud(id_solicitud):
    cursor = get_db().cursor()
    cursor.execute("SELECT * FROM solicitudes WHERE id=%s", (id_solicitud,))
    solicitud = cursor.fetchone()
    cursor.close()
    if not solicitud:
        return jsonify({"error": "Solicitud no encontrada"}), 404
    return jsonify({"solicitud": serializar_registro(solicitud)}), 200

@app.route("/api/solicitudes/<int:id_solicitud>", methods=["DELETE"])
@jwt_required()
def delete_solicitud(id_solicitud):
    if not es_admin():
        return jsonify({"error": "No autorizado"}), 403
    try:
        cursor = get_db().cursor()
        cursor.execute("DELETE FROM solicitudes WHERE id=%s", (id_solicitud,))
        get_db().commit()
        if cursor.rowcount == 0:
            cursor.close()
            return jsonify({"error": "Solicitud no encontrada"}), 404
        registrar_auditoria(get_jwt().get("nombre"), "eliminar", id_solicitud)
        cursor.close()
        return jsonify({"message": "Solicitud eliminada exitosamente"}), 200
    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/editar_solicitud/<int:id_solicitud>", methods=["PUT"])
@jwt_required()
def editar_estado(id_solicitud):
    claims = get_jwt()
    try:
        cursor = get_db().cursor()
        data   = request.get_json(force=True)
        estado = data.get("estado")
        cursor.execute("UPDATE solicitudes SET estado=%s WHERE id=%s", (estado, id_solicitud))
        get_db().commit()
        if cursor.rowcount == 0:
            cursor.close()
            return jsonify({"error": "Solicitud no encontrada"}), 404
        registrar_auditoria(
            claims.get("nombre", "Sistema"),
            "editar_estado",
            id_solicitud,
            f"nuevo estado: {estado}"
        )
        cursor.close()
        return jsonify({"message": "Solicitud actualizada exitosamente"}), 200
    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/resolver/<int:id_solicitud>", methods=["PUT"])
@jwt_required()
def resolver_solicitud(id_solicitud):
    claims = get_jwt()
    try:
        data       = request.get_json(force=True)
        asignado_a = data.get("asignado_a")
        if not asignado_a:
            return jsonify({"error": "El campo 'asignado_a' es obligatorio"}), 400
        cursor = get_db().cursor()
        cursor.execute(
            "UPDATE solicitudes SET estado=%s, fecha_resuelto=NOW(), asignado_a=%s WHERE id=%s",
            ("resuelto", asignado_a, id_solicitud)
        )
        get_db().commit()
        if cursor.rowcount == 0:
            cursor.close()
            return jsonify({"error": "Solicitud no encontrada"}), 404
        registrar_auditoria(claims.get("nombre", asignado_a), "resolver", id_solicitud)
        cursor.close()
        return jsonify({"message": "Solicitud resuelta exitosamente"}), 200
    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/asignar/<int:id>", methods=["PUT"])
@jwt_required()
def asignar_solicitud(id):
    claims     = get_jwt()
    data       = request.get_json()
    asignado_a = data.get("asignado_a")

    if not asignado_a:
        return jsonify({"error": "Falta el campo asignado_a"}), 400
    if not es_admin() and asignado_a != claims.get("nombre"):
        return jsonify({"error": "No autorizado"}), 403

    try:
        cursor = get_db().cursor()
        cursor.execute(
            "SELECT asignado_a, cliente, tipo_soporte, prioridad FROM solicitudes WHERE id=%s", (id,)
        )
        solicitud = cursor.fetchone()
        if not solicitud:
            cursor.close()
            return jsonify({"error": "Solicitud no encontrada"}), 404
        if solicitud["asignado_a"]:
            cursor.close()
            return jsonify({"error": "Esta solicitud ya tiene un responsable asignado"}), 409
        cursor.execute("UPDATE solicitudes SET asignado_a=%s WHERE id=%s", (asignado_a, id))
        get_db().commit()
        registrar_auditoria(claims.get("nombre"), "asignar", id, f"asignado a: {asignado_a}")
        insertar_notificacion(
            asignado_a,
            id,
            f"Nueva solicitud asignada: {solicitud['cliente']} ({solicitud['tipo_soporte']} · {solicitud['prioridad']})"
        )
        cursor.close()
        return jsonify({"message": "Asignado correctamente"}), 200
    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

# ─── NOTIFICACIONES ───────────────────────────────────────────────────────────

@app.route("/api/notificaciones", methods=["GET"])
@jwt_required()
def obtener_notificaciones():
    claims = get_jwt()
    nombre_usuario = claims.get("nombre")
    cursor = get_db().cursor()
    cursor.execute("""
        SELECT id, id_solicitud, mensaje, leida, fecha
        FROM notificaciones
        WHERE usuario = %s
        ORDER BY fecha DESC
        LIMIT 30
    """, (nombre_usuario,))
    rows = cursor.fetchall()
    cursor.close()
    return jsonify({"notificaciones": [serializar_registro(r) for r in rows]}), 200

@app.route("/api/notificaciones/no-leidas", methods=["GET"])
@jwt_required()
def contar_no_leidas():
    claims = get_jwt()
    nombre_usuario = claims.get("nombre")
    cursor = get_db().cursor()
    cursor.execute(
        "SELECT COUNT(*) as total FROM notificaciones WHERE usuario = %s AND leida = 0",
        (nombre_usuario,)
    )
    resultado = cursor.fetchone()
    cursor.close()
    return jsonify({"total": resultado["total"]}), 200

@app.route("/api/notificaciones/marcar-leidas", methods=["PUT"])
@jwt_required()
def marcar_leidas():
    claims = get_jwt()
    nombre_usuario = claims.get("nombre")
    cursor = get_db().cursor()
    cursor.execute(
        "UPDATE notificaciones SET leida = 1 WHERE usuario = %s AND leida = 0",
        (nombre_usuario,)
    )
    get_db().commit()
    cursor.close()
    return jsonify({"message": "Marcadas como leídas"}), 200

@app.route("/api/notificaciones/limpiar", methods=["DELETE"])
@jwt_required()
def limpiar_notificaciones():
    claims = get_jwt()
    nombre_usuario = claims.get("nombre")
    cursor = get_db().cursor()
    cursor.execute("DELETE FROM notificaciones WHERE usuario = %s", (nombre_usuario,))
    get_db().commit()
    cursor.close()
    return jsonify({"message": "Notificaciones eliminadas"}), 200

# ─── USUARIOS ─────────────────────────────────────────────────────────────────

@app.route("/api/usuarios", methods=["GET"])
@jwt_required()
def obtener_usuarios():
    if not es_admin():
        return jsonify({"error": "No autorizado"}), 403
    cursor   = get_db().cursor()
    cursor.execute("SELECT id, nombre, usuario, tipo, categoria FROM usuarios")
    usuarios = cursor.fetchall()
    cursor.close()
    return jsonify({"usuarios": usuarios}), 200

@app.route("/api/usuarios", methods=["POST"])
@jwt_required()
def register():
    if not es_admin():
        return jsonify({"error": "No autorizado"}), 403
    try:
        data     = request.get_json(force=True)
        usuario  = data.get("usuario")
        password = data.get("password")
        nombre   = data.get("nombre")
        tipo     = int(data.get("tipo", 2))

        if not usuario or not password or not nombre:
            return jsonify({"error": "Todos los campos son obligatorios"}), 400

        cursor = get_db().cursor()
        cursor.execute("SELECT id FROM usuarios WHERE usuario = %s", (usuario,))
        if cursor.fetchone():
            cursor.close()
            return jsonify({"error": "El usuario ya existe"}), 400

        hashed = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(rounds=10))
        cursor.execute(
            "INSERT INTO usuarios (usuario, password, tipo, nombre) VALUES (%s, %s, %s, %s)",
            (usuario, hashed.decode("utf-8"), tipo, nombre)
        )
        get_db().commit()
        registrar_auditoria(get_jwt().get("nombre"), "crear_usuario", detalle=f"usuario creado: {usuario}")
        cursor.close()
        return jsonify({"message": "Usuario registrado exitosamente"}), 201
    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/usuarios/<int:id_usuario>", methods=["PUT"])
@jwt_required()
def actualizar_usuario(id_usuario):
    if not es_admin():
        return jsonify({"error": "No autorizado"}), 403
    try:
        data      = request.get_json(force=True)
        tipo      = data.get("tipo")
        nombre    = data.get("nombre")
        usuario   = data.get("usuario")
        categoria = data.get("categoria")

        if tipo is None or not nombre or not usuario:
            return jsonify({"error": "tipo, nombre y usuario son obligatorios"}), 400

        cursor = get_db().cursor()
        cursor.execute(
            "UPDATE usuarios SET tipo=%s, nombre=%s, usuario=%s, categoria=%s WHERE id=%s",
            (tipo, nombre, usuario, categoria, id_usuario)
        )
        get_db().commit()
        if cursor.rowcount == 0:
            cursor.close()
            return jsonify({"error": "Usuario no encontrado"}), 404
        cursor.close()
        return jsonify({"message": "Usuario actualizado exitosamente"}), 200
    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/usuarios/<int:id_usuario>", methods=["DELETE"])
@jwt_required()
def eliminar_usuario(id_usuario):
    if not es_admin():
        return jsonify({"error": "No autorizado"}), 403
    try:
        cursor = get_db().cursor()
        cursor.execute("SELECT nombre, usuario FROM usuarios WHERE id=%s", (id_usuario,))
        usuario_obj = cursor.fetchone()
        if not usuario_obj:
            cursor.close()
            return jsonify({"error": "Usuario no encontrado"}), 404
        cursor.execute("DELETE FROM usuarios WHERE id=%s", (id_usuario,))
        get_db().commit()
        registrar_auditoria(
            get_jwt().get("nombre"), "eliminar_usuario",
            detalle=f"usuario eliminado: {usuario_obj['usuario']} ({usuario_obj['nombre']})"
        )
        cursor.close()
        return jsonify({"message": "Usuario eliminado exitosamente"}), 200
    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

# ─── AUTH ─────────────────────────────────────────────────────────────────────

@app.route("/api/login", methods=["POST"])
def login():
    try:
        cursor   = get_db().cursor()
        data     = request.get_json(force=True)
        usuario  = data.get("usuario")
        password = data.get("password")

        if not usuario or not password:
            return jsonify({"error": "Credenciales obligatorias"}), 400

        cursor.execute("SELECT * FROM usuarios WHERE usuario = %s", (usuario,))
        user = cursor.fetchone()
        cursor.close()

        if user and bcrypt.checkpw(password.encode("utf-8"), user["password"].encode("utf-8")):
            token = create_access_token(
                identity=usuario,
                additional_claims={"tipo": user["tipo"], "nombre": user["nombre"]}
            )
            return jsonify({"token": token, "nombre": user["nombre"], "tipo": user["tipo"]}), 200

        return jsonify({"error": "Usuario o contraseña incorrecto"}), 401
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ─── AUDITORÍA ────────────────────────────────────────────────────────────────

@app.route("/api/auditoria", methods=["GET"])
@jwt_required()
def obtener_auditoria():
    if not es_admin():
        return jsonify({"error": "No autorizado"}), 403
    cursor = get_db().cursor()
    cursor.execute("SELECT * FROM auditoria ORDER BY fecha DESC LIMIT 200")
    registros = cursor.fetchall()
    cursor.close()
    return jsonify({"registros": [serializar_registro(r) for r in registros]}), 200


if __name__ == '__main__':
    app.run(debug=True)