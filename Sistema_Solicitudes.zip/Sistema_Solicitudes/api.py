from datetime import timedelta
from flask import Flask, render_template, request, jsonify
import pymysql
from flask_cors import CORS 
import bcrypt
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt

app = Flask(__name__)
CORS(app, 
     origins=["http://localhost:5000", "http://127.0.0.1:5000"],
     supports_credentials=True,
     allow_headers=["Content-Type", "Authorization"]
)
app.config["JWT_SECRET_KEY"] = "ilder123"
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(minutes=30)
app.config["JWT_TOKEN_LOCATION"] = ["headers"]
app.config["JWT_HEADER_NAME"] = "Authorization"
app.config["JWT_HEADER_TYPE"] = "Bearer"
jwt = JWTManager(app)

db = None  # ← aquí

def conectar_db():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='sbarman',
        db='sistema_solicitudes',
        cursorclass=pymysql.cursors.DictCursor
    )

def get_db():
    global db
    try:
        db.ping(reconnect=True)
    except:
        db = conectar_db()
    return db
# Esta es la ruta principal que muestra el index.html
@app.route("/")
def index():
    return render_template("index.html")

def es_admin():
    claims = get_jwt()
    # Forzamos la conversión a int por seguridad
    return int(claims.get("tipo", 0)) == 1

@app.route("/api/solicitudes", methods=["GET"])
def obtener_solicitudes():
    cursor = get_db().cursor()
    cursor.execute("SELECT * FROM solicitudes ORDER BY fecha_reporte DESC")
    registros = cursor.fetchall()
    cursor.close()
    return jsonify({"registros": registros}), 200

@app.route("/api/solicitudes", methods=["POST"])
def agregar_solicitud():
    try:
        cursor = get_db().cursor()
        data = request.get_json(force=True)
        print("DATA RECIBIDA:", data)  # ← agrega esto temporalmente

        cliente         = data.get("cliente")
        persona_reporta = data.get("persona_reporta")
        tipo_soporte    = data.get("tipo_soporte")
        descripcion     = data.get("descripcion")
        prioridad       = data.get("prioridad")
        fecha_reporte   = data.get("fecha_reporte")
        estado          = data.get("estado")

        cursor.execute(
            """INSERT INTO solicitudes 
               (cliente, persona_reporta, tipo_soporte, descripcion, prioridad, fecha_reporte, estado) 
               VALUES (%s, %s, %s, %s, %s, %s, %s)""",
            (cliente, persona_reporta, tipo_soporte, descripcion, prioridad, fecha_reporte, estado)
        )
        get_db().commit()
        cursor.close()
        return jsonify({"message": "Solicitud agregada exitosamente"}), 201

    except Exception as e:
        print("ERROR:", e)  # ← y esto
        get_db().rollback()
        return jsonify({"error": str(e)}), 500
    
@app.route("/api/editar_solicitud/<int:id_solicitud>", methods=["PUT"])
def editar_estado(id_solicitud):
    try:
        cursor = get_db().cursor()
        data = request.get_json(force=True)
        estado = data.get("estado")
        cursor.execute(
            "UPDATE solicitudes SET estado=%s WHERE id=%s",
            (estado, id_solicitud)
        )
        get_db().commit()

        if cursor.rowcount == 0:
            return jsonify({"error": "Solicitud no encontrada"}), 404

        cursor.close()
        return jsonify({"message": "Solicitud actualizada exitosamente"}), 200

    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/solicitudes/<int:id_solicitud>", methods=["GET"])
def obtener_solicitud(id_solicitud):
    cursor = get_db().cursor()
    cursor.execute("SELECT * FROM solicitudes WHERE id=%s", (id_solicitud,))
    solicitud = cursor.fetchone()
    cursor.close()
    if not solicitud:
        return jsonify({"error": "Solicitud no encontrada"}), 404
    return jsonify({"solicitud": solicitud}), 200

@app.route("/register", methods=["GET"])
def register_page():
    return render_template("register.html")

@app.route("/api/usuarios", methods=["POST"])
def register():
    try:
        data = request.get_json(force=True)
        usuario = data.get("usuario")
        password = data.get("password")
        nombre = data.get("nombre")

        if not usuario or not password:
            return jsonify({"error": "Usuario y contraseña son obligatorios"}), 400
        
        if not nombre:
            return jsonify({"error": "El nombre es obligatorio"}), 400

        cursor = get_db().cursor()
        cursor.execute("SELECT * FROM usuarios WHERE usuario = %s", (usuario,))
        if cursor.fetchone():
            cursor.close()
            return jsonify({"error": "El usuario ya existe"}), 400

        hashed_password = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(rounds=10))
        cursor.execute(
            "INSERT INTO usuarios (usuario, password, tipo, nombre) VALUES (%s, %s, %s, %s)",
            (usuario, hashed_password.decode("utf-8"), 2, nombre)
        )
        get_db().commit()
        cursor.close()
        return jsonify({"message": "Usuario registrado exitosamente"}), 201

    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/usuarios", methods=["GET"])
def obtener_usuarios():
    cursor = get_db().cursor()
    cursor.execute("SELECT * FROM usuarios")
    usuarios = cursor.fetchall()
    cursor.close()
    return jsonify({"usuarios": usuarios}), 200

@app.route("/api/usuarios/<int:id_usuario>", methods=["DELETE"])
@jwt_required()
def eliminar_usuario(id_usuario):
  
    if not es_admin():
        return jsonify({"error": "No autorizado"}), 403
    try:
        cursor = get_db().cursor()
        cursor.execute("DELETE FROM usuarios WHERE id=%s", (id_usuario,))
        get_db().commit()

        if cursor.rowcount == 0:
            return jsonify({"error": "Usuario no encontrado"}), 404

        cursor.close()
        return jsonify({"message": "Usuario eliminado exitosamente"}), 200

    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

# ✅ Login corregido - usa "nombre" consistente
@app.route("/api/login", methods=["POST"])
def login():
    try:
        cursor = get_db().cursor()
        data = request.get_json(force=True)
        usuario = data.get("usuario")
        password = data.get("password")

        if not usuario or not password:
            return jsonify({"error": "Credenciales obligatorias"}), 400

        cursor.execute("SELECT * FROM usuarios WHERE usuario = %s", (usuario,))
        user = cursor.fetchone()
        cursor.close()

        if user and bcrypt.checkpw(password.encode("utf-8"), user["password"].encode("utf-8")):
            token = create_access_token(
                identity=usuario,
                additional_claims={
                    "tipo": user["tipo"],
                    "nombre": user["nombre"]   # ✅ columna correcta
                }
            )
            return jsonify({"token": token, "nombre": user["nombre"], "tipo": user["tipo"]}), 200

        return jsonify({"error": "Usuario o contraseña incorrecto"}), 401

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/resolver/<int:id_solicitud>", methods=["PUT"])
def resolver_solicitud(id_solicitud):
    try:
        data = request.get_json(force=True)
        asignado_a = data.get("asignado_a")

        if not asignado_a:
            return jsonify({"error": "El campo 'asignado_a' es obligatorio"}), 400

        cursor = get_db().cursor()
        cursor.execute(
            "UPDATE solicitudes SET estado=%s, fecha_resuelto=NOW(), asignado_a=%s WHERE id=%s",
            ("resuelto", asignado_a, id_solicitud)
        )
        get_db().commit()

        if cursor.rowcount == 0:
            return jsonify({"error": "Solicitud no encontrada"}), 404

        cursor.close()
        return jsonify({"message": "Solicitud resuelta exitosamente"}), 200

    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

# ✅ actualizar_usuario - tipo=0 ya no falla
@app.route("/api/usuarios/<int:id_usuario>", methods=["PUT"])
def actualizar_usuario(id_usuario):
    try:
        data = request.get_json(force=True)
        tipo    = data.get("tipo")
        nombre  = data.get("nombre")
        usuario = data.get("usuario")

        if tipo is None or not nombre or not usuario:   # ✅
            return jsonify({"error": "tipo, nombre y usuario son obligatorios"}), 400

        cursor = get_db().cursor()
        cursor.execute(
            "UPDATE usuarios SET tipo=%s, nombre=%s, usuario=%s WHERE id=%s",
            (tipo, nombre, usuario, id_usuario)
        )
        get_db().commit()

        if cursor.rowcount == 0:
            return jsonify({"error": "Usuario no encontrado"}), 404

        cursor.close()
        return jsonify({"message": "Usuario actualizado exitosamente"}), 200

    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/solicitudes/<int:id_solicitud>", methods=["DELETE"])
@jwt_required()
def delete_solicitud(id_solicitud):
    if not es_admin():
        return jsonify({"error": "No autorizado"}), 403
    try:
        cursor = get_db().cursor()
        cursor.execute("DELETE FROM solicitudes WHERE id=%s", (id_solicitud,))
        get_db().commit()

        if cursor.rowcount == 0:
            return jsonify({"error": "Solicitud no encontrada"}), 404

        cursor.close()
        return jsonify({"message": "Solicitud eliminada exitosamente"}), 200

    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/asignar/<int:id>", methods=["PUT"])
@jwt_required()
def asignar_solicitud(id):
    claims = get_jwt()
    data = request.get_json()
    asignado_a = data.get("asignado_a")
    
    if not asignado_a:
        return jsonify({"error": "Falta el campo asignado_a"}), 400
    
    # Solo admin puede asignar a otros, usuario solo a sí mismo
    if not es_admin() and asignado_a != claims.get("nombre"):
        return jsonify({"error": "No autorizado"}), 403

    try:
        cursor = get_db().cursor()
        cursor.execute("UPDATE solicitudes SET asignado_a=%s WHERE id=%s", (asignado_a, id))
        get_db().commit()
        if cursor.rowcount == 0:
            return jsonify({"error": "Solicitud no encontrada"}), 404
        cursor.close()
        return jsonify({"message": "Asignado correctamente"}), 200
    except Exception as e:
        get_db().rollback()
        return jsonify({"error": str(e)}), 500


@app.route("/api/mis-solicitudes", methods=["GET"])  
@jwt_required()
def mis_solicitudes():
        claims = get_jwt()
        nombre_usuario = claims.get("nombre")
        cursor = get_db().cursor()
        cursor.execute("SELECT * FROM solicitudes WHERE asignado_a=%s ORDER BY fecha_reporte DESC", (nombre_usuario,))
        solicitudes = cursor.fetchall()
        cursor.close()
        return jsonify({"solicitudes": solicitudes}), 200

  
# ✅ Rutas de páginas HTML faltantes
@app.route("/login")
def login_page():
    return render_template("login.html")

@app.route("/dashboard")
def dashboard_page():
    return render_template("index.html")




if __name__ == '__main__':
    app.run(debug=True)