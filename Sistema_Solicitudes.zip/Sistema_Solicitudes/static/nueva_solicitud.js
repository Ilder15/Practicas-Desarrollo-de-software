document.getElementById("f-fecha").valueAsDate = new Date();

function showToast(msg, type = "success") {
    const t = document.getElementById("toast");
    t.textContent = msg;
    t.className = `toast ${type} show`;
    setTimeout(() => t.classList.remove("show"), 3000);
}

async function enviar() {
    const body = {
        cliente:         document.getElementById("f-cliente").value.trim(),
        persona_reporta: document.getElementById("f-persona").value.trim(),
        tipo_soporte:    document.getElementById("f-tipo").value,
        prioridad:       document.getElementById("f-prioridad").value,
        fecha_reporte:   document.getElementById("f-fecha").value,
        descripcion:     document.getElementById("f-descripcion").value.trim(),
    };

    if (!body.cliente || !body.tipo_soporte || !body.prioridad || !body.fecha_reporte) {
        showToast("Completa todos los campos obligatorios", "error");
        return;
    }

    try {
        // CORREGIDO: URL con guion "-" para coincidir con la ruta Flask
        const res = await fetch("/api/solicitud-publica", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
        });
        const data = await res.json();
        if (res.ok) {
            showToast("¡Solicitud enviada exitosamente! ✓", "success");
            setTimeout(() => window.location.href = "/login", 2000);
        } else {
            showToast(data.error || "Error al enviar", "error");
        }
    } catch (e) {
        showToast("Error de conexión", "error");
    }
}
