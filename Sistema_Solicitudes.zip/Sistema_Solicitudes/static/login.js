document.getElementById("btnLogin").addEventListener("click", function() {
    const usuario = document.getElementById("usuario").value;
    const password = document.getElementById("password").value;

    if (!usuario || !password) {
        alert("Ingresa usuario y contraseña");
        return;
    }

    fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ usuario, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.token) {
            localStorage.setItem("token", data.token);
            localStorage.setItem("nombre", data.nombre);
            localStorage.setItem("tipo", data.tipo);
            window.location.href = "/";               
        } else {
            document.getElementById("error").style.display = "block";
        }
    })
    .catch(error => console.error("Error:", error));
});

