const btnRegister = document.getElementById("btnRegister");

if (btnRegister) {
    btnRegister.addEventListener("click", function () {
        const usuario  = document.getElementById("usuario").value;
        const password = document.getElementById("password").value;
        const nombre   = document.getElementById("nombre").value;

        if (!usuario || !password || !nombre) {
            alert("Ingresa todos los campos requeridos");
            return;
        }

        // CORREGIDO: URL relativa en lugar de http://127.0.0.1:5000 hardcodeado
        fetch("/api/usuarios", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ usuario, password, nombre })
        })
        .then(response => response.json())
        .then(data => {
            if (data.message) {
                alert("Usuario registrado exitosamente");
                window.location.href = "/login";
            } else {
                document.getElementById("error").textContent = data.error;
                document.getElementById("error").style.display = "block";
            }
        })
        .catch(error => console.error("Error:", error));
    });
}