const token  = localStorage.getItem("token");
const nombre = localStorage.getItem("nombre");
const tipo   = localStorage.getItem("tipo");

if (!token) window.location.href = "/login";

// Mostrar nombre y rol en sidenav
if (nombre) {
    document.getElementById("nombreAdmin").textContent = nombre;
    document.getElementById("avatarInitial").textContent = nombre.charAt(0).toUpperCase();
}
const roles = { "1": "Administrador", "2": "Empleado" };
const rolEl = document.querySelector(".user-role");
if (rolEl) rolEl.textContent = roles[tipo] || "Empleado";

// Ocultar secciones si no es admin
if (tipo !== "1") {
    document.querySelectorAll(".sidenav-link").forEach((link) => {
        const texto = link.querySelector("span")?.textContent.trim();
        if (["Usuarios", "Reportes", "Auditoria", "Configuración",""].includes(texto)) {
            link.style.display = "none";
        }
    });
}

let solicitudesData = [];
let editandoId = null;
let asignandoId = null;

// ─── API FETCH ────────────────────────────────────────────────────────────────
async function apiFetch(url, options = {}) {
    const res = await fetch(url, {
        ...options,
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token,
            ...options.headers,
        },
    });
    if (res.status === 401) {
        localStorage.clear();
        window.location.href = "/login";
        return null;
    }
    return res;
}

// ─── SIDENAV ──────────────────────────────────────────────────────────────────
function toggleSidenav() {
    document.getElementById("sidenav").classList.toggle("collapsed");
}

const sectionTitles = {
    solicitudes:       "Solicitudes",
    usuarios:          "Usuarios",
    reportes:          "Reportes",
    configuracion:     "Configuración",
    auditoria:         "Auditoría",
};

function switchSection(name, btn) {
    document.querySelectorAll(".page-section").forEach((s) => s.classList.remove("active"));
    document.querySelectorAll(".sidenav-link").forEach((l) => l.classList.remove("active"));
    document.getElementById("sec-" + name).classList.add("active");
    btn.classList.add("active");
    document.getElementById("topbarTitle").textContent = sectionTitles[name];

    if (name === "usuarios")        cargarUsuarios();
    if (name === "auditoria")       cargarAuditoria();
}

// ─── TABS ─────────────────────────────────────────────────────────────────────
function switchTab(name, btn) {
    document.querySelectorAll(".sub-section").forEach((s) => s.classList.remove("active"));
    document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
    document.getElementById("sec-" + name).classList.add("active");
    btn.classList.add("active");
}

// ─── SOLICITUDES ─────────────────────────────────────────────────────────────
async function cargarSolicitudes() {
    try {
        const res = await apiFetch("/api/solicitudes");
        if (!res) return;
        const data = await res.json();
        solicitudesData = data.registros || [];
        renderTabla(solicitudesData);
        actualizarStats(solicitudesData);
        renderRecientes(solicitudesData);

const recientesCard = document.querySelector(".recientes-card");
if (recientesCard) recientesCard.style.display = tipo === "1" ? "block" : "none";
    } catch (e) {
        document.getElementById("tablaSolicitudes").innerHTML =
            `<tr><td colspan="8"><div class="empty-state"><div class="icon">❌</div>Error al cargar datos</div></td></tr>`;
    }
}

async function crearSolicitud(nombreReporta) {
    const body = {
        cliente:         document.getElementById("f-cliente").value.trim(),
        persona_reporta: nombreReporta,
        tipo_soporte:    document.getElementById("f-tipo").value,
        prioridad:       document.getElementById("f-prioridad").value,
        fecha_reporte:   document.getElementById("f-fecha").value,
        estado:          document.getElementById("f-estado").value,
        descripcion:     document.getElementById("f-descripcion").value.trim(),
    };

    if (!body.cliente || !body.tipo_soporte || !body.prioridad || !body.fecha_reporte) {
        showToast("Completa todos los campos obligatorios", "error");
        return;
    }

    try {
        const res = await apiFetch("/api/solicitudes", {
            method: "POST",
            body: JSON.stringify(body),
        });
        if (!res) return;
        const d = await res.json();
        if (res.ok) {
            showToast("Solicitud creada exitosamente ✓", "success");
            ["f-cliente", "f-descripcion"].forEach((id) => (document.getElementById(id).value = ""));
            ["f-tipo", "f-prioridad"].forEach((id) => (document.getElementById(id).value = ""));
            document.getElementById("f-fecha").valueAsDate = new Date();
            switchTab("lista", document.querySelector(".tab"));
            cargarSolicitudes();
        } else {
            showToast(d.error || "Error al crear", "error");
        }
    } catch (e) { showToast("Error de conexión", "error"); }
}

async function borrarSolicitud(id) {
    try {
        const res = await apiFetch(`/api/solicitudes/${id}`, { method: "DELETE" });
        if (!res) return;
        if (res.ok) { showToast("Solicitud eliminada ✓", "success"); cargarSolicitudes(); }
        else { showToast("Error al eliminar", "error"); }
    } catch (e) { showToast("Error de conexión", "error"); }
}

// ─── USUARIOS ─────────────────────────────────────────────────────────────────
const categoriaLabel = {
    software:         "Software",
    hardware:         "Hardware",
    visitas_tecnicas: "Visitas Técnicas",
};

async function cargarUsuarios() {
    const lista = document.getElementById("usuariosLista");
    try {
        const res = await apiFetch("/api/usuarios");
        if (!res) return;
        const data = await res.json();
        const usuarios = data.usuarios || [];

        document.getElementById("usuariosCount").textContent = `${usuarios.length} usuarios`;

        if (!usuarios.length) {
            lista.innerHTML = `<div class="reciente-empty">✅ No hay usuarios registrados.</div>`;
            return;
        }

        lista.innerHTML = usuarios.map(u => {
            const esAdmin = u.tipo === 1 || u.tipo === "1";
            const cat = u.categoria ? categoriaLabel[u.categoria] || u.categoria : "Sin categoría";
            return `
                <div class="reciente-item">
                    <div class="usuario-avatar">${u.nombre.charAt(0).toUpperCase()}</div>
                    <div class="reciente-info">
                        <span class="reciente-cliente">${u.nombre}</span>
                        <span class="reciente-meta">@${u.usuario} · ID #${u.id} · ${cat}</span>
                    </div>
                    <div class="reciente-right">
                        <span class="badge ${esAdmin ? 'badge-alta' : 'badge-proceso'}">
                            ${esAdmin ? 'Admin' : 'Empleado'}
                        </span>
                        <button class="btn-action" onclick="editarUsuario(${u.id}, '${u.nombre}', '${u.usuario}', ${u.tipo}, '${u.categoria || ''}')">Editar</button>
                        <button class="btn-action delete" onclick="eliminarUsuario(${u.id})">Eliminar</button>
                    </div>
                </div>
            `;
        }).join('');
    } catch (e) {
        lista.innerHTML = `<div class="reciente-empty">❌ Error al conectar con el servidor.</div>`;
    }
}

async function eliminarUsuario(id) {
    if (!confirm("¿Eliminar este usuario?")) return;
    try {
        const res = await apiFetch(`/api/usuarios/${id}`, { method: "DELETE" });
        if (!res) return;
        if (res.ok) { showToast("Usuario eliminado ✓", "success"); cargarUsuarios(); }
        else { const d = await res.json(); showToast(d.error || "Error al eliminar", "error"); }
    } catch (e) { showToast("Error de conexión", "error"); }
}

function editarUsuario(id, nombre, usuario, tipo, categoria) {
    document.getElementById("edit-u-id").value        = id;
    document.getElementById("edit-u-nombre").value    = nombre;
    document.getElementById("edit-u-usuario").value   = usuario;
    document.getElementById("edit-u-tipo").value      = tipo;
    document.getElementById("edit-u-categoria").value = categoria || "";
    document.getElementById("modalEditarUsuario").classList.add("open");
}

function cerrarModalUsuario() {
    document.getElementById("modalEditarUsuario").classList.remove("open");
}

async function guardarUsuario() {
    const id        = document.getElementById("edit-u-id").value;
    const nombre    = document.getElementById("edit-u-nombre").value.trim();
    const usuario   = document.getElementById("edit-u-usuario").value.trim();
    const tipo      = document.getElementById("edit-u-tipo").value;
    const categoria = document.getElementById("edit-u-categoria").value || null;

    if (!nombre || !usuario) { showToast("Completa todos los campos", "error"); return; }
    try {
        const res = await apiFetch(`/api/usuarios/${id}`, {
            method: "PUT",
            body: JSON.stringify({ nombre, usuario, tipo, categoria }),
        });
        if (!res) return;
        if (res.ok) { showToast("Usuario actualizado ✓", "success"); cerrarModalUsuario(); cargarUsuarios(); }
        else { const d = await res.json(); showToast(d.error || "Error al actualizar", "error"); }
    } catch (e) { showToast("Error de conexión", "error"); }
}

async function registrarUsuario() {
    const nombre   = document.getElementById("nuevo-nombre").value.trim();
    const usuario  = document.getElementById("nuevo-usuario").value.trim();
    const password = document.getElementById("nuevo-password").value;
    const tipo     = document.getElementById("nuevo-tipo").value;

    if (!nombre || !usuario || !password) { showToast("Completa todos los campos", "error"); return; }
    if (password.length < 6) { showToast("La contraseña debe tener al menos 6 caracteres", "error"); return; }

    try {
        const res = await apiFetch("/api/usuarios", {
            method: "POST",
            body: JSON.stringify({ nombre, usuario, password, tipo: parseInt(tipo) }),
        });
        if (!res) return;
        if (res.ok) {
            showToast("Usuario creado exitosamente ✓", "success");
            ["nuevo-nombre", "nuevo-usuario", "nuevo-password"].forEach(id => {
                document.getElementById(id).value = "";
            });
            document.getElementById("nuevo-tipo").value = "2";
            cargarUsuarios();
        } else {
            const d = await res.json();
            showToast(d.error || "Error al crear usuario", "error");
        }
    } catch (e) { showToast("Error de conexión", "error"); }
}

// ─── STATS ────────────────────────────────────────────────────────────────────
function actualizarStats(data) {
    document.getElementById("statTotal").textContent     = data.length;
    document.getElementById("statPendiente").textContent = data.filter((s) => s.estado === "pendiente").length;
    document.getElementById("statResuelto").textContent  = data.filter((s) => s.estado === "resuelto").length;
    document.getElementById("statProceso").textContent   = data.filter((s) => s.estado === "en proceso").length;
}

// ─── TABLA ────────────────────────────────────────────────────────────────────
function formatFecha(fecha) {
    if (!fecha) return "—";
    return new Date(fecha).toLocaleDateString("es-CO", {
        day: "2-digit", month: "short", year: "numeric",
    });
}

function renderTabla(data) {
    const tbody = document.getElementById("tablaSolicitudes");
    if (!data.length) {
        tbody.innerHTML = `<tr><td colspan="8"><div class="empty-state"><div class="icon">📭</div>No hay solicitudes</div></td></tr>`;
        return;
    }
    tbody.innerHTML = data.map((s) => {
        const noResuelto = s.estado !== "resuelto";
        return `
            <tr>
                <td style="color:var(--muted)">#${s.id}</td>
                <td><strong>${s.cliente}</strong></td>
                <td>${s.persona_reporta || "—"}</td>
                <td>${s.tipo_soporte}</td>
                <td><span class="badge badge-${s.prioridad}">${s.prioridad}</span></td>
                <td><span class="badge badge-${s.estado === "en proceso" ? "proceso" : s.estado}">${s.estado}</span></td>
                ${tipo === "1" ? `<td style="color:var(--muted); font-size:0.82rem">${s.asignado_a || "—"}</td>` : ""}
                <td class="action-cell">
                    <div class="menu-container">
                        <button class="btn-dots" onclick="toggleActionMenu(event, ${s.id})">⋮</button>
                        <div id="menu-${s.id}" class="dropdown-actions">
                            <button onclick="verDetalles(${s.id})">Ver Detalles</button>
                            ${noResuelto ? `<button onclick="abrirEditar(${s.id}, '${s.estado}')">Editar Estado</button>` : ""}
                            ${noResuelto ? `<div class="divider"></div>` : ""}
                            ${noResuelto && !s.asignado_a ? `<button onclick="asignarme(${s.id})">Asignarme</button>` : ""}
                            ${noResuelto && !s.asignado_a && tipo === "1" ? `<button onclick="asignarA(${s.id})">Asignar a...</button>` : ""}
                            ${noResuelto ? `<button class="resolve-opt" onclick="resolver(${s.id})">Resolver</button>` : ""}
                            ${tipo === "1" ? `<div class="divider"></div><button class="delete-opt" onclick="borrarSolicitud(${s.id})">Eliminar</button>` : ""}
                        </div>
                    </div>
                </td>
            </tr>
        `;
    }).join("");
}

// ─── RECIENTES SIN ASIGNAR ────────────────────────────────────────────────────
function renderRecientes(data) {
    const sinAsignar = data.filter(s => !s.asignado_a && s.estado !== "resuelto").slice(0, 5);
    const total      = data.filter(s => !s.asignado_a && s.estado !== "resuelto").length;

    document.getElementById("recientesCount").textContent = `${total} pendientes`;

    const lista = document.getElementById("recientesLista");
    if (!sinAsignar.length) {
        lista.innerHTML = `<div class="reciente-empty">✅ Todas las solicitudes están asignadas</div>`;
        return;
    }
    lista.innerHTML = sinAsignar.map(s => `
        <div class="reciente-item">
            <div class="reciente-info">
                <span class="reciente-cliente">${s.cliente}</span>
                <span class="reciente-meta">${s.tipo_soporte} · ${formatFecha(s.fecha_reporte)}</span>
            </div>
            <div class="reciente-right">
                <span class="badge badge-${s.prioridad}">${s.prioridad}</span>
                <button class="btn-action" onclick="verDetalles(${s.id})">Ver Detalles</button>
                <button class="btn-action resolve" onclick="asignarme(${s.id})">Asignarme</button>
            </div>
        </div>
    `).join("");
}

// ─── FILTROS ──────────────────────────────────────────────────────────────────
let filtroEstadoActual    = "todos";
let filtroPrioridadActual = "todos";
let filtroTipoActual      = "todos";

function filtrarTabla() { aplicarFiltros(); }

function limpiarFechas() {
    document.getElementById("filtroDesde").value = "";
    document.getElementById("filtroHasta").value = "";
    aplicarFiltros();
}

function aplicarFiltros() {
    const q     = document.getElementById("searchInput").value.toLowerCase();
    const desde = document.getElementById("filtroDesde").value;
    const hasta = document.getElementById("filtroHasta").value;
    let filtrado = solicitudesData;

    if (filtroEstadoActual !== "todos")
        filtrado = filtrado.filter((s) => s.estado === filtroEstadoActual);
    if (filtroPrioridadActual !== "todos")
        filtrado = filtrado.filter((s) => s.prioridad === filtroPrioridadActual);
    if (filtroTipoActual !== "todos")
        filtrado = filtrado.filter((s) => s.tipo_soporte === filtroTipoActual);
    if (desde)
        filtrado = filtrado.filter((s) => s.fecha_reporte && new Date(s.fecha_reporte) >= new Date(desde));
    if (hasta) {
        filtrado = filtrado.filter((s) => {
            if (!s.fecha_reporte) return false;
            const hastaFin = new Date(hasta);
            hastaFin.setDate(hastaFin.getDate() + 1);
            return new Date(s.fecha_reporte) < hastaFin;
        });
    }
    if (q)
        filtrado = filtrado.filter((s) =>
            s.cliente.toLowerCase().includes(q) ||
            (s.persona_reporta || "").toLowerCase().includes(q)
        );

    renderTabla(filtrado);
}

function toggleDropdown() {
    document.getElementById("filtroOptions").classList.toggle("open");
    document.getElementById("filtroOptionsPrioridad").classList.remove("open");
    document.getElementById("tipoOptions").classList.remove("open");
}
function seleccionarFiltro(valor, label) {
    document.getElementById("filtroLabel").textContent = label;
    document.getElementById("filtroOptions").classList.remove("open");
    filtroEstadoActual = valor;
    aplicarFiltros();
}
function toggleDropdownPrioridad() {
    document.getElementById("filtroOptionsPrioridad").classList.toggle("open");
    document.getElementById("filtroOptions").classList.remove("open");
    document.getElementById("tipoOptions").classList.remove("open");
}
function seleccionarFiltroPrioridad(valor, label) {
    document.getElementById("filtroLabelPrioridad").textContent = label;
    document.getElementById("filtroOptionsPrioridad").classList.remove("open");
    filtroPrioridadActual = valor;
    aplicarFiltros();
}
function toggleDropdownTipo() {
    document.getElementById("tipoOptions").classList.toggle("open");
    document.getElementById("filtroOptions").classList.remove("open");
    document.getElementById("filtroOptionsPrioridad").classList.remove("open");
}
function seleccionarFiltroTipo(valor, label) {
    document.getElementById("tipoLabel").textContent = label;
    document.getElementById("tipoOptions").classList.remove("open");
    filtroTipoActual = valor;
    aplicarFiltros();
}
document.addEventListener("click", function (e) {
    if (!e.target.closest(".custom-select")) {
        document.getElementById("filtroOptions").classList.remove("open");
        document.getElementById("filtroOptionsPrioridad").classList.remove("open");
        document.getElementById("tipoOptions").classList.remove("open");
    }
});

// ─── DROPDOWN ACCIONES ────────────────────────────────────────────────────────
function toggleActionMenu(event, id) {
    event.stopPropagation();
    document.querySelectorAll(".dropdown-actions.show").forEach(menu => {
        if (menu.id !== `menu-${id}`) menu.classList.remove("show");
    });
    document.getElementById(`menu-${id}`).classList.toggle("show");
}
window.addEventListener("click", function (e) {
    if (!e.target.closest(".btn-dots")) {
        document.querySelectorAll(".dropdown-actions").forEach(menu => menu.classList.remove("show"));
    }
});

// ─── VER DETALLES ─────────────────────────────────────────────────────────────
function verDetalles(id) {
    const s = solicitudesData.find((s) => s.id === id);
    if (!s) { showToast("Solicitud no encontrada", "error"); return; }

    const estadoBadge = s.estado === "en proceso" ? "proceso" : s.estado;
    document.getElementById("modal-detalles").innerHTML = `
        <div class="detalle-grid">
            <div class="detalle-item">
                <span class="detalle-label">ID</span>
                <span class="detalle-valor">#${s.id}</span>
            </div>
            <div class="detalle-item">
                <span class="detalle-label">Estado</span>
                <span class="badge badge-${estadoBadge}">${s.estado}</span>
            </div>
            <div class="detalle-item">
                <span class="detalle-label">Cliente</span>
                <span class="detalle-valor">${s.cliente}</span>
            </div>
            <div class="detalle-item">
                <span class="detalle-label">Reportado por</span>
                <span class="detalle-valor">${s.persona_reporta || "—"}</span>
            </div>
            <div class="detalle-item">
                <span class="detalle-label">Tipo de soporte</span>
                <span class="detalle-valor">${s.tipo_soporte}</span>
            </div>
            <div class="detalle-item">
                <span class="detalle-label">Prioridad</span>
                <span class="badge badge-${s.prioridad}">${s.prioridad}</span>
            </div>
            <div class="detalle-item">
                <span class="detalle-label">Fecha de reporte</span>
                <span class="detalle-valor">${formatFecha(s.fecha_reporte)}</span>
            </div>
            <div class="detalle-item">
                <span class="detalle-label">Fecha resuelta</span>
                <span class="detalle-valor">${formatFecha(s.fecha_resuelto)}</span>
            </div>
            ${s.asignado_a ? `
            <div class="detalle-item full">
                <span class="detalle-label">Asignado a</span>
                <span class="detalle-valor">${s.asignado_a}</span>
            </div>` : ""}
            <div class="detalle-item full">
                <span class="detalle-label">Descripción</span>
                <span class="detalle-valor detalle-desc">${s.descripcion || "—"}</span>
            </div>
        </div>
    `;
    document.getElementById("modalDetalles").classList.add("open");
}
function cerrarModalDetalles() {
    document.getElementById("modalDetalles").classList.remove("open");
}

// ─── ASIGNAR ──────────────────────────────────────────────────────────────────
async function asignarme(id) {
    try {
        const res = await apiFetch("/api/asignar/" + id, {
            method: "PUT",
            body: JSON.stringify({ asignado_a: nombre }),
        });
        if (!res) return;
        if (res.ok) { showToast("Solicitud asignada ✓", "success"); cargarSolicitudes(); }
        else { const d = await res.json(); showToast(d.error || "Error al asignar", "error"); }
    } catch (e) { showToast("Error de conexión", "error"); }
}

async function asignarA(id) {
    asignandoId = id;
    try {
        const res = await apiFetch("/api/usuarios");
        if (!res) return;
        const data = await res.json();
        const select = document.getElementById("modal-usuario-asignar");
        select.innerHTML = (data.usuarios || [])
            .map(u => `<option value="${u.nombre}">${u.nombre} (${u.tipo == 1 ? 'Admin' : 'Empleado'})</option>`)
            .join('');
        document.getElementById("modalAsignar").classList.add("open");
    } catch (e) { showToast("Error al cargar usuarios", "error"); }
}

function cerrarModalAsignar() {
    document.getElementById("modalAsignar").classList.remove("open");
    asignandoId = null;
}

async function confirmarAsignar() {
    const usuario = document.getElementById("modal-usuario-asignar").value;
    if (!usuario) return;
    try {
        const res = await apiFetch(`/api/asignar/${asignandoId}`, {
            method: "PUT",
            body: JSON.stringify({ asignado_a: usuario }),
        });
        if (!res) return;
        if (res.ok) {
            showToast(`Asignado a ${usuario} ✓`, "success");
            cerrarModalAsignar();
            cargarSolicitudes();
        } else {
            const d = await res.json();
            showToast(d.error || "Error al asignar", "error");
        }
    } catch (e) { showToast("Error de conexión", "error"); }
}

// ─── RESOLVER ─────────────────────────────────────────────────────────────────
async function resolver(id) {
    try {
        const res = await apiFetch(`/api/resolver/${id}`, {
            method: "PUT",
            body: JSON.stringify({ asignado_a: nombre }),
        });
        if (!res) return;
        if (res.ok) {
            showToast("Solicitud marcada como resuelta ✓", "success");
            cargarSolicitudes();
            const secMis = document.getElementById("sec-mis-solicitudes");
            if (secMis && secMis.classList.contains("active")) cargarMisSolicitudes();
        } else {
            const d = await res.json();
            showToast(d.error || "Error al resolver", "error");
        }
    } catch (e) { showToast("Error de conexión", "error"); }
}

// ─── MODAL EDITAR ESTADO ──────────────────────────────────────────────────────
function abrirEditar(id, estadoActual) {
    editandoId = id;
    document.getElementById("modal-estado").value = estadoActual;
    document.getElementById("modalEditar").classList.add("open");
}
function cerrarModal() {
    document.getElementById("modalEditar").classList.remove("open");
    editandoId = null;
}
async function guardarEdicion() {
    const estado = document.getElementById("modal-estado").value;
    try {
        const res = await apiFetch(`/api/editar_solicitud/${editandoId}`, {
            method: "PUT",
            body: JSON.stringify({ estado }),
        });
        if (!res) return;
        if (res.ok) {
            showToast("Estado actualizado ✓", "success");
            cerrarModal();
            cargarSolicitudes();
            const secMis = document.getElementById("sec-mis-solicitudes");
            if (secMis && secMis.classList.contains("active")) cargarMisSolicitudes();
        } else {
            showToast("Error al actualizar", "error");
        }
    } catch (e) { showToast("Error de conexión", "error"); }
}

// ─── AUDITORÍA ────────────────────────────────────────────────────────────────
const etiquetas = {
    crear_solicitud:  "🟢 Crear solicitud",
    editar_estado:    "🔵 Editar estado",
    asignar:          "🟡 Asignar",
    resolver:         "✅ Resolver",
    eliminar:         "🔴 Eliminar solicitud",
    crear_usuario:    "🟢 Crear usuario",
    eliminar_usuario: "🔴 Eliminar usuario",
};

async function cargarAuditoria() {
    const lista = document.getElementById("auditoriaLista");
    try {
        const res = await apiFetch("/api/auditoria");
        if (!res) return;
        const data = await res.json();
        const registros = data.registros || [];

        document.getElementById("auditoriaCount").textContent = `${registros.length} registros`;

        if (!registros.length) {
            lista.innerHTML = `<div class="reciente-empty">📭 Sin registros de auditoría</div>`;
            return;
        }

        lista.innerHTML = registros.map(r => `
            <div class="reciente-item">
                <div class="reciente-info">
                    <span class="reciente-cliente">${etiquetas[r.accion] || r.accion} — Solicitud #${r.id_solicitud || '—'}</span>
                    <span class="reciente-meta">${r.detalle || ''}</span>
                </div>
                <div class="reciente-right">
                    <span style="color:var(--muted); font-size:0.8rem">${r.usuario}</span>
                    <span style="color:var(--muted); font-size:0.8rem">${formatFecha(r.fecha)}</span>
                </div>
            </div>
        `).join('');
    } catch (e) {
        lista.innerHTML = `<div class="reciente-empty">❌ Error al cargar auditoría</div>`;
    }
}

// ─── TOAST ────────────────────────────────────────────────────────────────────
function showToast(msg, type = "success") {
    const t = document.getElementById("toast");
    t.textContent = msg;
    t.className = `toast ${type} show`;
    setTimeout(() => t.classList.remove("show"), 3000);
}

// ─── LOGOUT ───────────────────────────────────────────────────────────────────
function logout() {
    localStorage.clear();
    window.location.href = "/login";
}

// ─── INIT ─────────────────────────────────────────────────────────────────────
document.getElementById("f-fecha").valueAsDate = new Date();

document.getElementById("modalEditar").addEventListener("click", function (e) {
    if (e.target === this) cerrarModal();
});
document.getElementById("modalDetalles").addEventListener("click", function (e) {
    if (e.target === this) cerrarModalDetalles();
});
document.getElementById("modalAsignar").addEventListener("click", function (e) {
    if (e.target === this) cerrarModalAsignar();
});

cargarSolicitudes();
// Al final del INIT, después de cargarSolicitudes()
if (tipo !== "1") {
    document.querySelectorAll("th").forEach(th => {
        if (th.textContent.trim() === "Asignado a") th.style.display = "none";
    });
}
// ─── NOTIFICACIONES (BD) ─────────────────────────────────────────────────────
// Las notificaciones se leen desde la tabla `notificaciones` en la BD.
// El backend inserta una fila cada vez que se asigna una solicitud.
// El frontend hace polling ligero cada 15s solo a esa tabla.

let notifPanelAbierto = false;

if ("Notification" in window && Notification.permission === "default") {
    Notification.requestPermission();
}

async function cargarNotificaciones() {
    try {
        const res = await apiFetch("/api/notificaciones");
        if (!res) return;
        const data = await res.json();
        const notifs = data.notificaciones || [];

        const noLeidas = notifs.filter(n => !n.leida).length;
        actualizarBadge(noLeidas);
        renderNotifPanel(notifs);

        // Notificación nativa solo por las nuevas no leídas
        notifs.filter(n => !n.leida).forEach(n => {
            if ("Notification" in window && Notification.permission === "granted") {
                const notif = new Notification("Nueva solicitud asignada", {
                    body: n.mensaje,
                    tag:  "notif-" + n.id,
                });
                notif.onclick = () => { window.focus(); notif.close(); };
                setTimeout(() => notif.close(), 6000);
            }
        });
    } catch (e) {}
}

async function limpiarNotificaciones() {
    await apiFetch("/api/notificaciones/limpiar", { method: "DELETE" });
    document.getElementById("notifLista").innerHTML =
        `<div class="notif-empty">Sin notificaciones nuevas</div>`;
    actualizarBadge(0);
}

function toggleNotifPanel() {
    notifPanelAbierto = !notifPanelAbierto;
    document.getElementById("notifPanel").classList.toggle("open", notifPanelAbierto);
    if (notifPanelAbierto) {
        actualizarBadge(0);
        apiFetch("/api/notificaciones/marcar-leidas", { method: "PUT" });
    }
}

function cerrarNotifPanel() {
    notifPanelAbierto = false;
    document.getElementById("notifPanel").classList.remove("open");
}


function actualizarBadge(cantidad) {
    const badge = document.getElementById("notifBadge");
    const btn   = document.getElementById("notifBtn");
    if (cantidad > 0) {
        badge.textContent = cantidad > 99 ? "99+" : cantidad;
        badge.style.display = "flex";
        btn.classList.add("has-notif");
    } else {
        badge.style.display = "none";
        btn.classList.remove("has-notif");
    }
}

function renderNotifPanel(notifs) {
    const lista = document.getElementById("notifLista");
    if (!notifs || !notifs.length) {
        lista.innerHTML = `<div class="notif-empty">Sin notificaciones nuevas</div>`;
        return;
    }
    lista.innerHTML = notifs.map(n => `
        <div class="notif-item ${n.leida ? '' : 'no-leida'}" onclick="irASolicitud(${n.id_solicitud})">
            <div class="notif-dot ${n.leida ? '' : 'asignada'}"></div>
            <div class="notif-item-body">
                <div class="notif-item-titulo">${n.mensaje}</div>
                <div class="notif-item-meta">${formatFecha(n.fecha)}</div>
            </div>
        </div>
    `).join("");
}

function irASolicitud(id) {
    cerrarNotifPanel();
    const linkSolicitudes = document.querySelector(".sidenav-link");
    if (linkSolicitudes) switchSection("solicitudes", linkSolicitudes);
    cargarSolicitudes().then(() => {
        setTimeout(() => {
            document.querySelectorAll("#tablaSolicitudes tr").forEach(tr => {
                if (tr.textContent.includes(`#${id}`)) {
                    tr.style.transition = "background 0.4s";
                    tr.style.background = "rgba(124,106,247,0.15)";
                    tr.scrollIntoView({ behavior: "smooth", block: "center" });
                    setTimeout(() => tr.style.background = "", 2500);
                }
            });
        }, 400);
    });
}

// Cerrar panel al hacer click fuera
document.addEventListener("click", function(e) {
    if (notifPanelAbierto && !e.target.closest("#notifWrapper")) {
        cerrarNotifPanel();
    }
});

// Cargar al abrir y luego cada 15 segundos
cargarNotificaciones();
setInterval(cargarNotificaciones, 15000);