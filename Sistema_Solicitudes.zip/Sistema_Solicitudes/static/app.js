const token  = localStorage.getItem("token");
const nombre = localStorage.getItem("nombre");
const tipo   = localStorage.getItem("tipo");

// Redirigir si no hay sesión
if (!token) window.location.href = "/login";

// Mostrar nombre y rol en sidenav
if (nombre) {
    document.getElementById("nombreAdmin").textContent = nombre;
    document.getElementById("avatarInitial").textContent = nombre.charAt(0).toUpperCase();
}
const roles = { "1": "Administrador", "2": "Empleado" };
const rolEl = document.querySelector(".user-role");
if (rolEl) rolEl.textContent = roles[tipo] || "Empleado";

// Ocultar secciones si no es admin
if (tipo !== "1") {
    document.querySelectorAll(".sidenav-link").forEach((link) => {
        const texto = link.querySelector("span")?.textContent.trim();
        if (["Usuarios", "Reportes", "Configuración"].includes(texto)) {
            link.style.display = "none";
        }
    });
}

let solicitudesData = [];
let editandoId = null;

// ─── SIDENAV ──────────────────────────────────────────────────────────────────
function toggleSidenav() {
    document.getElementById("sidenav").classList.toggle("collapsed");
}

const sectionTitles = {
    solicitudes:   "Solicitudes",
    usuarios:      "Usuarios",
    reportes:      "Reportes",
    configuracion: "Configuración",
    "mis-solicitudes": "Mis Solicitudes",
};

function switchSection(name, btn) {
    document.querySelectorAll(".page-section").forEach((s) => s.classList.remove("active"));
    document.querySelectorAll(".sidenav-link").forEach((l) => l.classList.remove("active"));
    document.getElementById("sec-" + name).classList.add("active");
    btn.classList.add("active");
    document.getElementById("topbarTitle").textContent = sectionTitles[name];

    if (name === "mis-solicitudes") cargarMisSolicitudes();
}

// ─── TABS ─────────────────────────────────────────────────────────────────────
function switchTab(name, btn) {
    document.querySelectorAll(".sub-section").forEach((s) => s.classList.remove("active"));
    document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
    document.getElementById("sec-" + name).classList.add("active");
    btn.classList.add("active");
}

// ─── CARGAR SOLICITUDES ───────────────────────────────────────────────────────
async function cargarSolicitudes() {
    try {
        const res = await fetch("/api/solicitudes", {
            headers: { "Authorization": "Bearer " + token }
        });
        const data = await res.json();
        solicitudesData = data.registros || [];
        renderTabla(solicitudesData);
        actualizarStats(solicitudesData);
        renderRecientes(solicitudesData);
    } catch (e) {
        document.getElementById("tablaSolicitudes").innerHTML =
            `<tr><td colspan="8"><div class="empty-state"><div class="icon">❌</div>Error al cargar datos</div></td></tr>`;
    }
}

// ─── STATS ────────────────────────────────────────────────────────────────────
function actualizarStats(data) {
    document.getElementById("statTotal").textContent     = data.length;
    document.getElementById("statPendiente").textContent = data.filter((s) => s.estado === "pendiente").length;
    document.getElementById("statResuelto").textContent  = data.filter((s) => s.estado === "resuelto").length;
    document.getElementById("statProceso").textContent   = data.filter((s) => s.estado === "en proceso").length;
}

// ─── TABLA ────────────────────────────────────────────────────────────────────
function formatFecha(fecha) {
    if (!fecha) return "—";
    return new Date(fecha).toLocaleDateString("es-CO", {
        day: "2-digit", month: "short", year: "numeric",
    });
}

function renderTabla(data) {
    const tbody = document.getElementById("tablaSolicitudes");
    if (!data.length) {
        tbody.innerHTML = `<tr><td colspan="8"><div class="empty-state"><div class="icon">📭</div>No hay solicitudes</div></td></tr>`;
        return;
    }
    tbody.innerHTML = data.map((s) => {
        const noResuelto = s.estado !== "resuelto";
        return `
            <tr>
                <td style="color:var(--muted)">#${s.id}</td>
                <td><strong>${s.cliente}</strong></td>
                <td>${s.persona_reporta}</td>
                <td>${s.tipo_soporte}</td>
                <td><span class="badge badge-${s.prioridad}">${s.prioridad}</span></td>
                <td><span class="badge badge-${s.estado === "en proceso" ? "proceso" : s.estado}">${s.estado}</span></td>
                <td style="color:var(--muted); font-size:0.82rem">${s.asignado_a || "—"}</td>
                <td class="action-cell">
                    <div class="menu-container">
                        <button class="btn-dots" onclick="toggleActionMenu(event, ${s.id})">⋮</button>
                        <div id="menu-${s.id}" class="dropdown-actions">
                            <button onclick="verDetalles(${s.id})">Ver Detalles</button>
                            <button onclick="abrirEditar(${s.id}, '${s.estado}')">Editar Estado</button>
                            ${noResuelto ? `
                                <div class="divider"></div>
                                ${!s.asignado_a ? `<button onclick="asignarme(${s.id})">Asignarme</button>` : ""}
                                ${tipo === "1" ? `<button onclick="asignarA(${s.id})">Asignar a...</button>` : ""}
                                <button class="resolve-opt" onclick="resolver(${s.id})">Resolver</button>
                            ` : ""}
                            ${tipo === "1" ? `
                                <div class="divider"></div>
                                <button class="delete-opt" onclick="borrarSolicitud(${s.id})">Eliminar</button>
                            ` : ""}
                        </div>
                    </div>
                </td>
            </tr>
        `;
    }).join("");
}

// ─── RECIENTES SIN ASIGNAR ────────────────────────────────────────────────────
function renderRecientes(data) {
    const sinAsignar = data.filter(s => !s.asignado_a && s.estado !== "resuelto").slice(0, 5);
    const total = data.filter(s => !s.asignado_a && s.estado !== "resuelto").length;

    document.getElementById("recientesCount").textContent = `${total} pendientes`;

    const lista = document.getElementById("recientesLista");
    if (!sinAsignar.length) {
        lista.innerHTML = `<div class="reciente-empty">✅ Todas las solicitudes están asignadas</div>`;
        return;
    }
    lista.innerHTML = sinAsignar.map(s => `
        <div class="reciente-item">
            <div class="reciente-info">
                <span class="reciente-cliente">${s.cliente}</span>
                <span class="reciente-meta">${s.tipo_soporte} · ${formatFecha(s.fecha_reporte)}</span>
            </div>
            <div class="reciente-right">
                <span class="badge badge-${s.prioridad}">${s.prioridad}</span>
                <button class="btn-action resolve" onclick="verDetalles(${s.id})">Ver Detalles</button>
                <button class="btn-action resolve" onclick="asignarme(${s.id})">Asignarme</button>
            </div>
        </div>
    `).join("");
}

// ─── FILTROS ──────────────────────────────────────────────────────────────────
let filtroEstadoActual    = "todos";
let filtroPrioridadActual = "todos";
let filtroTipoActual      = "todos";

function filtrarTabla() { aplicarFiltros(); }

function limpiarFechas() {
    document.getElementById("filtroDesde").value = "";
    document.getElementById("filtroHasta").value = "";
    aplicarFiltros();
}

function aplicarFiltros() {
    const q     = document.getElementById("searchInput").value.toLowerCase();
    const desde = document.getElementById("filtroDesde").value;
    const hasta = document.getElementById("filtroHasta").value;
    let filtrado = solicitudesData;

    if (filtroEstadoActual !== "todos")
        filtrado = filtrado.filter((s) => s.estado === filtroEstadoActual);
    if (filtroPrioridadActual !== "todos")
        filtrado = filtrado.filter((s) => s.prioridad === filtroPrioridadActual);
    if (filtroTipoActual !== "todos")
        filtrado = filtrado.filter((s) => s.tipo_soporte === filtroTipoActual);

    if (desde)
        filtrado = filtrado.filter((s) => {
            if (!s.fecha_reporte) return false;
            return new Date(s.fecha_reporte) >= new Date(desde);
        });
    if (hasta)
        filtrado = filtrado.filter((s) => {
            if (!s.fecha_reporte) return false;
            const hastaFin = new Date(hasta);
            hastaFin.setDate(hastaFin.getDate() + 1);
            return new Date(s.fecha_reporte) < hastaFin;
        });

    if (q)
        filtrado = filtrado.filter((s) =>
            s.cliente.toLowerCase().includes(q) ||
            s.persona_reporta.toLowerCase().includes(q)
        );

    renderTabla(filtrado);
}

// Dropdowns filtros
function toggleDropdown() {
    document.getElementById("filtroOptions").classList.toggle("open");
    document.getElementById("filtroOptionsPrioridad").classList.remove("open");
    document.getElementById("tipoOptions").classList.remove("open");
}
function seleccionarFiltro(valor, label) {
    document.getElementById("filtroLabel").textContent = label;
    document.getElementById("filtroOptions").classList.remove("open");
    filtroEstadoActual = valor;
    aplicarFiltros();
}
function toggleDropdownPrioridad() {
    document.getElementById("filtroOptionsPrioridad").classList.toggle("open");
    document.getElementById("filtroOptions").classList.remove("open");
    document.getElementById("tipoOptions").classList.remove("open");
}
function seleccionarFiltroPrioridad(valor, label) {
    document.getElementById("filtroLabelPrioridad").textContent = label;
    document.getElementById("filtroOptionsPrioridad").classList.remove("open");
    filtroPrioridadActual = valor;
    aplicarFiltros();
}
function toggleDropdownTipo() {
    document.getElementById("tipoOptions").classList.toggle("open");
    document.getElementById("filtroOptions").classList.remove("open");
    document.getElementById("filtroOptionsPrioridad").classList.remove("open");
}
function seleccionarFiltroTipo(valor, label) {
    document.getElementById("tipoLabel").textContent = label;
    document.getElementById("tipoOptions").classList.remove("open");
    filtroTipoActual = valor;
    aplicarFiltros();
}

// Cerrar dropdowns al click fuera
document.addEventListener("click", function (e) {
    if (!e.target.closest(".custom-select")) {
        document.getElementById("filtroOptions").classList.remove("open");
        document.getElementById("filtroOptionsPrioridad").classList.remove("open");
        document.getElementById("tipoOptions").classList.remove("open");
    }
});

// ─── DROPDOWN ACCIONES ────────────────────────────────────────────────────────
function toggleActionMenu(event, id) {
    event.stopPropagation();
    document.querySelectorAll(".dropdown-actions.show").forEach(menu => {
        if (menu.id !== `menu-${id}`) menu.classList.remove("show");
    });
    document.getElementById(`menu-${id}`).classList.toggle("show");
}

window.addEventListener("click", function (e) {
    if (!e.target.closest(".btn-dots")) {
        document.querySelectorAll(".dropdown-actions").forEach(menu => menu.classList.remove("show"));
    }
});

// ─── VER DETALLES ─────────────────────────────────────────────────────────────
function verDetalles(id) {
    const s = solicitudesData.find((s) => s.id === id);
    if (!s) { showToast("Solicitud no encontrada", "error"); return; }

    const estadoBadge = s.estado === "en proceso" ? "proceso" : s.estado;
    document.getElementById("modal-detalles").innerHTML = `
        <div class="detalle-grid">
            <div class="detalle-item">
                <span class="detalle-label">ID</span>
                <span class="detalle-valor">#${s.id}</span>
            </div>
            <div class="detalle-item">
                <span class="detalle-label">Estado</span>
                <span class="badge badge-${estadoBadge}">${s.estado}</span>
            </div>
            <div class="detalle-item">
                <span class="detalle-label">Cliente</span>
                <span class="detalle-valor">${s.cliente}</span>
            </div>
            <div class="detalle-item">
                <span class="detalle-label">Reportado por</span>
                <span class="detalle-valor">${s.persona_reporta}</span>
            </div>
            <div class="detalle-item">
                <span class="detalle-label">Tipo de soporte</span>
                <span class="detalle-valor">${s.tipo_soporte}</span>
            </div>
            <div class="detalle-item">
                <span class="detalle-label">Prioridad</span>
                <span class="badge badge-${s.prioridad}">${s.prioridad}</span>
            </div>
            <div class="detalle-item">
                <span class="detalle-label">Fecha de reporte</span>
                <span class="detalle-valor">${formatFecha(s.fecha_reporte)}</span>
            </div>
            <div class="detalle-item">
                <span class="detalle-label">Fecha resuelta</span>
                <span class="detalle-valor">${formatFecha(s.fecha_resuelto)}</span>
            </div>
            ${s.asignado_a ? `
            <div class="detalle-item full">
                <span class="detalle-label">Asignado a</span>
                <span class="detalle-valor">${s.asignado_a}</span>
            </div>` : ""}
            <div class="detalle-item full">
                <span class="detalle-label">Descripción</span>
                <span class="detalle-valor detalle-desc">${s.descripcion || "—"}</span>
            </div>
        </div>
    `;
    document.getElementById("modalDetalles").classList.add("open");
}
function cerrarModalDetalles() {
    document.getElementById("modalDetalles").classList.remove("open");
}

// ─── ASIGNAR ──────────────────────────────────────────────────────────────────
async function asignarme(id) {
    try {
        const res = await fetch(`/api/asignar/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json", "Authorization": "Bearer " + token },
            body: JSON.stringify({ asignado_a: nombre }),
        });
        if (res.ok) { showToast("Solicitud asignada ✓", "success"); cargarSolicitudes(); }
        else { const d = await res.json(); showToast(d.error || "Error al asignar", "error"); }
    } catch (e) { showToast("Error de conexión", "error"); }
}

async function asignarA(id) {
    const usuario = prompt("Nombre del usuario a asignar:");
    if (!usuario) return;
    try {
        const res = await fetch(`/api/asignar/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json", "Authorization": "Bearer " + token },
            body: JSON.stringify({ asignado_a: usuario }),
        });
        if (res.ok) { showToast(`Asignado a ${usuario} ✓`, "success"); cargarSolicitudes(); }
        else { const d = await res.json(); showToast(d.error || "Error al asignar", "error"); }
    } catch (e) { showToast("Error de conexión", "error"); }
}

// ─── RESOLVER ─────────────────────────────────────────────────────────────────
async function resolver(id) {
    try {
        const res = await fetch(`/api/resolver/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json", "Authorization": "Bearer " + token },
            body: JSON.stringify({ asignado_a: nombre }),
        });
        if (res.ok) { showToast("Solicitud marcada como resuelta ✓", "success"); cargarSolicitudes(); }
        else { const d = await res.json(); showToast(d.error || "Error al resolver", "error"); }
    } catch (e) { showToast("Error de conexión", "error"); }
}

// ─── BORRAR ───────────────────────────────────────────────────────────────────
async function borrarSolicitud(id) {
    try {
        const res = await fetch(`/api/solicitudes/${id}`, {
            method: "DELETE",
            headers: { "Authorization": "Bearer " + token },
        });
        if (res.ok) { showToast("Solicitud eliminada ✓", "success"); cargarSolicitudes(); }
        else { showToast("Error al eliminar", "error"); }
    } catch (e) { showToast("Error de conexión", "error"); }
}

// ─── MODAL EDITAR ─────────────────────────────────────────────────────────────
function abrirEditar(id, estadoActual) {
    editandoId = id;
    document.getElementById("modal-estado").value = estadoActual;
    document.getElementById("modalEditar").classList.add("open");
}
function cerrarModal() {
    document.getElementById("modalEditar").classList.remove("open");
    editandoId = null;
}
async function guardarEdicion() {
    const estado = document.getElementById("modal-estado").value;
    try {
        const res = await fetch(`/api/editar_solicitud/${editandoId}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json", "Authorization": "Bearer " + token },
            body: JSON.stringify({ estado }),
        });
        
        if (res.ok) { showToast("Estado actualizado ✓", "success"); cerrarModal(); cargarSolicitudes(); }
        else { showToast("Error al actualizar", "error"); }
    } catch (e) { showToast("Error de conexión", "error"); }
}

// ─── CREAR SOLICITUD ──────────────────────────────────────────────────────────
async function crearSolicitud(nombre) {
    const body = {
        cliente:         document.getElementById("f-cliente").value.trim(),
        persona_reporta: nombre,
        tipo_soporte:    document.getElementById("f-tipo").value,
        prioridad:       document.getElementById("f-prioridad").value,
        fecha_reporte:   document.getElementById("f-fecha").value,
        estado:          document.getElementById("f-estado").value,
        descripcion:     document.getElementById("f-descripcion").value.trim(),
    };

    if (!body.cliente || !body.tipo_soporte || !body.prioridad || !body.fecha_reporte) {
        showToast("Completa todos los campos obligatorios", "error");
        return;
    }

    try {
        const res = await fetch("/api/solicitudes", {
            method: "POST",
            headers: { "Content-Type": "application/json", "Authorization": "Bearer " + token },
            body: JSON.stringify(body),
        });
        if (res.ok) {
            showToast("Solicitud creada exitosamente ✓", "success");
            ["f-cliente", "f-descripcion"].forEach((id) => (document.getElementById(id).value = ""));
            ["f-tipo", "f-prioridad"].forEach((id) => (document.getElementById(id).value = ""));
            document.getElementById("f-fecha").valueAsDate = new Date();
            switchTab("lista", document.querySelector(".tab"));
            cargarSolicitudes();
        } else {
            const d = await res.json();
            showToast(d.error || "Error al crear", "error");
        }
    } catch (e) { showToast("Error de conexión", "error"); }
}

// ─── TOAST ────────────────────────────────────────────────────────────────────
function showToast(msg, type = "success") {
    const t = document.getElementById("toast");
    t.textContent = msg;
    t.className = `toast ${type} show`;
    setTimeout(() => t.classList.remove("show"), 3000);
}

// ─── LOGOUT ───────────────────────────────────────────────────────────────────
function logout() {
    localStorage.clear();
    window.location.href = "/login";
}

// ─── INIT ─────────────────────────────────────────────────────────────────────
document.getElementById("f-fecha").valueAsDate = new Date();

document.getElementById("modalEditar").addEventListener("click", function (e) {
    if (e.target === this) cerrarModal();
});
document.getElementById("modalDetalles").addEventListener("click", function (e) {
    if (e.target === this) cerrarModalDetalles();
});

cargarSolicitudes();

async function cargarMisSolicitudes() {
    // Referencia al contenedor de la lista en tu HTML
    const lista = document.getElementById("misSolicitudesLista");
    
    try {
        const res = await fetch("/api/mis-solicitudes", {
            headers: { "Authorization": "Bearer " + token }
        });
        const data = await res.json();
        
        // RECUERDA: En Python usamos "solicitudes"
        const misFilas = data.solicitudes || []; 
        
        // Actualizar el contador del encabezado
        document.getElementById("misSolicitudesCount").textContent = `${misFilas.length} asignadas`;

        // Si no hay nada, mostrar mensaje amigable
        if (misFilas.length === 0) {
            lista.innerHTML = `<div class="reciente-empty">✅ No tienes solicitudes asignadas actualmente.</div>`;
            return;
        }

        // Renderizar usando el estilo de tarjetas (divs) que ya tienes definido
        lista.innerHTML = misFilas.map(s => `
            <div class="reciente-item">
                <div class="reciente-info">
                    <span class="reciente-cliente">${s.cliente}</span>
                    <span class="reciente-meta">${s.tipo_soporte} · ${formatFecha(s.fecha_reporte)}</span>
                </div>
                <div class="reciente-right">
                    <span class="badge badge-${s.prioridad}">${s.prioridad}</span>
                    <span class="badge badge-${s.estado === 'en proceso' ? 'proceso' : s.estado}">${s.estado}</span>
                    <button class="btn-action" onclick="verDetalles(${s.id})">Ver Detalles</button>
                    ${s.estado !== 'resuelto' ? `
                        <button class="btn-action resolve" onclick="resolver(${s.id})">Resolver</button>
                    ` : ''}
                    <button class="btn-action resolve" onclick="abrirEditar(${s.id}, '${s.estado}')">Editar Estado</button>
                </div>
            </div>
        `).join('');

    } catch (e) {
        console.error("Error:", e);
        lista.innerHTML = `<div class="reciente-empty">❌ Error al conectar con el servidor.</div>`;
    }
}

