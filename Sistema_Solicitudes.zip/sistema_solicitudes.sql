-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-03-2026 a las 21:19:37
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistema_solicitudes`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auditoria`
--

CREATE TABLE `auditoria` (
  `id` int(11) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `accion` varchar(50) NOT NULL,
  `id_solicitud` int(11) DEFAULT NULL,
  `detalle` varchar(255) DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `auditoria`
--

INSERT INTO `auditoria` (`id`, `usuario`, `accion`, `id_solicitud`, `detalle`, `fecha`) VALUES
(1, 'Administrador del Sistema', 'crear_solicitud', 21, NULL, '2026-03-12 15:09:57'),
(2, 'Administrador del Sistema', 'asignar', 21, 'asignado a: Ilder Antonio Lopez Asprilla', '2026-03-12 15:10:33'),
(3, 'Administrador del Sistema', 'eliminar', 21, NULL, '2026-03-12 15:10:55'),
(5, 'Ilder Antonio Lopez Asprilla', 'asignar', 9, 'asignado a: Ilder Antonio Lopez Asprilla', '2026-03-12 16:26:06'),
(6, 'Ilder Antonio Lopez Asprilla', 'asignar', 7, 'asignado a: Ilder Antonio Lopez Asprilla', '2026-03-12 16:26:07'),
(7, 'Sistema', 'editar_estado', 9, 'nuevo estado: en proceso', '2026-03-12 16:26:15'),
(8, 'Sistema', 'editar_estado', 9, 'nuevo estado: pendiente', '2026-03-12 16:26:18'),
(9, 'Sistema', 'editar_estado', 9, 'nuevo estado: en proceso', '2026-03-12 16:26:22'),
(10, 'Administrador del Sistema', 'asignar', 8, 'asignado a: Administrador del Sistema', '2026-03-16 12:13:33'),
(11, 'Administrador del Sistema', 'crear_usuario', NULL, 'usuario creado: il', '2026-03-16 14:32:11'),
(12, 'Administrador del Sistema', 'crear_usuario', NULL, 'usuario creado: lop', '2026-03-16 14:32:36'),
(13, 'Administrador del Sistema', 'eliminar_usuario', NULL, 'usuario eliminado: anto (Antonio Asprilla)', '2026-03-16 14:53:49'),
(14, 'Administrador del Sistema', 'resolver', 8, NULL, '2026-03-16 16:00:33'),
(15, 'Administrador del Sistema', 'asignar', 6, 'asignado a: Administrador del Sistema', '2026-03-16 16:00:44'),
(16, 'Sistema', 'editar_estado', 6, 'nuevo estado: en proceso', '2026-03-16 16:00:52'),
(17, 'Ilder', 'crear_solicitud', 22, NULL, '2026-03-18 10:08:42'),
(18, 'Ilder', 'asignar', 2, 'asignado a: Ilder', '2026-03-18 10:09:02'),
(19, 'Ilder', 'resolver', 10, NULL, '2026-03-18 10:09:06'),
(20, 'Administrador del Sistema', 'crear_solicitud', 23, NULL, '2026-03-18 10:19:00'),
(21, 'Administrador del Sistema', 'asignar', 22, 'asignado a: Ilder', '2026-03-18 10:19:16'),
(22, 'ilder', 'crear_solicitud', 24, NULL, '2026-03-18 10:52:23'),
(23, 'PRUEBASOFTWARE', 'crear_solicitud', 25, NULL, '2026-03-18 12:56:41'),
(24, 'Ilder', 'asignar', 25, 'auto-asignado por categoría', '2026-03-18 12:56:41'),
(25, 'Ilder', 'resolver', 25, NULL, '2026-03-18 14:09:40'),
(26, 'Ilder', 'asignar', 23, 'asignado a: Ilder', '2026-03-18 14:09:48'),
(27, 'Administrador del Sistema', 'crear_usuario', NULL, 'usuario creado: pep', '2026-03-18 14:18:58'),
(28, 'Administrador del Sistema', 'crear_solicitud', 26, NULL, '2026-03-18 14:37:42'),
(29, 'Ilder', 'asignar', 26, 'auto-asignado por categoría', '2026-03-18 14:37:42'),
(30, 'Ilder', 'editar_estado', 26, 'nuevo estado: pendiente', '2026-03-18 14:38:06'),
(31, 'Ilder', 'crear_solicitud', 27, NULL, '2026-03-18 14:38:18'),
(32, 'Ilder', 'asignar', 27, 'auto-asignado por categoría', '2026-03-18 14:38:18'),
(33, 'Administrador del Sistema', 'crear_solicitud', 28, NULL, '2026-03-18 14:48:48'),
(34, 'Ilder', 'asignar', 28, 'auto-asignado por categoría', '2026-03-18 14:48:48'),
(35, 'Ilder', 'crear_solicitud', 29, NULL, '2026-03-18 15:12:21'),
(36, 'Ilder', 'asignar', 29, 'auto-asignado por categoría', '2026-03-18 15:12:21'),
(37, 'Ilder', 'crear_solicitud', 30, NULL, '2026-03-18 15:12:39'),
(38, 'Ilder Antonio Lopez Asprilla', 'asignar', 30, 'auto-asignado por categoría', '2026-03-18 15:12:39'),
(39, 'Ilder Antonio Lopez Asprilla', 'crear_solicitud', 31, NULL, '2026-03-18 15:14:01'),
(40, 'Ilder Antonio Lopez Asprilla', 'asignar', 31, 'auto-asignado por categoría', '2026-03-18 15:14:01'),
(41, 'Ilder Antonio Lopez Asprilla', 'crear_solicitud', 32, NULL, '2026-03-18 15:14:21'),
(42, 'Ilder', 'asignar', 32, 'auto-asignado por categoría', '2026-03-18 15:14:21'),
(43, 'Ilder', 'crear_solicitud', 33, NULL, '2026-03-18 15:21:27'),
(44, 'Ilder', 'asignar', 33, 'auto-asignado por categoría', '2026-03-18 15:21:27'),
(45, 'Ilder', 'crear_solicitud', 34, NULL, '2026-03-18 15:21:38'),
(46, 'Ilder Antonio Lopez Asprilla', 'asignar', 34, 'auto-asignado por categoría', '2026-03-18 15:21:38'),
(47, 'Administrador del Sistema', 'crear_solicitud', 35, NULL, '2026-03-18 15:22:57'),
(48, 'Ilder', 'asignar', 35, 'auto-asignado por categoría', '2026-03-18 15:22:57'),
(49, 'Administrador del Sistema', 'crear_solicitud', 36, NULL, '2026-03-18 15:27:33'),
(50, 'Ilder', 'asignar', 36, 'auto-asignado por categoría', '2026-03-18 15:27:33'),
(51, 'Administrador del Sistema', 'crear_solicitud', 37, NULL, '2026-03-18 15:27:44'),
(52, 'Ilder Antonio Lopez Asprilla', 'asignar', 37, 'auto-asignado por categoría', '2026-03-18 15:27:44'),
(53, 'Ilder Antonio Lopez Asprilla', 'crear_solicitud', 38, NULL, '2026-03-18 15:34:17'),
(54, 'Ilder', 'asignar', 38, 'auto-asignado por categoría', '2026-03-18 15:34:17'),
(55, 'Ilder', 'crear_solicitud', 39, NULL, '2026-03-18 15:36:23'),
(56, 'Ilder', 'asignar', 39, 'auto-asignado por categoría', '2026-03-18 15:36:23'),
(57, 'Ilder', 'crear_solicitud', 40, NULL, '2026-03-18 15:36:30'),
(58, 'Ilder Antonio Lopez Asprilla', 'asignar', 40, 'auto-asignado por categoría', '2026-03-18 15:36:30'),
(59, 'Ilder Antonio Lopez Asprilla', 'crear_solicitud', 41, NULL, '2026-03-18 15:38:58'),
(60, 'Ilder', 'asignar', 41, 'auto-asignado por categoría', '2026-03-18 15:38:58'),
(61, 'Ilder', 'crear_solicitud', 42, NULL, '2026-03-18 15:57:49'),
(62, 'Ilder Antonio Lopez Asprilla', 'asignar', 42, 'auto-asignado por categoría', '2026-03-18 15:57:49'),
(63, 'Ilder Antonio Lopez Asprilla', 'crear_solicitud', 43, NULL, '2026-03-18 15:58:08'),
(64, 'Ilder', 'asignar', 43, 'auto-asignado por categoría', '2026-03-18 15:58:08'),
(65, 'Ilder', 'crear_solicitud', 44, NULL, '2026-03-18 15:58:29'),
(66, 'Ilder Antonio Lopez Asprilla', 'asignar', 44, 'auto-asignado por categoría', '2026-03-18 15:58:29'),
(67, 'Ilder Antonio Lopez Asprilla', 'crear_solicitud', 45, NULL, '2026-03-18 15:58:47'),
(68, 'Ilder', 'asignar', 45, 'auto-asignado por categoría', '2026-03-18 15:58:47'),
(69, 'Ilder Antonio Lopez Asprilla', 'crear_solicitud', 46, NULL, '2026-03-18 15:58:54'),
(70, 'Ilder', 'asignar', 46, 'auto-asignado por categoría', '2026-03-18 15:58:54'),
(71, 'ILDER', 'crear_solicitud', 47, NULL, '2026-03-18 15:59:37'),
(72, 'Ilder', 'asignar', 47, 'auto-asignado por categoría', '2026-03-18 15:59:37'),
(73, 'Ilder', 'crear_solicitud', 48, NULL, '2026-03-18 16:17:28'),
(74, 'Ilder', 'resolver', 47, NULL, '2026-03-18 16:39:32'),
(75, 'Ilder Antonio Lopez Asprilla', 'resolver', 37, NULL, '2026-03-18 16:42:03'),
(76, 'Pablo', 'crear_solicitud', 49, NULL, '2026-03-19 10:10:31'),
(77, 'Ilder', 'asignar', 49, 'auto-asignado por categoría', '2026-03-19 10:10:31'),
(78, 'Prueba1', 'crear_solicitud', 50, NULL, '2026-03-19 10:44:55'),
(79, 'Ilder', 'asignar', 50, 'auto-asignado por categoría', '2026-03-19 10:44:55'),
(80, 'Admin', 'crear_solicitud', 51, NULL, '2026-03-19 10:45:12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificaciones`
--

CREATE TABLE `notificaciones` (
  `id` int(11) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `id_solicitud` int(11) DEFAULT NULL,
  `mensaje` varchar(255) DEFAULT NULL,
  `leida` tinyint(1) DEFAULT 0,
  `fecha` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `notificaciones`
--

INSERT INTO `notificaciones` (`id`, `usuario`, `id_solicitud`, `mensaje`, `leida`, `fecha`) VALUES
(1, 'Ilder Antonio Lopez Asprilla', 42, 'Nueva solicitud asignada: ñda,sad (hardware · media)', 1, '2026-03-18 15:57:49'),
(3, 'Ilder Antonio Lopez Asprilla', 44, 'Nueva solicitud asignada: dfsdfdf (hardware · alta)', 1, '2026-03-18 15:58:29'),
(7, 'Ilder', 49, 'Nueva solicitud asignada: PEticion (software · baja)', 1, '2026-03-19 10:10:31'),
(8, 'Ilder', 50, 'Nueva solicitud asignada: PRueba1 (software · baja)', 1, '2026-03-19 10:44:55');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes`
--

CREATE TABLE `solicitudes` (
  `id` int(255) NOT NULL,
  `cliente` varchar(500) NOT NULL,
  `persona_reporta` varchar(255) NOT NULL,
  `tipo_soporte` varchar(500) NOT NULL,
  `descripcion` text NOT NULL,
  `prioridad` varchar(100) NOT NULL,
  `fecha_reporte` datetime NOT NULL,
  `fecha_resuelto` datetime DEFAULT NULL,
  `fecha_asignado` datetime DEFAULT NULL,
  `asignado_a` varchar(255) DEFAULT NULL,
  `estado` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `solicitudes`
--

INSERT INTO `solicitudes` (`id`, `cliente`, `persona_reporta`, `tipo_soporte`, `descripcion`, `prioridad`, `fecha_reporte`, `fecha_resuelto`, `fecha_asignado`, `asignado_a`, `estado`) VALUES
(35, 'Carplay', 'Administrador del Sistema', 'software', '', 'media', '2026-03-18 00:00:00', NULL, NULL, 'Ilder', 'pendiente'),
(36, 'pan', 'Administrador del Sistema', 'software', '', 'alta', '2026-03-18 00:00:00', NULL, NULL, 'Ilder', 'en proceso'),
(37, 'PRUEBA SOFTWARE', 'Administrador del Sistema', 'hardware', '', 'media', '2026-03-18 00:00:00', '2026-03-18 16:42:03', NULL, 'Ilder Antonio Lopez Asprilla', 'resuelto'),
(38, 'pan', 'Ilder Antonio Lopez Asprilla', 'software', '', 'alta', '2026-03-18 00:00:00', NULL, NULL, 'Ilder', 'pendiente'),
(39, 'pan', 'Ilder', 'software', '', 'alta', '2026-03-18 00:00:00', NULL, NULL, 'Ilder', 'pendiente'),
(40, 'PRUEBA SOFTWARE', 'Ilder', 'hardware', '', 'media', '2026-03-18 00:00:00', NULL, NULL, 'Ilder Antonio Lopez Asprilla', 'pendiente'),
(41, 'PRUEBA SOFTWARE252', 'Ilder Antonio Lopez Asprilla', 'software', '', 'alta', '2026-03-18 00:00:00', NULL, NULL, 'Ilder', 'pendiente'),
(42, 'ñda,sad', 'Ilder', 'hardware', '', 'media', '2026-03-18 00:00:00', NULL, NULL, 'Ilder Antonio Lopez Asprilla', 'pendiente'),
(43, 'asdsa', 'Ilder Antonio Lopez Asprilla', 'software', '', 'alta', '2026-03-18 00:00:00', NULL, NULL, 'Ilder', 'pendiente'),
(44, 'dfsdfdf', 'Ilder', 'hardware', '', 'alta', '2026-03-18 00:00:00', NULL, NULL, 'Ilder Antonio Lopez Asprilla', 'pendiente'),
(45, 'edddddddd', 'Ilder Antonio Lopez Asprilla', 'software', '', 'media', '2026-03-18 00:00:00', NULL, NULL, 'Ilder', 'pendiente'),
(46, 'aaaaaaaaa', 'Ilder Antonio Lopez Asprilla', 'software', '', 'alta', '2026-03-18 00:00:00', NULL, NULL, 'Ilder', 'pendiente'),
(47, 'NUEVA', 'ILDER', 'software', 'NUEVA', 'alta', '2026-03-18 00:00:00', '2026-03-18 16:39:32', NULL, 'Ilder', 'resuelto'),
(48, 'OTRO REPORT', 'Ilder', 'otro', 'asd', 'media', '2026-03-18 00:00:00', NULL, NULL, NULL, 'pendiente'),
(49, 'PEticion', 'Pablo', 'software', '', 'baja', '2026-03-19 00:00:00', NULL, NULL, 'Ilder', 'pendiente'),
(50, 'PRueba1', 'Prueba1', 'software', '', 'baja', '2026-03-19 00:00:00', NULL, NULL, 'Ilder', 'pendiente'),
(51, 'PruebaAdmikn', 'Admin', 'otro', '', 'alta', '2026-03-19 00:00:00', NULL, NULL, NULL, 'pendiente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(255) NOT NULL,
  `tipo` smallint(10) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `usuario` varchar(255) NOT NULL,
  `password` varchar(200) NOT NULL,
  `categoria` enum('hardware','software','visitas_tecnicas') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `tipo`, `nombre`, `usuario`, `password`, `categoria`) VALUES
(4, 1, 'Administrador del Sistema', 'admin', '$2b$10$fLxTD5VxPE3E76LOtslhkOQbSAfbUlTB0t9/idohNcghm3wY/7KqK', NULL),
(5, 2, 'Ilder Antonio Lopez Asprilla', 'Ilder15', '$2b$10$EdVXHA4pJa6lg9N4GtcRp.VSjL0Cvv3.wNd3tV6YBrQN5E/k6Kg52', 'hardware'),
(6, 2, 'Ilder', 'ilder', '$2b$10$gGQHnO4GaGwBQc6qT4FmWOw1VXph9CZlu8X8MXUn92Upgw/8zheoK', 'software'),
(10, 2, 'Pepito', 'pep', '$2b$10$P6RzOylzHXE4Yle7ikZnLuRNpuBZyMhFnA4kngQTWYL3qdmNrKlIe', 'visitas_tecnicas');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `auditoria`
--
ALTER TABLE `auditoria`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_solicitud` (`id_solicitud`);

--
-- Indices de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `resuelto_por` (`asignado_a`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario` (`usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `auditoria`
--
ALTER TABLE `auditoria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`id_solicitud`) REFERENCES `solicitudes` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
