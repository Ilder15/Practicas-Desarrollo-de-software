# services/archivo_service.py
import os
import uuid
from werkzeug.utils import secure_filename
from config.settings import config
from models.archivo import Archivo
from services.auditoria_service import AuditoriaService
import traceback
from services.historial_service import HistorialService

env = os.environ.get("FLASK_ENV", "development")
cfg = config[env]

# Servicio para manejar archivos adjuntos relacionados con las solicitudes
class ArchivoService:
    
    ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'xls', 'xlsx', 'txt', 'zip'}

    # Funciones auxiliares para validar archivos, y manejar la logica de guardado
    @staticmethod
    def allowed_file(filename):
        if not filename or '.' not in filename:
            return False
        extension = filename.rsplit('.', 1)[1].lower()
        return extension in ArchivoService.ALLOWED_EXTENSIONS

    # Funcion para formatear el tamaño de los archivos en una forma legible
    @staticmethod
    def formatear_tamano(bytes):
        if bytes < 1024:
            return f"{bytes} B"
        elif bytes < 1024 * 1024:
            return f"{bytes / 1024:.1f} KB"
        elif bytes < 1024 * 1024 * 1024:
            return f"{bytes / (1024 * 1024):.1f} MB"
        else:
            return f"{bytes / (1024 * 1024 * 1024):.1f} GB"

    # Funcion para guardar un archivo adjunto a una solicitud, con autenticacion
    @staticmethod
    def guardar_archivo(file, id_solicitud, usuario):
        """Guarda un archivo adjunto (con autenticación)"""
        try:
            print(f"[DEBUG] Guardando archivo para solicitud {id_solicitud}")
            
            if not file or file.filename == '':
                return False, "No se seleccionó ningún archivo"
            
            if not ArchivoService.allowed_file(file.filename):
                return False, f"Tipo de archivo no permitido. Permitidos: {', '.join(ArchivoService.ALLOWED_EXTENSIONS)}"
            
            original_nombre = secure_filename(file.filename)
            extension = original_nombre.rsplit('.', 1)[1].lower()
            nuevo_nombre = f"{uuid.uuid4().hex}.{extension}"
            
            os.makedirs(cfg.UPLOAD_FOLDER, exist_ok=True)
            
            ruta_completa = os.path.join(cfg.UPLOAD_FOLDER, nuevo_nombre)
            file.save(ruta_completa)
            
            tamano = os.path.getsize(ruta_completa)
            
            Archivo.create(
                id_solicitud,
                original_nombre,
                nuevo_nombre,
                f"/uploads/solicitudes/{nuevo_nombre}",
                file.content_type,
                tamano,
                usuario
            )
            HistorialService.registrar_archivo(id_solicitud, usuario, original_nombre, subido=True)
            
            AuditoriaService.registrar(
                usuario,
                "subir_archivo",
                id_solicitud,
                f"Archivo: {original_nombre}"
            )
            
            print(f"[DEBUG] Archivo guardado: {original_nombre}")
            return True, "Archivo subido correctamente"
            
        except Exception as e:
            print(f"[ERROR] Error guardando archivo: {e}")
            traceback.print_exc()
            return False, f"Error: {str(e)}"

    # Funcion para guardar los archivos relacionados a una solicitud especifica
    @staticmethod
    def guardar_archivo_publico(file, id_solicitud, nombre_usuario="Público"):
        """Guarda un archivo adjunto (sin autenticación)"""
        try:
            print(f"[DEBUG] Guardando archivo público para solicitud {id_solicitud}")
            
            if not file or file.filename == '':
                return False, "No se seleccionó ningún archivo"
            
            if not ArchivoService.allowed_file(file.filename):
                return False, f"Tipo de archivo no permitido. Permitidos: {', '.join(ArchivoService.ALLOWED_EXTENSIONS)}"
            
            original_nombre = secure_filename(file.filename)
            extension = original_nombre.rsplit('.', 1)[1].lower()
            nuevo_nombre = f"{uuid.uuid4().hex}.{extension}"
            
            os.makedirs(cfg.UPLOAD_FOLDER, exist_ok=True)
            
            ruta_completa = os.path.join(cfg.UPLOAD_FOLDER, nuevo_nombre)
            file.save(ruta_completa)
            
            tamano = os.path.getsize(ruta_completa)
            
            Archivo.create(
                id_solicitud,
                original_nombre,
                nuevo_nombre,
                f"/uploads/solicitudes/{nuevo_nombre}",
                file.content_type,
                tamano,
                nombre_usuario
            )
            
            print(f"[DEBUG] Archivo público guardado: {original_nombre}")
            return True, "Archivo subido correctamente"
            
        except Exception as e:
            print(f"[ERROR] Error guardando archivo público: {e}")
            traceback.print_exc()
            return False, f"Error: {str(e)}"

    # Funcion para obtener los archivos relacionadas a una solicitud especifica
    @staticmethod
    def obtener_archivos_por_solicitud(id_solicitud):
        try:
            print(f"[DEBUG] Buscando archivos para solicitud {id_solicitud}")
            archivos = Archivo.get_by_solicitud(id_solicitud)
            print(f"[DEBUG] Encontrados {len(archivos) if archivos else 0} archivos")
            return archivos if archivos else []
        except Exception as e:
            print(f"[ERROR] Error en obtener_archivos_por_solicitud: {e}")
            traceback.print_exc()
            return []

    # Funcion para eliminar un archivo adjunto por su ID 
    @staticmethod
    def eliminar_archivo(id_archivo, usuario):
        archivo = Archivo.get_by_id(id_archivo)
        if not archivo:
            return False, "Archivo no encontrado"
        
        ruta_fisica = os.path.join(cfg.UPLOAD_FOLDER, archivo['nombre_archivo'])
        if os.path.exists(ruta_fisica):
            os.remove(ruta_fisica)
        
        if Archivo.delete(id_archivo):
            AuditoriaService.registrar(
                usuario,
                "eliminar_archivo",
                archivo['id_solicitud'],
                f"Archivo: {archivo['nombre_original']}"
            )
            HistorialService.registrar_archivo(archivo['id_solicitud'], usuario, archivo['nombre_original'], subido=False)
            return True, "Archivo eliminado correctamente"
        
        return False, "Error al eliminar archivo"