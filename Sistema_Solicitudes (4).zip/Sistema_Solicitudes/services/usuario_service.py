from models.usuario import Usuario
from services.auditoria_service import AuditoriaService

# Servicio para manejar operaciones con los usuarios
class UsuarioService:

    # Funciones para obtener usuarios
    @staticmethod
    def obtener_todos():
        try:
            usuarios = Usuario.get_all()
            print(f"[DEBUG] UsuarioService.obtener_todos: {len(usuarios)} usuarios")
            return usuarios
        except Exception as e:
            print(f"[ERROR] UsuarioService.obtener_todos: {e}")
            return []

    # Funciones para obtener un usuario por su ID
    @staticmethod
    def obtener_por_id(id_usuario):
        return Usuario.get_by_id(id_usuario)

    # Funciones para crar un usuario 
    @staticmethod
    def crear(data, usuario_creador):
        existing = Usuario.get_by_username(data['usuario'])
        if existing:
            return False, "El usuario ya existe"
        

        nueva_id = Usuario.create(data)
        #Agregar auditoria de creacion de usuario
        if nueva_id:
            AuditoriaService.registrar(usuario_creador, "crear_usuario", detalle=f"usuario creado: {data['usuario']}")
            return True, "Usuario registrado exitosamente"
        return False, "Error al crear usuario"

    # Funciones para actualizar un usuario por ID
    @staticmethod
    def actualizar(id_usuario, data, usuario_editor):
        if Usuario.update(id_usuario, data):
            AuditoriaService.registrar(usuario_editor, "editar_usuario", detalle=f"usuario editado: ID {id_usuario}")
            return True, "Usuario actualizado exitosamente"
        return False, "Usuario no encontrado"

    # Funciones para eliminar un usuario por ID
    @staticmethod
    def eliminar(id_usuario, usuario_eliminador):
        usuario = Usuario.get_by_id(id_usuario)
        if not usuario:
            return False, "Usuario no encontrado"
        
        if Usuario.delete(id_usuario):
            AuditoriaService.registrar(
                usuario_eliminador, "eliminar_usuario",
                detalle=f"usuario eliminado: {usuario['usuario']} ({usuario['nombre']})"
            )
            return True, "Usuario eliminado exitosamente"
        return False, "Error al eliminar"

    # Funcion para auto asignar una solicitud a un tecnico disponible segun la categoria de la solicitud
    @staticmethod
    def auto_asignar(categoria):
        return Usuario.get_tecnico_by_categoria(categoria)