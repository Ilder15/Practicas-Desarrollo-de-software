from models.notificacion import Notificacion

class NotificacionService:
    
    @staticmethod
    def obtener_por_usuario(usuario):
        """Obtiene todas las notificaciones de un usuario"""
        try:
            return Notificacion.get_by_usuario(usuario)
        except Exception as e:
            print(f"Error en NotificacionService.obtener_por_usuario: {e}")
            return []
    
    @staticmethod
    def crear(usuario, id_solicitud, mensaje, tipo="info"):
        """Crea una nueva notificación
        
        Args:
            usuario (str): Nombre del usuario destinatario
            id_solicitud (int): ID de la solicitud relacionada
            mensaje (str): Mensaje de la notificación
            tipo (str): Tipo de notificación (info, reasignacion_solicitada, etc.)
        """
        try:
            print(f"[DEBUG] Creando notificación - Usuario: {usuario}, ID Solicitud: {id_solicitud}, Tipo: {tipo}")
            result = Notificacion.create(usuario, id_solicitud, mensaje, tipo)
            print(f"[DEBUG] Resultado creación: {result}")
            return result
        except Exception as e:
            print(f"Error en NotificacionService.crear: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    @staticmethod
    def contar_no_leidas(usuario):
        """Cuenta las notificaciones no leídas de un usuario"""
        try:
            return Notificacion.count_no_leidas(usuario)
        except Exception as e:
            print(f"Error en NotificacionService.contar_no_leidas: {e}")
            return 0
    
    @staticmethod
    def marcar_todas_como_leidas(usuario):
        """Marca todas las notificaciones de un usuario como leídas"""
        try:
            Notificacion.mark_all_as_read(usuario)
            return True
        except Exception as e:
            print(f"Error en NotificacionService.marcar_todas_como_leidas: {e}")
            return False
    
    @staticmethod
    def limpiar_todas(usuario):
        """Elimina todas las notificaciones de un usuario"""
        try:
            return Notificacion.delete_all(usuario)
        except Exception as e:
            print(f"Error en NotificacionService.limpiar_todas: {e}")
            return False
    
    @staticmethod
    def obtener_por_tipo(usuario, tipo):
        """Obtiene notificaciones de un tipo específico"""
        try:
            return Notificacion.get_pendientes_por_tipo(usuario, tipo)
        except Exception as e:
            print(f"Error en NotificacionService.obtener_por_tipo: {e}")
            return []
    
    @staticmethod
    def marcar_como_leida(notificacion_id):
        """Marca una notificación específica como leída"""
        try:
            return Notificacion.mark_as_read(notificacion_id)
        except Exception as e:
            print(f"Error en NotificacionService.marcar_como_leida: {e}")
            return False