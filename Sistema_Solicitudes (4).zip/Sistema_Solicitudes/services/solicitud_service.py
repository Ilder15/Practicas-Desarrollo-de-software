# services/solicitud_service.py
from config.database import get_db
from models.solicitud import Solicitud
from models.usuario import Usuario
from models.historial import Historial
from services.auditoria_service import AuditoriaService
from services.notificacion_service import NotificacionService
from services.historial_service import HistorialService
from datetime import datetime, timedelta

class SolicitudService:
    
    @staticmethod
    def obtener_todas(usuario, es_admin):
        """Obtiene todas las solicitudes (todas si es admin, solo las asignadas si es técnico)"""
        return Solicitud.get_all(usuario if not es_admin else None, es_admin)
    
    @staticmethod
    def obtener_por_id(id_solicitud):
        """Obtiene una solicitud por su ID"""
        return Solicitud.get_by_id(id_solicitud)
    
    @staticmethod
    def obtener_sin_asignar():
        """Obtiene las solicitudes sin asignar"""
        return Solicitud.get_sin_asignar()
    
    @staticmethod
    def _calcular_sla_vencimiento(fecha_reporte, prioridad):
        """Calcula la fecha de vencimiento SLA según prioridad"""
        if prioridad == 'alta':
            return fecha_reporte + timedelta(hours=6)
        elif prioridad == 'media':
            return fecha_reporte + timedelta(hours=12)
        else:  # baja
            return fecha_reporte + timedelta(hours=24)
    
    @staticmethod
    def crear(data, usuario_creador):
        """Crea una nueva solicitud con SLA calculado"""
        fecha_reporte = datetime.now()
        nueva_id = Solicitud.create(data)
        
        vencimiento = SolicitudService._calcular_sla_vencimiento(fecha_reporte, data['prioridad'])
        
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "UPDATE solicitudes SET sla_vencimiento = %s WHERE id = %s",
            (vencimiento, nueva_id)
        )
        db.commit()
        cursor.close()
        
        AuditoriaService.registrar(
            usuario_creador, "crear_solicitud", nueva_id,
            f"Cliente: {data['cliente']} · SLA: {data['prioridad']} vence {vencimiento.strftime('%Y-%m-%d %H:%M')}"
        )
        
        HistorialService.registrar_creacion(nueva_id, usuario_creador, data)
        
        asignado = Usuario.get_tecnico_by_categoria(data['tipo_soporte'])
        
        if asignado:
            Solicitud.update_asignado(nueva_id, asignado)
            AuditoriaService.registrar(asignado, "asignar", nueva_id, "auto-asignado por categoría")
            HistorialService.registrar_asignacion(nueva_id, asignado, asignado, es_auto=True)
            NotificacionService.crear(
                asignado, nueva_id,
                f"Nueva solicitud asignada: {data['cliente']} ({data['tipo_soporte']} · {data['prioridad']}) · SLA: {vencimiento.strftime('%d/%m %H:%M')}"
            )
        
        return nueva_id, asignado
    
    @staticmethod
    def actualizar(id_solicitud, data, usuario):
        """Actualiza los datos de una solicitud (cliente, descripción, tipo, prioridad)"""
        solicitud = Solicitud.get_by_id(id_solicitud)
        if not solicitud:
            return False
        
        if solicitud['estado'] == 'resuelto':
            return False
        
        prioridad_anterior = solicitud.get('prioridad')
        nueva_prioridad = data.get('prioridad')
        
        campos_modificados = []
        if solicitud.get('cliente') != data.get('cliente'):
            campos_modificados.append('cliente')
        if solicitud.get('tipo_soporte') != data.get('tipo_soporte'):
            campos_modificados.append('tipo_soporte')
        if prioridad_anterior != nueva_prioridad:
            campos_modificados.append('prioridad')
            fecha_reporte = solicitud.get('fecha_reporte')
            if fecha_reporte:
                nuevo_vencimiento = SolicitudService._calcular_sla_vencimiento(fecha_reporte, nueva_prioridad)
                db = get_db()
                cursor = db.cursor()
                cursor.execute(
                    "UPDATE solicitudes SET sla_vencimiento = %s WHERE id = %s",
                    (nuevo_vencimiento, id_solicitud)
                )
                db.commit()
                cursor.close()
                data['sla_vencimiento'] = nuevo_vencimiento
        if solicitud.get('descripcion') != data.get('descripcion'):
            campos_modificados.append('descripcion')
        
        if Solicitud.update(id_solicitud, data):
            AuditoriaService.registrar(
                usuario, "editar_solicitud", id_solicitud,
                f"cliente: {data['cliente']} · {data['tipo_soporte']} · {data['prioridad']}"
            )
            if campos_modificados:
                HistorialService.registrar_edicion(id_solicitud, usuario, campos_modificados)
            return True
        return False

    @staticmethod
    def actualizar_estado(id_solicitud, estado, usuario):
        """Actualiza el estado de una solicitud (pendiente, en proceso, resuelto)"""
        solicitud = Solicitud.get_by_id(id_solicitud)
        if not solicitud:
            return False
        
        estado_anterior = solicitud['estado']
        
        if Solicitud.update_estado(id_solicitud, estado):
            AuditoriaService.registrar(usuario, "editar_estado", id_solicitud, f"nuevo estado: {estado}")
            HistorialService.registrar_cambio_estado(id_solicitud, usuario, estado_anterior, estado)
            return True
        return False

    @staticmethod
    def resolver(id_solicitud, asignado_a, usuario):
        """Marca una solicitud como resuelta"""
        if Solicitud.resolver(id_solicitud, asignado_a):
            AuditoriaService.registrar(usuario, "resolver", id_solicitud)
            HistorialService.registrar_resolucion(id_solicitud, usuario)
            return True
        return False

    @staticmethod
    def asignar(id_solicitud, asignado_a, usuario, es_admin=False):
        """Asigna una solicitud a un usuario"""
        solicitud = Solicitud.get_by_id(id_solicitud)
        if not solicitud:
            return False, "Solicitud no encontrada"
        
        if solicitud['asignado_a']:
            return False, "Esta solicitud ya tiene un responsable asignado"
        
        if not es_admin and asignado_a != usuario:
            return False, "No autorizado"
        
        if Solicitud.update_asignado(id_solicitud, asignado_a):
            AuditoriaService.registrar(usuario, "asignar", id_solicitud, f"asignado a: {asignado_a}")
            HistorialService.registrar_asignacion(id_solicitud, usuario, asignado_a, es_auto=False)
            NotificacionService.crear(
                asignado_a, id_solicitud,
                f"Nueva solicitud asignada: {solicitud['cliente']} ({solicitud['tipo_soporte']} · {solicitud['prioridad']})"
            )
            return True, "Asignado correctamente"
        return False, "Error al asignar"

    @staticmethod
    def reasignar(id_solicitud, nuevo_asignado, usuario):
        """Reasigna una solicitud de un usuario a otro (solo admin)"""
        solicitud = Solicitud.get_by_id(id_solicitud)
        if not solicitud:
            return False, "Solicitud no encontrada"
        
        anterior = solicitud['asignado_a'] or "Sin asignar"
        
        if Solicitud.update_asignado(id_solicitud, nuevo_asignado):
            AuditoriaService.registrar(
                usuario, "reasignar", id_solicitud,
                f"reasignado de {anterior} a {nuevo_asignado}"
            )
            HistorialService.registrar_reasignacion(id_solicitud, usuario, anterior, nuevo_asignado)
            NotificacionService.crear(
                nuevo_asignado, id_solicitud,
                f"Solicitud reasignada: {solicitud['cliente']} ({solicitud['tipo_soporte']} · {solicitud['prioridad']})"
            )
            return True, f"Reasignado a {nuevo_asignado}"
        return False, "Error al reasignar"

    @staticmethod
    def eliminar(id_solicitud, usuario):
        """Elimina una solicitud (solo admin)"""
        if Solicitud.delete(id_solicitud):
            AuditoriaService.registrar(usuario, "eliminar", id_solicitud)
            return True
        return False

    @staticmethod
    def obtener_sla_status(id_solicitud):
        """Obtiene el estado detallado del SLA de una solicitud"""
        return Solicitud.obtener_sla_status(id_solicitud)

    # ========== SOLICITAR REASIGNACIÓN (VERSIÓN CORREGIDA) ==========
    @staticmethod
    def solicitar_reasignacion(id_solicitud, usuario_solicitante, motivo):
        """Un técnico solicita reasignar una solicitud"""
        try:
            solicitud = Solicitud.get_by_id(id_solicitud)
            if not solicitud:
                return False, "Solicitud no encontrada"
            
            if solicitud['estado'] == 'resuelto':
                return False, "No se puede reasignar una solicitud resuelta"
            
            if solicitud['asignado_a'] != usuario_solicitante:
                return False, "Solo el técnico asignado puede solicitar reasignación"
            
            db = get_db()
            cursor = db.cursor()
            cursor.execute("SELECT nombre FROM usuarios WHERE tipo = 1")
            admins = cursor.fetchall()
            cursor.close()
            
            if not admins:
                return False, "No hay administradores disponibles para procesar la solicitud"
            
            # FORMATO ESTRUCTURADO CON PIPE - ESTE ES EL CORRECTO
            mensaje = f"REASIGNACION|{id_solicitud}|{usuario_solicitante}|{motivo}|{solicitud['cliente']}|{solicitud['prioridad']}|{solicitud['tipo_soporte']}"
            
            print(f"[DEBUG] Mensaje formateado para reasignación: {mensaje}")
            
            for admin in admins:
                NotificacionService.crear(
                    admin['nombre'],
                    id_solicitud,
                    mensaje,
                    "reasignacion_solicitada"
                )
            
            AuditoriaService.registrar(
                usuario_solicitante,
                "solicitar_reasignacion",
                id_solicitud,
                f"Solicita reasignación. Motivo: {motivo[:100]}"
            )
            
            # Usar Historial directamente
            Historial.registrar(
                id_solicitud,
                "solicitud_reasignacion",
                f"{usuario_solicitante} solicitó reasignación. Motivo: {motivo[:100]}",
                usuario_solicitante
            )
            
            return True, "Solicitud de reasignación enviada a los administradores"
            
        except Exception as e:
            print(f"Error en solicitar_reasignacion: {e}")
            import traceback
            traceback.print_exc()
            return False, f"Error interno: {str(e)}"