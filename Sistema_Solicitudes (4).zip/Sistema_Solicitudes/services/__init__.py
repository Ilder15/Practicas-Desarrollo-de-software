from services.auth_service import AuthService
from services.solicitud_service import SolicitudService
from services.usuario_service import UsuarioService
from services.comentario_service import ComentarioService
from services.notificacion_service import NotificacionService
from services.auditoria_service import AuditoriaService