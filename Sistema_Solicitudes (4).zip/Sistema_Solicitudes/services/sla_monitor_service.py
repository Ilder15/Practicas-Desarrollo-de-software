# services/sla_monitor_service.py
from datetime import datetime
from config.database import get_db
from models.solicitud import Solicitud
from services.notificacion_service import NotificacionService

# Servicio para monitorear las SLA de las solicitudes 
class SLAMonitorService:

    # Funcion para verificar solicitudes con SLA vencido y enviar notificaciones a los responsables
    @staticmethod
    def verificar_slas_vencidos():
        """Verifica solicitudes con SLA vencido y envía notificaciones"""
        db = get_db()
        cursor = db.cursor()
        cursor.execute("""
            SELECT id, cliente, asignado_a, sla_vencimiento 
            FROM solicitudes 
            WHERE estado != 'resuelto' 
            AND sla_vencimiento < NOW() 
            AND sla_notificado = FALSE
        """)
        vencidas = cursor.fetchall()
        cursor.close()
        
        for s in vencidas:
            # Enviar notificación
            NotificacionService.crear(
                s['asignado_a'] or 'admin',
                s['id'],
                f"⚠️ SLA VENCIDO - Solicitud #{s['id']}: {s['cliente']}"
            )
            # Marcar como notificada
            cursor = db.cursor()
            cursor.execute("UPDATE solicitudes SET sla_notificado = TRUE WHERE id = %s", (s['id'],))
            db.commit()
            cursor.close()