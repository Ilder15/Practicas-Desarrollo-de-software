from models.auditoria import Auditoria

# Servicio para manejar auditoria de acciones del sistema
class AuditoriaService:

    # Funciones para obtener registros de auditoria, y registrar nuevas acciones
    @staticmethod
    def obtener_todas(limit=200):
        try:
            registros = Auditoria.get_all(limit)
            print(f"[DEBUG] AuditoriaService.obtener_todas: {len(registros)} registros")
            return registros
        except Exception as e:
            print(f"[ERROR] AuditoriaService.obtener_todas: {e}")
            return []

    # Funcion para registrar una nueva accion en la auditoria
    @staticmethod
    def registrar(usuario, accion, id_solicitud=None, detalle=None):
        return Auditoria.create(usuario, accion, id_solicitud, detalle)