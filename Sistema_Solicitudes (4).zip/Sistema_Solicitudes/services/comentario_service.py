from models.comentario import Comentario
from services.auditoria_service import AuditoriaService
from services.historial_service import HistorialService

# Servicio para manejar comentarios relacionados con solicitudes
class ComentarioService:

    # Funciones para obtener comentarios de una solicitud
    @staticmethod
    def obtener_por_solicitud(id_solicitud):
        return Comentario.get_by_solicitud(id_solicitud)

    # Funcion para crear un nuevo comentario en una solicitud, con autenticacion
    @staticmethod
    def crear(id_solicitud, usuario, mensaje):
        Comentario.create(id_solicitud, usuario, mensaje)
        AuditoriaService.registrar(usuario, "comentario_agregado", id_solicitud, mensaje[:50])
        HistorialService.registrar_comentario(id_solicitud, usuario, mensaje)
        return True