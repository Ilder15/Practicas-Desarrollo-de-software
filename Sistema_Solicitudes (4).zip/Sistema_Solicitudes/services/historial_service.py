# services/historial_service.py
from models.historial import Historial

# Servicio para manejar el historial de acciones realizadas en las solicitudes
class HistorialService:
    
    # Mapeo de acciones a iconos y colores
    ICONOS = {
        'creacion': '📝',
        'cambio_estado': '🔄',
        'asignacion': '👤',
        'reasignacion': '🔄',
        'comentario': '💬',
        'archivo_subido': '📎',
        'archivo_eliminado': '🗑️',
        'edicion': '✏️',
        'resolucion': '✅'
    }
    
    COLORES = {
        'creacion': '#6af7c8',
        'cambio_estado': '#f7c26a',
        'asignacion': '#7c6af7',
        'reasignacion': '#f76a8a',
        'comentario': '#8888a0',
        'archivo_subido': '#6af7c8',
        'archivo_eliminado': '#f76a8a',
        'edicion': '#f7c26a',
        'resolucion': '#6af7c8'
    }

    # Funciones para registrar diferentes tipos de acciones en el historial, y obtener el historial de una solicitud
    @staticmethod
    def registrar_creacion(id_solicitud, usuario, datos):
        descripcion = f"Solicitud creada por {usuario}"
        return Historial.registrar(id_solicitud, 'creacion', descripcion, usuario)

    # Funcion para registrar un cambio de estado en el historial
    @staticmethod
    def registrar_cambio_estado(id_solicitud, usuario, estado_anterior, estado_nuevo):
        descripcion = f"Estado cambiado de '{estado_anterior}' a '{estado_nuevo}' por {usuario}"
        return Historial.registrar(id_solicitud, 'cambio_estado', descripcion, usuario, estado_anterior, estado_nuevo)

    # Funcion para registrar una asignacion a un nuevo responsable en el historial
    @staticmethod
    def registrar_asignacion(id_solicitud, usuario, asignado_a, es_auto=False):
        tipo = "auto-asignación" if es_auto else "asignación"
        descripcion = f"{tipo.capitalize()} a {asignado_a} por {usuario}"
        return Historial.registrar(id_solicitud, 'asignacion', descripcion, usuario)

    # Funcion para registrar una reasignacion a un nuevo responsable en el historial
    @staticmethod
    def registrar_reasignacion(id_solicitud, usuario, anterior, nuevo):
        descripcion = f"Reasignado de {anterior} a {nuevo} por {usuario}"
        return Historial.registrar(id_solicitud, 'reasignacion', descripcion, usuario)

    # Funcion para registrar un nuevo comentario en el historial
    @staticmethod
    def registrar_comentario(id_solicitud, usuario, mensaje):
        descripcion = f"Comentario de {usuario}: {mensaje[:100]}"
        return Historial.registrar(id_solicitud, 'comentario', descripcion, usuario)

    # Funcion para registrar la subida o eliminacion de un archivo relacionado a una solicitud en el histarial 
    @staticmethod
    def registrar_archivo(id_solicitud, usuario, nombre_archivo, subido=True):
        accion = 'archivo_subido' if subido else 'archivo_eliminado'
        texto = "subió" if subido else "eliminó"
        descripcion = f"{usuario} {texto} el archivo: {nombre_archivo}"
        return Historial.registrar(id_solicitud, accion, descripcion, usuario)

    # Funcion para registrar la edicion de una solicitud en el histarial, indicando los campos modificados
    @staticmethod
    def registrar_edicion(id_solicitud, usuario, campos_modificados):
        descripcion = f"{usuario} editó la solicitud: {', '.join(campos_modificados)}"
        return Historial.registrar(id_solicitud, 'edicion', descripcion, usuario)

    # Funcion para registrar la resolucion de una solicitud en el historial
    @staticmethod
    def registrar_resolucion(id_solicitud, usuario):
        descripcion = f"Solicitud resuelta por {usuario}"
        return Historial.registrar(id_solicitud, 'resolucion', descripcion, usuario)

    # Funcion para obtener el historial completo de una solicitud
    @staticmethod
    def obtener_historial(id_solicitud):
        registros = Historial.get_by_solicitud(id_solicitud)
        
        resultado = []
        for r in registros:
            resultado.append({
                'id': r['id'],
                'accion': r['accion'],
                'descripcion': r['descripcion'],
                'usuario': r['usuario'],
                'fecha': r['fecha'],
                'icono': HistorialService.ICONOS.get(r['accion'], '📌'),
                'color': HistorialService.COLORES.get(r['accion'], '#8888a0'),
                'datos_anteriores': r.get('datos_anteriores'),
                'datos_nuevos': r.get('datos_nuevos')
            })
        
        return resultado
    # services/historial_service.py - Agrega este método

    @staticmethod
    def registrar(id_solicitud, accion, descripcion, usuario, datos_anteriores=None, datos_nuevos=None):
        """Registra cualquier acción en el historial"""
        try:
            from models.historial import Historial
            return Historial.registrar(id_solicitud, accion, descripcion, usuario, datos_anteriores, datos_nuevos)
        except Exception as e:
            print(f"Error en HistorialService.registrar: {e}")
            return False