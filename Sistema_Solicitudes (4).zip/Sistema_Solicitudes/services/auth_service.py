from flask_jwt_extended import create_access_token
from models.usuario import Usuario

# Servicio para manejar autenticacion y autorizacion de usuarios
class AuthService:
    
    # Funciones para validar credenciales, generar tokens JWT, y manejar la autenticacion de usuarios
    @staticmethod
    def login(usuario, password):
        user = Usuario.verify_password(usuario, password)
        
        if not user:
            return None, None, None
        
        token = create_access_token(
            identity=usuario,
            additional_claims={"tipo": user["tipo"], "nombre": user["nombre"]}
        )
        
        return token, user["nombre"], user["tipo"]