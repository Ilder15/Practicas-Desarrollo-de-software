const RECAPTCHA_SITE_KEY = '{{ recaptcha_site_key }}';

async function getRecaptchaToken() {
    if (typeof grecaptcha === 'undefined' || !RECAPTCHA_SITE_KEY || RECAPTCHA_SITE_KEY === 'None') {
        return null;
    }
    
    return new Promise((resolve) => {
        grecaptcha.ready(async () => {
            try {
                const token = await grecaptcha.execute(RECAPTCHA_SITE_KEY, { action: 'login' });
                resolve(token);
            } catch (error) {
                console.error('Error obteniendo token reCAPTCHA:', error);
                resolve(null);
            }
        });
    });
}

function showError(message, isRateLimit = false) {
    const errorEl = document.getElementById("error");
    const rateLimitEl = document.getElementById("rate-limit-warning");
    
    if (isRateLimit) {
        rateLimitEl.textContent = message;
        rateLimitEl.style.display = "block";
        errorEl.style.display = "none";
        setTimeout(() => { rateLimitEl.style.display = "none"; }, 5000);
    } else {
        errorEl.textContent = message;
        errorEl.style.display = "block";
        rateLimitEl.style.display = "none";
    }
}

document.getElementById("loginForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    
    const usuario = document.getElementById("usuario").value.trim();
    const password = document.getElementById("password").value;
    const btnLogin = document.getElementById("btnLogin");
    const originalText = btnLogin.textContent;

    if (!usuario || !password) {
        showError("Ingresa usuario y contraseña");
        return;
    }

    btnLogin.textContent = "Verificando...";
    btnLogin.disabled = true;

    try {
        let recaptchaToken = null;
        if (typeof grecaptcha !== 'undefined' && RECAPTCHA_SITE_KEY && RECAPTCHA_SITE_KEY !== 'None') {
            recaptchaToken = await getRecaptchaToken();
        }

        const response = await fetch("/api/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ usuario, password, recaptcha_token: recaptchaToken })
        });
        
        const data = await response.json();
        
        if (response.status === 429) {
            showError("Demasiados intentos. Por favor, espera un minuto.", true);
            btnLogin.textContent = originalText;
            btnLogin.disabled = false;
            return;
        }
        
        if (data.token) {
            localStorage.setItem("token", data.token);
            localStorage.setItem("nombre", data.nombre);
            localStorage.setItem("tipo", data.tipo);
            window.location.href = "/";
        } else {
            showError(data.error || "Usuario o contraseña incorrectos");
            btnLogin.textContent = originalText;
            btnLogin.disabled = false;
            document.getElementById("password").value = "";
        }
        
    } catch (error) {
        console.error("Error de conexión:", error);
        showError("Error de conexión. Verifica tu internet e intenta de nuevo.");
        btnLogin.textContent = originalText;
        btnLogin.disabled = false;
    }
});

document.getElementById("usuario").addEventListener("input", () => {
    document.getElementById("error").style.display = "none";
    document.getElementById("rate-limit-warning").style.display = "none";
});

document.getElementById("password").addEventListener("input", () => {
    document.getElementById("error").style.display = "none";
    document.getElementById("rate-limit-warning").style.display = "none";
});