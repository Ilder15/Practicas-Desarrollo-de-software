// ========== FUNCIONES UTILITY ==========
function showToast(msg, type) {
    type = type || "success";
    var t = document.getElementById("toast");
    t.textContent = msg;
    t.className = "toast " + type + " show";
    setTimeout(function() { t.classList.remove("show"); }, 3000);
}

function formatFecha(fecha) {
    if (!fecha) return "—";
    return new Date(fecha).toLocaleDateString("es-CO", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    });
}

function formatFechaHora(fecha) {
    if (!fecha) return "—";
    return new Date(fecha).toLocaleString("es-CO", {
        day: "2-digit",
        month: "short",
        hour: "2-digit",
        minute: "2-digit"
    });
}

function getEstadoClass(estado) {
    switch(estado) {
        case 'pendiente': return 'pendiente';
        case 'en proceso': return 'proceso';
        case 'resuelto': return 'resuelto';
        default: return 'pendiente';
    }
}

function getEstadoTexto(estado) {
    switch(estado) {
        case 'pendiente': return '⏳ Pendiente';
        case 'en proceso': return '🔄 En Proceso';
        case 'resuelto': return '✅ Resuelto';
        default: return estado;
    }
}

function escapeHtml(text) {
    if (!text) return text;
    var div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ========== FUNCIONES PARA COMENTARIOS ==========
var comentariosCargados = {};

function cargarComentariosPublicos(id) {
    var container = document.getElementById("comentarios-" + id);
    if (!container) return;
    
    container.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--muted);">⏳ Cargando comentarios...</div>';
    
    fetch("/api/solicitudes/" + id + "/comentarios")
    .then(function(res) { return res.json(); })
    .then(function(data) {
        if (!data.comentarios || data.comentarios.length === 0) {
            container.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--muted);">💬 No hay comentarios aún. El técnico responderá pronto.</div>';
            return;
        }
        
        var html = '';
        for (var i = 0; i < data.comentarios.length; i++) {
            var c = data.comentarios[i];
            html += '<div style="margin-bottom: 16px; padding: 12px; background: var(--surface); border-radius: 10px;">' +
                '<div style="display: flex; justify-content: space-between; margin-bottom: 6px; flex-wrap: wrap; gap: 4px;">' +
                '<strong style="color: var(--accent); font-size: 0.85rem;">' + escapeHtml(c.usuario) + '</strong>' +
                '<span style="font-size: 0.7rem; color: var(--muted);">' + formatFechaHora(c.fecha) + '</span>' +
                '</div>' +
                '<div style="font-size: 0.85rem; line-height: 1.4; word-wrap: break-word;">' + escapeHtml(c.mensaje) + '</div>' +
                '</div>';
        }
        container.innerHTML = html;
        container.scrollTop = container.scrollHeight;
    })
    .catch(function(error) {
        console.error("Error cargando comentarios:", error);
        container.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--accent2);">❌ Error al cargar comentarios</div>';
    });
}

function toggleComentarios(id, event) {
    var container = document.getElementById("comentarios-" + id);
    var btn = event.target;
    
    if (!container) return;
    
    if (container.style.display === 'none' || container.style.display === '') {
        container.style.display = 'block';
        btn.innerHTML = 'Ocultar comentarios ▲';
        
        if (!comentariosCargados[id]) {
            cargarComentariosPublicos(id);
            comentariosCargados[id] = true;
        }
    } else {
        container.style.display = 'none';
        btn.innerHTML = 'Mostrar comentarios ▼';
    }
}

// ========== FUNCIONES PARA ARCHIVOS ==========
function getIconoArchivoPublico(tipo) {
    if (!tipo) return "📎";
    if (tipo.includes("image")) return "🖼️";
    if (tipo.includes("pdf")) return "📄";
    if (tipo.includes("word") || tipo.includes("document")) return "📝";
    if (tipo.includes("excel") || tipo.includes("sheet")) return "📊";
    if (tipo.includes("zip") || tipo.includes("compressed")) return "🗜️";
    if (tipo.includes("text")) return "📃";
    return "📎";
}

function cargarArchivosPublicos(idSolicitud) {
    var container = document.getElementById("archivos-" + idSolicitud);
    if (!container) return;
    
    container.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--muted);">⏳ Cargando archivos...</div>';
    
    fetch("/api/public/solicitudes/" + idSolicitud + "/archivos")
    .then(function(res) { return res.json(); })
    .then(function(data) {
        if (!data.archivos || data.archivos.length === 0) {
            container.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--muted);">📎 No hay archivos adjuntos</div>';
            return;
        }
        
        var html = '';
        for (var i = 0; i < data.archivos.length; i++) {
            var a = data.archivos[i];
            var icono = getIconoArchivoPublico(a.tipo);
            
            html += '<div class="archivo-item" style="display: flex; align-items: center; justify-content: space-between; padding: 8px; border-bottom: 1px solid var(--border);">' +
                '<div style="display: flex; align-items: center; gap: 10px;">' +
                '<span style="font-size: 1.2rem;">' + icono + '</span>' +
                '<div>' +
                '<div style="font-size: 0.85rem; font-weight: 500;">' + escapeHtml(a.nombre_original) + '</div>' +
                '<div style="font-size: 0.7rem; color: var(--muted);">' + (a.tamano || '?') + ' · ' + formatFecha(a.fecha_subida) + '</div>' +
                '</div>' +
                '</div>' +
                '<button class="btn-action" onclick="descargarArchivoPublico(' + a.id + ')" style="padding: 4px 8px;">📥 Descargar</button>' +
                '</div>';
        }
        
        container.innerHTML = html;
    })
    .catch(function(error) {
        console.error("Error cargando archivos:", error);
        container.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--accent2);">❌ Error al cargar archivos</div>';
    });
}

// ========== FUNCIÓN CORREGIDA PARA DESCARGA PÚBLICA ==========
async function descargarArchivoPublico(idArchivo) {
    
    try {
        // IMPORTANTE: Usar la ruta pública, NO /api/archivos/
        const response = await fetch(`/api/public/archivos/${idArchivo}/descargar`, {
            method: "GET"
            // No incluir headers de autorización
        });
        
        
        if (!response.ok) {
            let errorMsg = "Error al descargar";
            try {
                const errorData = await response.json();
                errorMsg = errorData.error || errorMsg;
            } catch(e) {}
            showToast(errorMsg, "error");
            throw new Error(errorMsg);
        }
        
        // Obtener el nombre del archivo
        const contentDisposition = response.headers.get("Content-Disposition");
        let filename = "archivo";
        if (contentDisposition) {
            const match = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
            if (match && match[1]) {
                filename = match[1].replace(/['"]/g, '');
            }
        }
        
        const blob = await response.blob();
        
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        showToast("Descargando archivo...", "success");
        
    } catch (error) {
        console.error("❌ Error en descarga pública:", error);
        showToast("Error de conexión al descargar", "error");
    }
}

// ========== FUNCIÓN PRINCIPAL DE BÚSQUEDA ==========
function buscarSolicitudes() {
    var nombre = document.getElementById("searchNombre").value.trim();
    var id = document.getElementById("searchId").value.trim();
    var resultadosDiv = document.getElementById("resultados");
    
    if (!nombre && !id) {
        showToast("Ingresa tu nombre o número de solicitud", "error");
        return;
    }
    
    resultadosDiv.innerHTML = '<div class="empty-state-custom"><div class="icon">⏳</div><p>Buscando solicitudes...</p></div>';
    
    var url = "/api/buscar-solicitudes?";
    if (nombre) url += "nombre=" + encodeURIComponent(nombre);
    if (id) url += (nombre ? '&' : '') + "id=" + encodeURIComponent(id);
    
    fetch(url)
    .then(function(res) { return res.json(); })
    .then(function(data) {
        if (!data.solicitudes || data.solicitudes.length === 0) {
            resultadosDiv.innerHTML = '<div class="empty-state-custom"><div class="icon">📭</div><p>No se encontraron solicitudes</p><p style="font-size: 0.8rem; margin-top: 8px;">Verifica que el nombre sea exactamente como lo registraste</p></div>';
            return;
        }
        
        var html = '';
        for (var i = 0; i < data.solicitudes.length; i++) {
            var s = data.solicitudes[i];
            var estadoClass = getEstadoClass(s.estado);
            var estadoTexto = getEstadoTexto(s.estado);
            
            html += '<div class="solicitud-card">' +
                '<div class="solicitud-header">' +
                '<span class="solicitud-id">Solicitud #' + s.id + '</span>' +
                '<span class="solicitud-fecha">' + formatFecha(s.fecha_reporte) + '</span>' +
                '</div>' +
                '<div class="solicitud-info">' +
                '<div class="info-item"><span class="info-label">Cliente</span><span class="info-value">' + escapeHtml(s.cliente) + '</span></div>' +
                '<div class="info-item"><span class="info-label">Tipo de soporte</span><span class="info-value">' + (s.tipo_soporte || '—') + '</span></div>' +
                '<div class="info-item"><span class="info-label">Prioridad</span><span class="badge badge-' + (s.prioridad || 'media') + '">' + (s.prioridad || 'Media') + '</span></div>' +
                '<div class="info-item"><span class="info-label">Estado</span><span class="badge badge-' + estadoClass + '">' + estadoTexto + '</span></div>';
            
            if (s.asignado_a) {
                html += '<div class="info-item"><span class="info-label">Asignado a</span><span class="info-value">' + escapeHtml(s.asignado_a) + '</span></div>';
            }
            
            html += '</div>';
            
            if (s.descripcion) {
                html += '<div class="descripcion"><strong>📝 Descripción:</strong><br>' + escapeHtml(s.descripcion) + '</div>';
            }
            
            html += '<div class="timeline">' +
                '<div class="timeline-title">📅 Línea de tiempo</div>' +
                '<div class="timeline-item"><div class="timeline-dot ' + estadoClass + '"></div><div class="timeline-content"><strong>Solicitud creada</strong><div class="timeline-fecha">' + formatFecha(s.fecha_reporte) + '</div></div></div>';
            
            if (s.estado === 'en proceso') {
                html += '<div class="timeline-item"><div class="timeline-dot proceso"></div><div class="timeline-content"><strong>En proceso de atención</strong><div class="timeline-fecha">Técnico asignado está trabajando en tu solicitud</div></div></div>';
            }
            
            if (s.estado === 'resuelto') {
                html += '<div class="timeline-item"><div class="timeline-dot resuelto"></div><div class="timeline-content"><strong>Solicitud resuelta</strong><div class="timeline-fecha">' + (s.fecha_resuelto ? formatFecha(s.fecha_resuelto) : 'Recientemente') + '</div></div></div>';
            }
            
            html += '</div>';
            
            // SECCIÓN DE COMENTARIOS
            html += '<div class="comentarios-section" style="margin-top: 20px; padding-top: 16px; border-top: 1px solid var(--border);">' +
                '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; flex-wrap: wrap; gap: 8px;">' +
                '<strong style="font-size: 0.85rem;">💬 Observaciones de Soporte</strong>' +
                '<button class="btn-toggle-comentarios" onclick="toggleComentarios(' + s.id + ', event)" style="background: none; border: none; color: var(--accent); cursor: pointer; font-size: 0.75rem; padding: 4px 8px; border-radius: 6px;">Mostrar comentarios ▼</button>' +
                '</div>' +
                '<div id="comentarios-' + s.id + '" class="comentarios-lista" style="display: none; max-height: 300px; overflow-y: auto; background: var(--surface2); border-radius: 12px; padding: 12px;">' +
                '<div style="text-align: center; padding: 20px; color: var(--muted);">Cargando Observaciones...</div>' +
                '</div>' +
                '</div>';
            
            // SECCIÓN DE ARCHIVOS ADJUNTOS
            html += '<div class="archivos-section" style="margin-top: 20px; padding-top: 16px; border-top: 1px solid var(--border);">' +
                '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">' +
                '<strong style="font-size: 0.85rem;">📎 Archivos Adjuntos</strong>' +
                '</div>' +
                '<div id="archivos-' + s.id + '" class="archivos-lista" style="max-height: 200px; overflow-y: auto; background: var(--surface2); border-radius: 12px; padding: 8px;">' +
                '<div style="text-align: center; padding: 20px; color: var(--muted);">Cargando archivos...</div>' +
                '</div>' +
                '</div>';
            
            html += '</div>';
        }
        
        resultadosDiv.innerHTML = html;
        
        // Cargar archivos para cada solicitud
        for (var j = 0; j < data.solicitudes.length; j++) {
            var sid = data.solicitudes[j].id;
            cargarArchivosPublicos(sid);
        }
        
        var wrapper = document.getElementById("resultadosWrapper");
        if (wrapper) {
            wrapper.scrollTop = 0;
        }
    })
    .catch(function(error) {
        console.error("Error:", error);
        resultadosDiv.innerHTML = '<div class="empty-state-custom"><div class="icon">❌</div><p>Error al buscar solicitudes</p></div>';
        showToast("Error de conexión", "error");
    });
}

// ========== INICIALIZACIÓN ==========
document.addEventListener("DOMContentLoaded", function() {
    var searchNombre = document.getElementById("searchNombre");
    var searchId = document.getElementById("searchId");
    
    if (searchNombre) {
        searchNombre.addEventListener("keypress", function(e) {
            if (e.key === "Enter") buscarSolicitudes();
        });
    }
    
    if (searchId) {
        searchId.addEventListener("keypress", function(e) {
            if (e.key === "Enter") buscarSolicitudes();
        });
    }
    
    // Si hay parámetros en la URL, buscar automáticamente
    var urlParams = new URLSearchParams(window.location.search);
    var idParam = urlParams.get('id');
    var nombreParam = urlParams.get('nombre');
    
    if (idParam && searchId) {
        searchId.value = idParam;
        buscarSolicitudes();
    } else if (nombreParam && searchNombre) {
        searchNombre.value = nombreParam;
        buscarSolicitudes();
    }
});