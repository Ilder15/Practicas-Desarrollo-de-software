// ========== VARIABLES GLOBALES ==========
let idSolicitudActiva = null;
let editandoSolicitudId = null;
let editandoId = null;
let asignandoId = null;
let notifPanelAbierto = false;
let solicitudesData = [];
let auditoriaData = [];

// Datos de la sesion
const token = localStorage.getItem("token");
const nombre = localStorage.getItem("nombre");
const tipo = localStorage.getItem("tipo");

const categoriaLabel = {
    software: "Software",
    hardware: "Hardware",
    visitas_tecnicas: "Visitas Técnicas",
};

// Variables para filtros
let filtroEstadoActual = "todos";
let filtroPrioridadActual = "todos";
let filtroTipoActual = "todos";

if (!token) window.location.href = "/login";

// ========== CONFIGURACIÓN UI ==========
if (nombre) {
    document.getElementById("nombreAdmin").textContent = nombre;
    document.getElementById("avatarInitial").textContent = nombre.charAt(0).toUpperCase();
}

// Mostrar el rol del usuario
const roles = { 1: "Administrador", 2: "Tecnico" };
const rolEl = document.querySelector(".user-role");
if (rolEl) rolEl.textContent = roles[tipo] || "Tecnico";

// Ocultar secciones si no es admin
if (tipo !== "1") {
    document.querySelectorAll(".sidenav-link").forEach((link) => {
        const texto = link.querySelector("span")?.textContent.trim();
        if (["Usuarios", "Reportes", "Auditoria", "Configuración"].includes(texto)) {
            link.style.display = "none";
        }
    });
}

// ========== FUNCIONES UTILITY ==========
function escapeHtml(text) {
    if (!text) return text;
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showToast(msg, type = "success") {
    const t = document.getElementById("toast");
    t.textContent = msg;
    t.className = `toast ${type} show`;
    setTimeout(() => t.classList.remove("show"), 3000);
}

function formatFecha(fecha) {
    if (!fecha) return "—";
    return new Date(fecha).toLocaleDateString("es-CO", {
        day: "2-digit",
        month: "short",
        year: "numeric",
    });
}

function formatFechaHora(fecha) {
    if (!fecha) return "—";
    return new Date(fecha).toLocaleString("es-CO", {
        day: "2-digit",
        month: "short",
        hour: "2-digit",
        minute: "2-digit"
    });
}

// ========== API FETCH ==========
async function apiFetch(url, options = {}) {
    try {
        const res = await fetch(url, {
            ...options,
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token,
                ...options.headers,
            },
        });
        
        if (res.status === 401) {
            localStorage.clear();
            window.location.href = "/login";
            return null;
        }
        
        return res;
    } catch (error) {
        console.error("Error en apiFetch:", error);
        return null;
    }
}

// ========== SIDENAV ==========
function toggleSidenav() {
    document.getElementById("sidenav").classList.toggle("collapsed");
}

const sectionTitles = {
    solicitudes: "Solicitudes",
    usuarios: "Usuarios",
    reportes: "Reportes",
    configuracion: "Configuración",
    auditoria: "Auditoría",
};

window.switchSection = function(name, btn) {
    document.querySelectorAll(".page-section").forEach(s => s.classList.remove("active"));
    document.querySelectorAll(".sidenav-link").forEach(l => l.classList.remove("active"));
    
    const targetSection = document.getElementById("sec-" + name);
    if (targetSection) {
        targetSection.classList.add("active");
    } else {
        console.error(`❌ Sección "sec-${name}" no encontrada`);
        return;
    }
    
    btn.classList.add("active");
    document.getElementById("topbarTitle").textContent = sectionTitles[name] || name;

    if (name === "usuarios") {
        setTimeout(() => cargarUsuarios(), 50);
    }
    if (name === "auditoria") {
        setTimeout(() => cargarAuditoria(), 50);
    }
    if (name === "solicitudes") {
        cargarSolicitudes();
    }
};

// ========== TABS ==========
window.switchTab = function(name, btn) {
    document.querySelectorAll(".sub-section").forEach(s => s.classList.remove("active"));
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.getElementById("sec-" + name).classList.add("active");
    btn.classList.add("active");
};

// ========== SOLICITUDES ==========
async function cargarSolicitudes() {
    try {
        const res = await apiFetch("/api/solicitudes");
        if (!res) return;
        const data = await res.json();
        solicitudesData = data.registros || [];
        renderTabla(solicitudesData);
        actualizarStats(solicitudesData);
        renderRecientes(solicitudesData);

        const recientesCard = document.querySelector(".recientes-card");
        if (recientesCard) recientesCard.style.display = tipo === "1" ? "block" : "none";
    } catch (e) {
        document.getElementById("tablaSolicitudes").innerHTML = `<td colspan="9"><div class="empty-state">❌ Error al cargar datos</div></td>`;
    }
}

function actualizarStats(data) {
    document.getElementById("statTotal").textContent = data.length;
    document.getElementById("statPendiente").textContent = data.filter(s => s.estado === "pendiente").length;
    document.getElementById("statResuelto").textContent = data.filter(s => s.estado === "resuelto").length;
    document.getElementById("statProceso").textContent = data.filter(s => s.estado === "en proceso").length;
}

function renderTabla(data) {
    const tbody = document.getElementById("tablaSolicitudes");
    if (!data.length) {
        tbody.innerHTML = `<td colspan="9"><div class="empty-state">📭 No hay solicitudes</div></td>`;
        return;
    }
    
    tbody.innerHTML = data.map(s => {
        const noResuelto = s.estado !== "resuelto";
        const mostrarBotonReasignacion = noResuelto && s.asignado_a && s.asignado_a.toLowerCase() === nombre?.toLowerCase() && tipo !== "1";
        
        let slaClass = "badge-sla-pendiente";
        let slaTexto = "⏳ Pendiente";
        
        if (s.estado === "resuelto") {
            if (s.sla_vencimiento && s.fecha_resuelto) {
                const vencimiento = new Date(s.sla_vencimiento);
                const fechaResuelto = new Date(s.fecha_resuelto);
                if (!isNaN(vencimiento.getTime()) && !isNaN(fechaResuelto.getTime())) {
                    if (fechaResuelto > vencimiento) {
                        const diffMs = fechaResuelto - vencimiento;
                        const horasRetraso = Math.floor(diffMs / (1000 * 60 * 60));
                        const minutosRetraso = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                        slaTexto = horasRetraso > 0 ? `⚠️ Cumplido con ${horasRetraso}h ${minutosRetraso}m de retraso` : `⚠️ Cumplido con ${minutosRetraso}m de retraso`;
                        slaClass = "badge-sla-retraso";
                    } else {
                        slaTexto = "✅ Cumplido a tiempo";
                        slaClass = "badge-sla-cumplido";
                    }
                } else {
                    slaTexto = "✅ Cumplido";
                    slaClass = "badge-sla-cumplido";
                }
            } else {
                slaTexto = "✅ Cumplido";
                slaClass = "badge-sla-cumplido";
            }
        } else if (s.sla_vencimiento) {
            const ahora = new Date();
            const vencimiento = new Date(s.sla_vencimiento);
            if (!isNaN(vencimiento.getTime())) {
                if (ahora > vencimiento) {
                    const diffMs = ahora - vencimiento;
                    const horasVencido = Math.floor(diffMs / (1000 * 60 * 60));
                    const minutosVencido = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                    slaClass = "badge-sla-vencido";
                    slaTexto = horasVencido > 0 ? `⚠️ VENCIDO (${horasVencido}h ${minutosVencido}m)` : `⚠️ VENCIDO (${minutosVencido}m)`;
                } else {
                    const diffMs = vencimiento - ahora;
                    const horasRestantes = Math.floor(diffMs / (1000 * 60 * 60));
                    const minutosRestantes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                    if (horasRestantes > 0) {
                        slaTexto = `🟢 ${horasRestantes}h ${minutosRestantes}m`;
                    } else if (minutosRestantes > 0) {
                        slaTexto = `🟢 ${minutosRestantes}m`;
                    } else {
                        slaTexto = `🟢 < 1m`;
                    }
                    slaClass = "badge-sla-ok";
                }
            }
        }
        
        return `
            <tr>
                <td style="color:var(--muted)">#${s.id}</td>
                <td><strong>${escapeHtml(s.cliente)}</strong></td>
                <td>${escapeHtml(s.persona_reporta || "—")}</td>
                <td>${s.tipo_soporte}</td>
                <td><span class="badge badge-${s.prioridad}">${s.prioridad}</span></td>
                <td><span class="badge badge-${s.estado === "en proceso" ? "proceso" : s.estado}">${s.estado}</span></td>
                <td><span class="badge ${slaClass}">${slaTexto}</span></td>
                ${tipo === "1" ? `<td style="color:var(--muted);">${s.asignado_a || "—"}</td>` : ""}
                <td class="action-cell">
                    <div class="menu-container">
                        <button class="btn-dots" onclick="toggleActionMenu(event, ${s.id})">⋮</button>
                        <div id="menu-${s.id}" class="dropdown-actions">
                            <button onclick="verDetalles(${s.id})">📋 Ver Detalles</button>
                            ${noResuelto ? `<button onclick="abrirEditarEstado(${s.id}, '${s.estado}')">🔄 Editar Estado</button>` : ""}
                            ${noResuelto ? `<div class="divider"></div>` : ""}
                            ${tipo === "1" ? `<button onclick="abrirEditarSolicitud(${s.id})">✏️ Editar</button>` : ""}
                            ${noResuelto && !s.asignado_a ? `<button onclick="asignarme(${s.id})">👤 Asignarme</button>` : ""}
                            ${noResuelto && !s.asignado_a && tipo === "1" ? `<button onclick="asignarA(${s.id})">👥 Asignar a...</button>` : ""}
                            ${tipo === "1" && s.asignado_a ? `<button onclick="reasignarA(${s.id})">🔄 Reasignar</button>` : ""}
                            ${mostrarBotonReasignacion ? `<button class="request-reasign" onclick="solicitarReasignacion(${s.id})">📢 Solicitar Reasignación</button>` : ""}
                            ${noResuelto ? `<button class="resolve-opt" onclick="resolver(${s.id})">✅ Resolver</button>` : ""}
                            ${tipo === "1" ? `<div class="divider"></div><button class="delete-opt" onclick="borrarSolicitud(${s.id})">🗑️ Eliminar</button>` : ""}
                        </div>
                    </div>
                </td>
            </tr>
        `;
    }).join("");
}

function renderRecientes(data) {
    const sinAsignar = data.filter(s => !s.asignado_a && s.estado !== "resuelto").slice(0, 5);
    const total = data.filter(s => !s.asignado_a && s.estado !== "resuelto").length;
    
    document.getElementById("recientesCount").textContent = `${total} pendientes`;
    const lista = document.getElementById("recientesLista");
    
    if (!sinAsignar.length) {
        lista.innerHTML = `<div class="reciente-empty">✅ Todas las solicitudes están asignadas</div>`;
        return;
    }
    
    lista.innerHTML = sinAsignar.map(s => `
        <div class="reciente-item">
            <div class="reciente-info">
                <span class="reciente-cliente">${escapeHtml(s.cliente)}</span>
                <span class="reciente-meta">${s.tipo_soporte} · ${formatFecha(s.fecha_reporte)}</span>
            </div>
            <div class="reciente-right">
                <span class="badge badge-${s.prioridad}">${s.prioridad}</span>
                <button class="btn-action" onclick="verDetalles(${s.id})">Ver</button>
                <button class="btn-action" onclick="asignarA(${s.id})">Asignar</button>
                <button class="btn-action" onclick="asignarme(${s.id})">Asignarme</button>
            </div>
        </div>
    `).join("");
}

// ========== CREAR SOLICITUD ==========
window.crearSolicitud = async function() {
    const body = {
        cliente: document.getElementById("f-cliente").value.trim(),
        persona_reporta: nombre,
        tipo_soporte: document.getElementById("f-tipo").value,
        prioridad: document.getElementById("f-prioridad").value,
        estado: document.getElementById("f-estado").value,
        descripcion: document.getElementById("f-descripcion").value.trim(),
    };
    
    const archivosInput = document.getElementById("f-archivos-dashboard");
    const archivos = archivosInput ? archivosInput.files : [];
    
    if (!body.cliente || !body.tipo_soporte || !body.prioridad) {
        showToast("Completa todos los campos obligatorios", "error");
        return;
    }
    
    for (let i = 0; i < archivos.length; i++) {
        if (archivos[i].size > 16 * 1024 * 1024) {
            showToast(`El archivo ${archivos[i].name} supera el límite de 16MB`, "error");
            return;
        }
    }
    
    const btn = document.querySelector('#sec-crear .btn-primary');
    const originalText = btn.textContent;
    btn.textContent = "Enviando...";
    btn.disabled = true;
    
    try {
        const res = await apiFetch("/api/solicitudes", {
            method: "POST",
            body: JSON.stringify(body),
        });
        
        if (!res) return;
        const data = await res.json();
        
        if (res.ok) {
            const idSolicitud = data.id;
            showToast(`Solicitud creada (ID: ${idSolicitud})`, "success");
            
            if (archivos && archivos.length > 0) {
                showToast(`Subiendo ${archivos.length} archivo(s)...`, "success");
                for (let i = 0; i < archivos.length; i++) {
                    const formData = new FormData();
                    formData.append("archivo", archivos[i]);
                    try {
                        const uploadRes = await fetch(`/api/solicitudes/${idSolicitud}/archivos`, {
                            method: "POST",
                            headers: { "Authorization": "Bearer " + token },
                            body: formData
                        });
                        if (!uploadRes.ok) {
                            const errorData = await uploadRes.json();
                            showToast(`Error al subir ${archivos[i].name}: ${errorData.error || "Error"}`, "error");
                        }
                    } catch (uploadError) {
                        showToast(`Error al subir ${archivos[i].name}`, "error");
                    }
                }
            }
            
            document.getElementById("f-cliente").value = "";
            document.getElementById("f-descripcion").value = "";
            document.getElementById("f-tipo").value = "";
            document.getElementById("f-prioridad").value = "";
            if (archivosInput) archivosInput.value = "";
            
            switchTab("lista", document.querySelector(".tab"));
            await cargarSolicitudes();
        } else {
            showToast(data.error || "Error al crear la solicitud", "error");
        }
    } catch (e) {
        showToast("Error de conexión", "error");
    } finally {
        btn.textContent = originalText;
        btn.disabled = false;
    }
};

// ========== ELIMINAR SOLICITUD ==========
window.borrarSolicitud = async function(id) {
    if (!confirm("¿Eliminar esta solicitud?")) return;
    const res = await apiFetch(`/api/solicitudes/${id}`, { method: "DELETE" });
    if (res?.ok) {
        showToast("Solicitud eliminada ✓", "success");
        await cargarSolicitudes();
    } else {
        showToast("Error al eliminar", "error");
    }
};

// ========== EDITAR SOLICITUD ==========
window.abrirEditarSolicitud = function(id) {
    const s = solicitudesData.find(s => s.id === id);
    if (!s) return;
    editandoSolicitudId = id;
    idSolicitudActiva = id;
    document.getElementById("es-cliente").value = s.cliente || "";
    document.getElementById("es-descripcion").value = s.descripcion || "";
    document.getElementById("es-tipo").value = s.tipo_soporte || "";
    document.getElementById("es-prioridad").value = s.prioridad || "";
    document.getElementById("modalEditarSolicitud").classList.add("open");
};

window.cerrarModalEditarSolicitud = function() {
    document.getElementById("modalEditarSolicitud").classList.remove("open");
    editandoSolicitudId = null;
};

window.guardarEdicionSolicitud = async function() {
    const cliente = document.getElementById("es-cliente").value.trim();
    const descripcion = document.getElementById("es-descripcion").value.trim();
    const tipo = document.getElementById("es-tipo").value;
    const prioridad = document.getElementById("es-prioridad").value;
    
    if (!cliente || !tipo || !prioridad) {
        showToast("Cliente, tipo y prioridad son obligatorios", "error");
        return;
    }
    
    const res = await apiFetch(`/api/solicitudes/${editandoSolicitudId}`, {
        method: "PUT",
        body: JSON.stringify({ cliente, descripcion, tipo_soporte: tipo, prioridad })
    });
    
    if (res?.ok) {
        showToast("Solicitud actualizada ✓", "success");
        cerrarModalEditarSolicitud();
        await cargarSolicitudes();
    } else {
        showToast("Error al actualizar", "error");
    }
};

// ========== EXPORTAR SOLICITUDES ==========
window.exportarCSV = async function() {
    try {
        showToast("Generando archivo CSV...", "success");
        const response = await apiFetch("/api/solicitudes/exportar/csv", { method: "GET" });
        if (!response) return;
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "solicitudes.csv";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        showToast("Exportación completada ✓", "success");
    } catch (error) {
        showToast("Error al exportar", "error");
    }
};

window.exportarExcel = async function() {
    try {
        showToast("Generando archivo Excel...", "success");
        const response = await apiFetch("/api/solicitudes/exportar/excel", { method: "GET" });
        if (!response) return;
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "solicitudes.xlsx";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        showToast("Exportación completada ✓", "success");
    } catch (error) {
        showToast("Error al exportar", "error");
    }
};

window.exportarConFiltros = exportarConFiltros;

async function exportarConFiltros() {
    try {
        const formato = await mostrarDialogoFormato();
        if (!formato) return;
        
        const filtros = {
            estado: filtroEstadoActual,
            prioridad: filtroPrioridadActual,
            tipo_soporte: filtroTipoActual,
            desde: document.getElementById("filtroDesde")?.value || "",
            hasta: document.getElementById("filtroHasta")?.value || "",
            busqueda: document.getElementById("searchInput")?.value || ""
        };
        
        const response = await apiFetch("/api/solicitudes/exportar/filtrado", {
            method: "POST",
            body: JSON.stringify({ formato: formato, filtros: filtros })
        });
        
        if (!response) return;
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        const fecha = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
        const extension = formato === 'excel' ? 'xlsx' : 'csv';
        a.download = `solicitudes_filtradas_${fecha}.${extension}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        showToast("Exportación completada ✓", "success");
    } catch (error) {
        showToast("Error al exportar", "error");
    }
}

function mostrarDialogoFormato() {
    return new Promise((resolve) => {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.style.display = 'flex';
        modal.style.opacity = '1';
        modal.style.visibility = 'visible';
        modal.innerHTML = `
            <div class="modal" style="max-width: 400px;">
                <h3 style="margin-bottom: 20px;">📁 Seleccionar formato de exportación</h3>
                <p style="color: var(--muted); margin-bottom: 20px; font-size: 0.85rem;">¿En qué formato deseas exportar las solicitudes filtradas?</p>
                <div style="display: flex; gap: 12px; margin-bottom: 20px;">
                    <button id="btnFormatoCSV" style="flex: 1; padding: 12px; background: var(--surface2); border: 1px solid var(--border); border-radius: 10px; cursor: pointer;">CSV</button>
                    <button id="btnFormatoExcel" style="flex: 1; padding: 12px; background: var(--surface2); border: 1px solid var(--border); border-radius: 10px; cursor: pointer;">Excel</button>
                </div>
                <button id="btnCancelarFormato" class="btn-secondary" style="width: 100%;">Cancelar</button>
            </div>
        `;
        document.body.appendChild(modal);
        
        document.getElementById("btnFormatoCSV").onclick = () => { modal.remove(); resolve('csv'); };
        document.getElementById("btnFormatoExcel").onclick = () => { modal.remove(); resolve('excel'); };
        document.getElementById("btnCancelarFormato").onclick = () => { modal.remove(); resolve(null); };
        modal.onclick = (e) => { if (e.target === modal) { modal.remove(); resolve(null); } };
    });
}

// ========== EDITAR ESTADO ==========
window.abrirEditarEstado = function(id, estadoActual) {
    editandoId = id;
    document.getElementById("modal-estado").value = estadoActual;
    document.getElementById("modalEditar").classList.add("open");
};

window.cerrarModal = function() {
    document.getElementById("modalEditar").classList.remove("open");
    editandoId = null;
};

window.guardarEdicionEstado = async function() {
    const estado = document.getElementById("modal-estado").value;
    const res = await apiFetch(`/api/editar_solicitud/${editandoId}`, {
        method: "PUT",
        body: JSON.stringify({ estado })
    });
    if (res?.ok) {
        showToast("Estado actualizado ✓", "success");
        cerrarModal();
        await cargarSolicitudes();
    } else {
        showToast("Error al actualizar", "error");
    }
};

// ========== RESOLVER ==========
window.resolver = async function(id) {
    const res = await apiFetch(`/api/resolver/${id}`, {
        method: "PUT",
        body: JSON.stringify({ asignado_a: nombre })
    });
    if (res?.ok) {
        showToast("Solicitud resuelta ✓", "success");
        await cargarSolicitudes();
    } else {
        showToast("Error al resolver", "error");
    }
};

// ========== ASIGNAR ==========
window.asignarme = async function(id) {
    const res = await apiFetch(`/api/asignar/${id}`, {
        method: "PUT",
        body: JSON.stringify({ asignado_a: nombre })
    });
    if (res?.ok) {
        showToast("Solicitud asignada ✓", "success");
        await cargarSolicitudes();
    } else {
        showToast("Error al asignar", "error");
    }
};

window.asignarA = async function(id) {
    asignandoId = id;
    const res = await apiFetch("/api/usuarios");
    if (!res) return;
    const data = await res.json();
    const select = document.getElementById("modal-usuario-asignar");
    select.innerHTML = (data.usuarios || []).map(u => {
        const cat = categoriaLabel[u.categoria] || "Sin categoría";
        return `<option value="${escapeHtml(u.nombre)}">${escapeHtml(u.nombre)} — ${cat}</option>`;
    }).join('');
    document.getElementById("modalAsignar").dataset.modo = "asignar";
    document.getElementById("modalAsignar").classList.add("open");
};

window.reasignarA = async function(id) {
    asignandoId = id;
    const res = await apiFetch("/api/usuarios");
    if (!res) return;
    const data = await res.json();
    const select = document.getElementById("modal-usuario-asignar");
    select.innerHTML = (data.usuarios || []).map(u => {
        const cat = categoriaLabel[u.categoria] || "Sin categoría";
        return `<option value="${escapeHtml(u.nombre)}">${escapeHtml(u.nombre)} — ${cat}</option>`;
    }).join('');
    document.getElementById("modalAsignar").dataset.modo = "reasignar";
    document.getElementById("modalAsignar").classList.add("open");
};

window.cerrarModalAsignar = function() {
    document.getElementById("modalAsignar").classList.remove("open");
    asignandoId = null;
};

window.confirmarAsignar = async function() {
    const usuario = document.getElementById("modal-usuario-asignar").value;
    if (!usuario) return;
    const modo = document.getElementById("modalAsignar").dataset.modo;
    const url = modo === "reasignar" ? `/api/reasignar/${asignandoId}` : `/api/asignar/${asignandoId}`;
    const res = await apiFetch(url, {
        method: "PUT",
        body: JSON.stringify({ asignado_a: usuario })
    });
    if (res?.ok) {
        showToast(`${modo === "reasignar" ? "Reasignado" : "Asignado"} a ${usuario} ✓`, "success");
        cerrarModalAsignar();
        await cargarSolicitudes();
    } else {
        showToast("Error al asignar", "error");
    }
};

// ========== FUNCIONES PARA PESTAÑAS DEL MODAL ==========
function mostrarSeccionHistorial(seccion) {
    document.querySelectorAll('.seccion-historial').forEach(s => s.style.display = 'none');
    document.querySelectorAll('.tab-historial').forEach(t => t.style.color = 'var(--muted)');
    
    if (seccion === 'detalles') {
        document.getElementById('seccion-detalles').style.display = 'block';
        document.querySelector('.tab-historial:first-child').style.color = 'var(--accent)';
    } else if (seccion === 'historial') {
        document.getElementById('seccion-historial').style.display = 'block';
        document.querySelector('.tab-historial:nth-child(2)').style.color = 'var(--accent)';
        cargarHistorial(idSolicitudActiva);
    } else if (seccion === 'comentarios') {
        document.getElementById('seccion-comentarios').style.display = 'block';
        document.querySelector('.tab-historial:nth-child(3)').style.color = 'var(--accent)';
    } else if (seccion === 'archivos') {
        document.getElementById('seccion-archivos').style.display = 'block';
        document.querySelector('.tab-historial:nth-child(4)').style.color = 'var(--accent)';
        cargarArchivosModal(idSolicitudActiva);
    }
}

// ========== CARGAR HISTORIAL ==========
async function cargarHistorial(idSolicitud) {
    const container = document.getElementById('historial-container');
    if (!container) return;
    container.innerHTML = '<div style="text-align:center; padding:40px;">⏳ Cargando historial...</div>';
    
    try {
        const res = await apiFetch(`/api/solicitudes/${idSolicitud}/historial`);
        if (!res) return;
        const data = await res.json();
        const historial = data.historial || [];
        if (!historial.length) {
            container.innerHTML = '<div style="text-align:center; padding:40px;">📭 No hay registros en el historial</div>';
            return;
        }
        
        let html = '<div style="position: relative; padding-left: 20px;">';
        for (let i = 0; i < historial.length; i++) {
            const item = historial[i];
            html += `
                <div style="position: relative; padding-bottom: 20px; border-left: 2px solid ${item.color}; padding-left: 20px; margin-left: 10px;">
                    <div style="position: absolute; left: -9px; top: 0; width: 16px; height: 16px; border-radius: 50%; background: ${item.color}; display: flex; align-items: center; justify-content: center; font-size: 10px;">${item.icono}</div>
                    <div style="background: var(--surface2); border-radius: 8px; padding: 12px; margin-bottom: 8px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; margin-bottom: 6px;">
                            <strong style="color: ${item.color};">${item.icono} ${item.accion.replace('_', ' ').toUpperCase()}</strong>
                            <span style="font-size: 0.7rem; color: var(--muted);">${formatFechaHora(item.fecha)}</span>
                        </div>
                        <div style="font-size: 0.85rem; margin-bottom: 4px;">${escapeHtml(item.descripcion)}</div>
                        <div style="font-size: 0.7rem; color: var(--muted);">Por: ${escapeHtml(item.usuario)}</div>
                    </div>
                </div>
            `;
        }
        html += '</div>';
        container.innerHTML = html;
    } catch (error) {
        container.innerHTML = '<div style="text-align:center; padding:40px;">❌ Error al cargar el historial</div>';
    }
}

// ========== VER DETALLES ==========
window.verDetalles = function(id) {
    const s = solicitudesData.find(s => s.id === id);
    if (!s) {
        showToast("Solicitud no encontrada", "error");
        return;
    }
    idSolicitudActiva = id;
    
    document.getElementById("modal-detalles").innerHTML = `
        <div class="detalle-grid">
            <div class="detalle-item"><span class="detalle-label">ID</span><span class="detalle-valor">#${s.id}</span></div>
            <div class="detalle-item"><span class="detalle-label">Estado</span><span class="badge badge-${s.estado === 'en proceso' ? 'proceso' : s.estado}">${s.estado}</span></div>
            <div class="detalle-item"><span class="detalle-label">Cliente</span><span class="detalle-valor">${escapeHtml(s.cliente)}</span></div>
            <div class="detalle-item"><span class="detalle-label">Reportado por</span><span class="detalle-valor">${escapeHtml(s.persona_reporta || "—")}</span></div>
            <div class="detalle-item"><span class="detalle-label">Tipo</span><span class="detalle-valor">${s.tipo_soporte}</span></div>
            <div class="detalle-item"><span class="detalle-label">Prioridad</span><span class="badge badge-${s.prioridad}">${s.prioridad}</span></div>
            <div class="detalle-item"><span class="detalle-label">Fecha</span><span class="detalle-valor">${formatFechaHora(s.fecha_reporte)}</span></div>
            <div class="detalle-item"><span class="detalle-label">Resuelta</span><span class="detalle-valor">${formatFechaHora(s.fecha_resuelto)}</span></div>
            ${s.asignado_a ? `<div class="detalle-item full"><span class="detalle-label">Asignado</span><span class="detalle-valor">${escapeHtml(s.asignado_a)}</span></div>` : ""}
            <div class="detalle-item full"><span class="detalle-label">Descripción</span><span class="detalle-valor">${escapeHtml(s.descripcion || "—")}</span></div>
        </div>
    `;
    mostrarSeccionHistorial('detalles');
    cargarComentarios(id);
    cargarArchivosModal(id);
    document.getElementById("modalDetalles").classList.add("open");
};

window.cerrarModalDetalles = function() {
    document.getElementById("modalDetalles").classList.remove("open");
    idSolicitudActiva = null;
};

// ========== COMENTARIOS ==========
async function cargarComentarios(id) {
    const res = await apiFetch(`/api/solicitudes/${id}/comentarios`);
    if (!res) return;
    const data = await res.json();
    const box = document.getElementById("chatBox");
    if (!box) return;
    
    if (!data.comentarios?.length) {
        box.innerHTML = '<div style="text-align:center; padding:20px;">💬 No hay comentarios aún.</div>';
        return;
    }
    
    box.innerHTML = data.comentarios.map(c => `
        <div class="chat-msg ${c.usuario === nombre ? 'me' : 'other'}">
            <div class="msg-header">
                <span class="msg-user">${escapeHtml(c.usuario)}</span>
                <span class="msg-time">${new Date(c.fecha).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</span>
            </div>
            <div class="msg-body">${escapeHtml(c.mensaje)}</div>
        </div>
    `).join('');
    box.scrollTop = box.scrollHeight;
}

window.enviarComentario = async function() {
    const input = document.getElementById("inputComentario");
    const mensaje = input.value.trim();
    if (!mensaje || !idSolicitudActiva) return;
    const res = await apiFetch(`/api/solicitudes/${idSolicitudActiva}/comentarios`, {
        method: "POST",
        body: JSON.stringify({ mensaje })
    });
    if (res?.ok) {
        input.value = "";
        await cargarComentarios(idSolicitudActiva);
    }
};

// ========== ARCHIVOS EN MODAL ==========
function mostrarSubirArchivoModal() {
    const form = document.getElementById("form-subir-archivo-modal");
    if (form) form.style.display = "block";
}

function ocultarSubirArchivoModal() {
    const form = document.getElementById("form-subir-archivo-modal");
    const input = document.getElementById("archivo-input-modal");
    if (form) form.style.display = "none";
    if (input) input.value = "";
}

async function subirArchivoModal() {
    const fileInput = document.getElementById("archivo-input-modal");
    const file = fileInput?.files[0];
    if (!file) {
        showToast("Selecciona un archivo", "error");
        return;
    }
    if (file.size > 16 * 1024 * 1024) {
        showToast("El archivo no puede superar 16MB", "error");
        return;
    }
    
    const formData = new FormData();
    formData.append("archivo", file);
    const btn = event.target;
    const originalText = btn.textContent;
    btn.textContent = "Subiendo...";
    btn.disabled = true;
    
    try {
        const res = await fetch(`/api/solicitudes/${idSolicitudActiva}/archivos`, {
            method: "POST",
            headers: { "Authorization": "Bearer " + token },
            body: formData
        });
        const data = await res.json();
        if (res.ok) {
            showToast("Archivo subido ✓", "success");
            ocultarSubirArchivoModal();
            await cargarArchivosModal(idSolicitudActiva);
        } else {
            showToast(data.error || "Error al subir", "error");
        }
    } catch (error) {
        showToast("Error de conexión", "error");
    } finally {
        btn.textContent = originalText;
        btn.disabled = false;
    }
}

async function cargarArchivosModal(idSolicitud) {
    const container = document.getElementById("lista-archivos-modal");
    if (!container) return;
    container.innerHTML = '<div style="text-align:center; padding:20px;">⏳ Cargando...</div>';
    
    try {
        const res = await fetch(`/api/solicitudes/${idSolicitud}/archivos`, {
            headers: { "Authorization": "Bearer " + token }
        });
        if (!res.ok) throw new Error();
        const data = await res.json();
        if (!data.archivos?.length) {
            container.innerHTML = '<div style="text-align:center; padding:20px;">📎 No hay archivos</div>';
            return;
        }
        const esAdmin = tipo === "1";
        container.innerHTML = data.archivos.map(a => `
            <div class="archivo-item" style="display:flex; justify-content:space-between; align-items:center; padding:8px; border-bottom:1px solid var(--border);">
                <div style="display:flex; align-items:center; gap:10px;">
                    <span>${getIconoArchivo(a.tipo)}</span>
                    <div>
                        <div style="font-weight:500;">${escapeHtml(a.nombre_original)}</div>
                        <div style="font-size:0.7rem; color:var(--muted);">${a.tamano || '?'} · ${formatFecha(a.fecha_subida)}</div>
                    </div>
                </div>
                <div style="display:flex; gap:8px;">
                    <button class="btn-action" onclick="descargarArchivoModal(${a.id})">📥 Descargar</button>
                    ${esAdmin ? `<button class="btn-action delete" onclick="eliminarArchivoModal(${a.id})">🗑 Eliminar</button>` : ""}
                </div>
            </div>
        `).join('');
    } catch (error) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">❌ Error al cargar</div>';
    }
}

function getIconoArchivo(tipo) {
    if (!tipo) return "📎";
    if (tipo.includes("image")) return "🖼️";
    if (tipo.includes("pdf")) return "📄";
    if (tipo.includes("word") || tipo.includes("document")) return "📝";
    if (tipo.includes("excel") || tipo.includes("sheet")) return "📊";
    if (tipo.includes("zip") || tipo.includes("compressed")) return "🗜️";
    return "📎";
}

async function descargarArchivoModal(idArchivo) {
    try {
        const response = await fetch(`/api/archivos/${idArchivo}/descargar`, {
            method: "GET",
            headers: { "Authorization": "Bearer " + token }
        });
        if (!response.ok) {
            showToast("Error al descargar", "error");
            return;
        }
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "archivo";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        showToast("Descargando archivo...", "success");
    } catch (error) {
        showToast("Error de conexión al descargar", "error");
    }
}

async function eliminarArchivoModal(idArchivo) {
    if (!confirm("¿Eliminar este archivo?")) return;
    const res = await fetch(`/api/archivos/${idArchivo}`, {
        method: "DELETE",
        headers: { "Authorization": "Bearer " + token }
    });
    if (res.ok) {
        showToast("Archivo eliminado ✓", "success");
        await cargarArchivosModal(idSolicitudActiva);
    } else {
        showToast("Error al eliminar", "error");
    }
}

// ========== USUARIOS ==========
async function cargarUsuarios() {
    const lista = document.getElementById("usuariosLista");
    if (!lista) return;
    lista.innerHTML = '<div class="reciente-empty">⏳ Cargando usuarios...</div>';
    
    try {
        const res = await apiFetch("/api/usuarios");
        if (!res) return;
        const data = await res.json();
        const usuarios = data.usuarios || [];
        const usuariosCount = document.getElementById("usuariosCount");
        if (usuariosCount) usuariosCount.textContent = `${usuarios.length} usuarios`;
        if (!usuarios.length) {
            lista.innerHTML = '<div class="reciente-empty">📭 No hay usuarios registrados</div>';
            return;
        }
        lista.innerHTML = usuarios.map(u => {
            const esAdmin = u.tipo === 1 || u.tipo === "1";
            const cat = categoriaLabel[u.categoria] || u.categoria || "Sin categoría";
            return `
                <div class="reciente-item">
                    <div class="usuario-avatar" style="width: 40px; height: 40px; border-radius: 50%; background: var(--accent); display: flex; align-items: center; justify-content: center; font-weight: bold;">${u.nombre ? u.nombre.charAt(0).toUpperCase() : '?'}</div>
                    <div class="reciente-info">
                        <span class="reciente-cliente" style="font-weight: 600;">${escapeHtml(u.nombre)}</span>
                        <span class="reciente-meta">@${escapeHtml(u.usuario)} · ID #${u.id} · ${cat}</span>
                    </div>
                    <div class="reciente-right">
                        <span class="badge ${esAdmin ? "badge-alta" : "badge-proceso"}">${esAdmin ? "Admin" : "Técnico"}</span>
                        <button class="btn-action" onclick='editarUsuario(${u.id}, "${escapeHtml(u.nombre).replace(/"/g, '\\"')}", "${escapeHtml(u.usuario).replace(/"/g, '\\"')}", ${u.tipo}, "${u.categoria || ""}")'>Editar</button>
                        <button class="btn-action delete" onclick="eliminarUsuario(${u.id})">Eliminar</button>
                    </div>
                </div>
            `;
        }).join("");
    } catch (error) {
        lista.innerHTML = '<div class="reciente-empty">❌ Error al cargar usuarios</div>';
    }
}

window.editarUsuario = function(id, nombre, usuario, tipo, categoria) {
    document.getElementById("edit-u-id").value = id;
    document.getElementById("edit-u-nombre").value = nombre;
    document.getElementById("edit-u-usuario").value = usuario;
    document.getElementById("edit-u-tipo").value = tipo;
    document.getElementById("edit-u-categoria").value = categoria || "";
    document.getElementById("modalEditarUsuario").classList.add("open");
};

window.cerrarModalUsuario = function() {
    document.getElementById("modalEditarUsuario").classList.remove("open");
};

window.guardarUsuario = async function() {
    const id = document.getElementById("edit-u-id").value;
    const nombre = document.getElementById("edit-u-nombre").value.trim();
    const usuario = document.getElementById("edit-u-usuario").value.trim();
    const tipo = document.getElementById("edit-u-tipo").value;
    const categoria = document.getElementById("edit-u-categoria").value || null;
    if (!nombre || !usuario) {
        showToast("Completa todos los campos", "error");
        return;
    }
    const res = await apiFetch(`/api/usuarios/${id}`, {
        method: "PUT",
        body: JSON.stringify({ nombre, usuario, tipo, categoria })
    });
    if (res?.ok) {
        showToast("Usuario actualizado ✓", "success");
        cerrarModalUsuario();
        await cargarUsuarios();
    } else {
        showToast("Error al actualizar", "error");
    }
};

window.eliminarUsuario = async function(id) {
    if (!confirm("¿Eliminar este usuario?")) return;
    const res = await apiFetch(`/api/usuarios/${id}`, { method: "DELETE" });
    if (res?.ok) {
        showToast("Usuario eliminado ✓", "success");
        await cargarUsuarios();
    } else {
        showToast("Error al eliminar", "error");
    }
};

window.registrarUsuario = async function() {
    const nombre = document.getElementById("nuevo-nombre").value.trim();
    const usuario = document.getElementById("nuevo-usuario").value.trim();
    const password = document.getElementById("nuevo-password").value;
    const tipo = document.getElementById("nuevo-tipo").value;
    const categoria = document.getElementById("nuevo-categoria").value || null;
    if (!nombre || !usuario || !password) {
        showToast("Completa todos los campos", "error");
        return;
    }
    if (password.length < 6) {
        showToast("La contraseña debe tener al menos 6 caracteres", "error");
        return;
    }
    const res = await apiFetch("/api/usuarios", {
        method: "POST",
        body: JSON.stringify({ nombre, usuario, password, tipo: parseInt(tipo), categoria: categoria })
    });
    if (res?.ok) {
        showToast("Usuario creado ✓", "success");
        document.getElementById("nuevo-nombre").value = "";
        document.getElementById("nuevo-usuario").value = "";
        document.getElementById("nuevo-password").value = "";
        document.getElementById("nuevo-categoria").value = "";
        await cargarUsuarios();
    } else {
        const d = await res.json();
        showToast(d.error || "Error al crear", "error");
    }
};

// ========== AUDITORIA ==========
const etiquetas = {
    crear_solicitud: "🟢 Crear solicitud",
    editar_estado: "🔵 Editar estado",
    editar_solicitud: "✏️ Editar solicitud",
    asignar: "🟡 Asignar",
    reasignar: "🔄 Reasignar",
    resolver: "✅ Resolver",
    eliminar: "🔴 Eliminar solicitud",
    crear_usuario: "🟢 Crear usuario",
    editar_usuario: "✏️ Editar usuario",
    eliminar_usuario: "🔴 Eliminar usuario",
    subir_archivo: "📎 Subir archivo",
    eliminar_archivo: "🗑️ Eliminar archivo",
    comentario_agregado: "💬 Comentario"
};

async function cargarAuditoria() {
    const lista = document.getElementById("auditoriaLista");
    if (!lista) return;
    lista.innerHTML = '<div class="reciente-empty">⏳ Cargando auditoría...</div>';
    
    try {
        const res = await apiFetch("/api/auditoria");
        if (!res) return;
        const data = await res.json();
        auditoriaData = data.registros || [];
        const auditoriaCount = document.getElementById("auditoriaCount");
        if (auditoriaCount) auditoriaCount.textContent = `${auditoriaData.length} registros`;
        
        const usuariosUnicos = [...new Set(auditoriaData.map(r => r.usuario).filter(Boolean))];
        const filtroUsuario = document.getElementById("filtroUsuarioAuditoria");
        if (filtroUsuario) {
            filtroUsuario.innerHTML = '<option value="todos">Todos los usuarios</option>' + usuariosUnicos.map(u => `<option value="${escapeHtml(u)}">${escapeHtml(u)}</option>`).join('');
        }
        aplicarFiltrosAuditoria();
    } catch (error) {
        lista.innerHTML = '<div class="reciente-empty">❌ Error al cargar auditoría</div>';
    }
}

function aplicarFiltrosAuditoria() {
    const lista = document.getElementById("auditoriaLista");
    if (!lista) return;
    const busqueda = document.getElementById("buscarAuditoria")?.value.toLowerCase() || "";
    const accionFiltro = document.getElementById("filtroAccionAuditoria")?.value || "todas";
    const usuarioFiltro = document.getElementById("filtroUsuarioAuditoria")?.value || "todos";
    const desde = document.getElementById("filtroAuditoriaDesde")?.value;
    const hasta = document.getElementById("filtroAuditoriaHasta")?.value;
    
    let filtrados = [...auditoriaData];
    if (busqueda) {
        filtrados = filtrados.filter(r => (r.usuario && r.usuario.toLowerCase().includes(busqueda)) || (r.accion && etiquetas[r.accion] && etiquetas[r.accion].toLowerCase().includes(busqueda)) || (r.detalle && r.detalle.toLowerCase().includes(busqueda)) || (r.id_solicitud && `#${r.id_solicitud}`.includes(busqueda)));
    }
    if (accionFiltro !== "todas") filtrados = filtrados.filter(r => r.accion === accionFiltro);
    if (usuarioFiltro !== "todos") filtrados = filtrados.filter(r => r.usuario === usuarioFiltro);
    if (desde) {
        const desdeDate = new Date(desde);
        desdeDate.setHours(0, 0, 0, 0);
        filtrados = filtrados.filter(r => r.fecha && new Date(r.fecha) >= desdeDate);
    }
    if (hasta) {
        const hastaDate = new Date(hasta);
        hastaDate.setHours(23, 59, 59, 999);
        filtrados = filtrados.filter(r => r.fecha && new Date(r.fecha) <= hastaDate);
    }
    
    const auditoriaCount = document.getElementById("auditoriaCount");
    if (auditoriaCount) auditoriaCount.textContent = `${filtrados.length} registros ${filtrados.length !== auditoriaData.length ? `(de ${auditoriaData.length} totales)` : ''}`;
    if (!filtrados.length) {
        lista.innerHTML = '<div class="reciente-empty">📭 No hay registros que coincidan con los filtros</div>';
        return;
    }
    lista.innerHTML = filtrados.map(r => {
        let detalle = r.detalle || "";
        if (detalle.length > 80) detalle = detalle.substring(0, 80) + "...";
        let fechaStr = "—";
        if (r.fecha) {
            try {
                const fecha = new Date(r.fecha);
                fechaStr = fecha.toLocaleDateString("es-CO") + " " + fecha.toLocaleTimeString("es-CO", {hour: '2-digit', minute:'2-digit'});
            } catch(e) { fechaStr = r.fecha; }
        }
        return `
            <div class="reciente-item" style="padding: 12px;">
                <div class="reciente-info" style="flex: 1;">
                    <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                        <span class="reciente-cliente" style="font-weight: 600;">${etiquetas[r.accion] || r.accion}</span>
                        ${r.id_solicitud ? `<span class="badge badge-info" style="background: rgba(124,106,247,0.15);">Solicitud #${r.id_solicitud}</span>` : ''}
                    </div>
                    ${detalle ? `<div style="font-size: 0.75rem; color: var(--muted); margin-top: 4px;">${escapeHtml(detalle)}</div>` : ''}
                    <div style="display: flex; gap: 12px; margin-top: 6px;">
                        <span style="color: var(--accent); font-size: 0.7rem;">👤 ${escapeHtml(r.usuario)}</span>
                        <span style="color: var(--muted); font-size: 0.7rem;">📅 ${fechaStr}</span>
                    </div>
                </div>
            </div>
        `;
    }).join("");
}

function limpiarFiltrosAuditoria() {
    const buscador = document.getElementById("buscarAuditoria");
    const filtroAccion = document.getElementById("filtroAccionAuditoria");
    const filtroUsuario = document.getElementById("filtroUsuarioAuditoria");
    const desde = document.getElementById("filtroAuditoriaDesde");
    const hasta = document.getElementById("filtroAuditoriaHasta");
    if (buscador) buscador.value = "";
    if (filtroAccion) filtroAccion.value = "todas";
    if (filtroUsuario) filtroUsuario.value = "todos";
    if (desde) desde.value = "";
    if (hasta) hasta.value = "";
    aplicarFiltrosAuditoria();
}

// ========== FILTROS ==========
window.filtrarTabla = function() { aplicarFiltros(); };
window.limpiarFechas = function() {
    document.getElementById("filtroDesde").value = "";
    document.getElementById("filtroHasta").value = "";
    aplicarFiltros();
};

function aplicarFiltros() {
    const q = document.getElementById("searchInput").value.toLowerCase();
    const desde = document.getElementById("filtroDesde").value;
    const hasta = document.getElementById("filtroHasta").value;
    let filtrado = [...solicitudesData];
    if (filtroEstadoActual !== "todos") filtrado = filtrado.filter(s => s.estado === filtroEstadoActual);
    if (filtroPrioridadActual !== "todos") filtrado = filtrado.filter(s => s.prioridad === filtroPrioridadActual);
    if (filtroTipoActual !== "todos") filtrado = filtrado.filter(s => s.tipo_soporte === filtroTipoActual);
    if (desde) filtrado = filtrado.filter(s => s.fecha_reporte && new Date(s.fecha_reporte) >= new Date(desde));
    if (hasta) {
        const hastaFin = new Date(hasta);
        hastaFin.setDate(hastaFin.getDate() + 1);
        filtrado = filtrado.filter(s => s.fecha_reporte && new Date(s.fecha_reporte) < hastaFin);
    }
    if (q) filtrado = filtrado.filter(s => s.cliente.toLowerCase().includes(q) || (s.persona_reporta || "").toLowerCase().includes(q));
    renderTabla(filtrado);
}

// ========== DROPDOWN FILTROS ==========
window.toggleDropdown = function() {
    const options = document.getElementById("filtroOptions");
    const optionsPrioridad = document.getElementById("filtroOptionsPrioridad");
    const tipoOptions = document.getElementById("tipoOptions");
    if (options) options.classList.toggle("open");
    if (optionsPrioridad) optionsPrioridad.classList.remove("open");
    if (tipoOptions) tipoOptions.classList.remove("open");
};

window.seleccionarFiltro = function(valor, label) {
    const labelSpan = document.getElementById("filtroLabel");
    const options = document.getElementById("filtroOptions");
    if (labelSpan) labelSpan.textContent = label;
    if (options) options.classList.remove("open");
    filtroEstadoActual = valor;
    aplicarFiltros();
};

window.toggleDropdownPrioridad = function() {
    const options = document.getElementById("filtroOptionsPrioridad");
    const optionsEstado = document.getElementById("filtroOptions");
    const tipoOptions = document.getElementById("tipoOptions");
    if (options) options.classList.toggle("open");
    if (optionsEstado) optionsEstado.classList.remove("open");
    if (tipoOptions) tipoOptions.classList.remove("open");
};

window.seleccionarFiltroPrioridad = function(valor, label) {
    const labelSpan = document.getElementById("filtroLabelPrioridad");
    const options = document.getElementById("filtroOptionsPrioridad");
    if (labelSpan) labelSpan.textContent = label;
    if (options) options.classList.remove("open");
    filtroPrioridadActual = valor;
    aplicarFiltros();
};

window.toggleDropdownTipo = function() {
    const options = document.getElementById("tipoOptions");
    const optionsEstado = document.getElementById("filtroOptions");
    const optionsPrioridad = document.getElementById("filtroOptionsPrioridad");
    if (options) options.classList.toggle("open");
    if (optionsEstado) optionsEstado.classList.remove("open");
    if (optionsPrioridad) optionsPrioridad.classList.remove("open");
};

window.seleccionarFiltroTipo = function(valor, label) {
    const labelSpan = document.getElementById("tipoLabel");
    const options = document.getElementById("tipoOptions");
    if (labelSpan) labelSpan.textContent = label;
    if (options) options.classList.remove("open");
    filtroTipoActual = valor;
    aplicarFiltros();
};

document.addEventListener("click", function(e) {
    if (!e.target.closest(".custom-select")) {
        document.getElementById("filtroOptions")?.classList.remove("open");
        document.getElementById("filtroOptionsPrioridad")?.classList.remove("open");
        document.getElementById("tipoOptions")?.classList.remove("open");
    }
});

// ========== DROPDOWN ACCIONES ==========
function cerrarTodosLosMenus() {
    document.querySelectorAll(".dropdown-actions.show").forEach(menu => menu.classList.remove("show"));
}

window.toggleActionMenu = function(event, id) {
    event.stopPropagation();
    const menu = document.getElementById(`menu-${id}`);
    const button = event.currentTarget;
    
    document.querySelectorAll(".dropdown-actions.show").forEach(otherMenu => {
        if (otherMenu.id !== `menu-${id}`) otherMenu.classList.remove("show");
    });
    
    if (menu.classList.contains("show")) {
        menu.classList.remove("show");
        return;
    }
    
    const rect = button.getBoundingClientRect();
    menu.style.position = 'fixed';
    menu.style.top = `${rect.bottom + window.scrollY + 5}px`;
    menu.style.left = `${rect.left + window.scrollX - 150}px`;
    menu.style.zIndex = '10000';
    const menuRect = menu.getBoundingClientRect();
    if (menuRect.right > window.innerWidth) menu.style.left = `${rect.left + window.scrollX - menuRect.width}px`;
    if (menuRect.bottom > window.innerHeight) menu.style.top = `${rect.top + window.scrollY - menuRect.height - 5}px`;
    menu.classList.add("show");
};

document.addEventListener("click", function(event) {
    if (!event.target.closest(".btn-dots") && !event.target.closest(".dropdown-actions")) {
        cerrarTodosLosMenus();
    }
});
window.addEventListener("scroll", () => cerrarTodosLosMenus());
document.addEventListener("keydown", (event) => { if (event.key === "Escape") cerrarTodosLosMenus(); });
window.addEventListener("resize", () => cerrarTodosLosMenus());

// ========== NOTIFICACIONES ==========
let intentosFallidos = 0;
let intervaloNotificaciones = null;
let tiempoBase = 60000;

function iniciarNotificaciones() {
    if (intervaloNotificaciones) clearInterval(intervaloNotificaciones);
    intervaloNotificaciones = setInterval(cargarNotificacionesConBackoff, tiempoBase);
    cargarNotificacionesConBackoff();
}

async function cargarNotificacionesConBackoff() {
    try {
        const res = await apiFetch("/api/notificaciones");
        if (!res) return;
        if (res.status === 429) {
            intentosFallidos++;
            const tiempoEspera = Math.min(300000, tiempoBase * Math.pow(1.5, intentosFallidos));
            if (intervaloNotificaciones) clearInterval(intervaloNotificaciones);
            intervaloNotificaciones = setInterval(cargarNotificacionesConBackoff, tiempoEspera);
            return;
        }
        if (intentosFallidos > 0) {
            intentosFallidos = 0;
            if (intervaloNotificaciones) clearInterval(intervaloNotificaciones);
            intervaloNotificaciones = setInterval(cargarNotificacionesConBackoff, tiempoBase);
        }
        if (!res.ok) return;
        const data = await res.json();
        const notifs = data.notificaciones || [];
        const noLeidas = notifs.filter(n => !n.leida).length;
        actualizarBadge(noLeidas);
        renderNotifPanel(notifs);
    } catch (e) {
        intentosFallidos++;
    }
}

window.limpiarNotificaciones = async function() {
    try {
        const res = await apiFetch("/api/notificaciones/limpiar", { method: "DELETE" });
        if (res?.ok) {
            const notifLista = document.getElementById("notifLista");
            if (notifLista) notifLista.innerHTML = '<div class="notif-empty">Sin notificaciones nuevas</div>';
            actualizarBadge(0);
            showToast("Notificaciones limpiadas ✓", "success");
        }
    } catch (error) {
        showToast("Error de conexión", "error");
    }
};

window.toggleNotifPanel = function() {
    notifPanelAbierto = !notifPanelAbierto;
    const panel = document.getElementById("notifPanel");
    if (panel) panel.classList.toggle("open", notifPanelAbierto);
    if (notifPanelAbierto) {
        actualizarBadge(0);
        apiFetch("/api/notificaciones/marcar-leidas", { method: "PUT" });
    }
};

function cerrarNotifPanel() {
    notifPanelAbierto = false;
    const panel = document.getElementById("notifPanel");
    if (panel) panel.classList.remove("open");
}

function actualizarBadge(cantidad) {
    const badge = document.getElementById("notifBadge");
    const btn = document.getElementById("notifBtn");
    if (cantidad > 0) {
        badge.textContent = cantidad > 99 ? "99+" : cantidad;
        badge.style.display = "flex";
        btn?.classList.add("has-notif");
    } else {
        badge.style.display = "none";
        btn?.classList.remove("has-notif");
    }
}

function renderNotifPanel(notifs) {
    const lista = document.getElementById("notifLista");
    if (!lista) return;
    if (!notifs?.length) {
        lista.innerHTML = `<div class="notif-empty">Sin notificaciones nuevas</div>`;
        return;
    }
    
    const reasignaciones = notifs.filter(n => n.tipo === "reasignacion_solicitada");
    const otras = notifs.filter(n => n.tipo !== "reasignacion_solicitada");
    let html = '';
    
    if (reasignaciones.length > 0 && tipo === "1") {
        html += `<div class="notif-group"><div class="notif-group-title">📢 Solicitudes de Reasignación</div>`;
        reasignaciones.forEach(n => {
            let idSolicitud = n.id_solicitud || 'N/A';
            let tecnico = 'Desconocido';
            let motivo = 'Sin motivo';
            let cliente = 'N/A';
            let prioridad = 'N/A';
            let tipoSoporte = 'N/A';
            
            if (n.mensaje && n.mensaje.startsWith('REASIGNACION|')) {
                const partes = n.mensaje.split('|');
                idSolicitud = partes[1] || idSolicitud;
                tecnico = partes[2] || tecnico;
                motivo = partes[3] || motivo;
                cliente = partes[4] || cliente;
                prioridad = partes[5] || prioridad;
                tipoSoporte = partes[6] || tipoSoporte;
            } else if (n.mensaje) {
                motivo = n.mensaje.substring(0, 100);
            }
            
            html += `
                <div class="notif-item ${n.leida ? "" : "no-leida"}" onclick='abrirModalAprobarReasignacion(${idSolicitud}, "${escapeHtml(tecnico)}", "${escapeHtml(motivo)}", "${escapeHtml(cliente)}", "${escapeHtml(prioridad)}", "${escapeHtml(tipoSoporte)}")'>
                    <div class="notif-dot ${n.leida ? "" : "asignada"}"></div>
                    <div class="notif-item-body">
                        <div class="notif-item-titulo">
                            <strong>📢 Solicitud #${idSolicitud}</strong><br>
                            👤 Técnico: ${escapeHtml(tecnico)}<br>
                            🏢 Cliente: ${escapeHtml(cliente)}<br>
                            📝 Motivo: ${escapeHtml(motivo.substring(0, 80))}${motivo.length > 80 ? '...' : ''}
                        </div>
                        <div class="notif-item-meta">${formatFecha(n.fecha)}</div>
                    </div>
                </div>
            `;
        });
        html += `</div>`;
    }
    
    if (otras.length > 0) {
        if (reasignaciones.length > 0) html += `<div class="notif-group"><div class="notif-group-title">📬 Otras Notificaciones</div>`;
        otras.forEach(n => {
            let mensaje = n.mensaje || '';
            if (mensaje.length > 100) mensaje = mensaje.substring(0, 100) + '...';
            html += `
                <div class="notif-item ${n.leida ? "" : "no-leida"}" onclick="irASolicitud(${n.id_solicitud})">
                    <div class="notif-dot ${n.leida ? "" : "asignada"}"></div>
                    <div class="notif-item-body">
                        <div class="notif-item-titulo">${escapeHtml(mensaje)}</div>
                        <div class="notif-item-meta">${formatFecha(n.fecha)}</div>
                    </div>
                </div>
            `;
        });
        if (reasignaciones.length > 0) html += `</div>`;
    }
    lista.innerHTML = html;
}

function abrirReasignacionDesdeNotificacion(idSolicitud, tecnico, motivo) {
    cerrarNotifPanel();
    const linkSolicitudes = document.querySelector(".sidenav-link");
    if (linkSolicitudes) switchSection("solicitudes", linkSolicitudes);
    cargarSolicitudes().then(() => {
        setTimeout(() => {
            document.querySelectorAll("#tablaSolicitudes tr").forEach(tr => {
                if (tr.textContent.includes(`#${idSolicitud}`)) {
                    tr.style.transition = "background 0.4s";
                    tr.style.background = "rgba(124,106,247,0.15)";
                    tr.scrollIntoView({ behavior: "smooth", block: "center" });
                    showToast(`📢 Solicitud #${idSolicitud}\nTécnico: ${tecnico}\nMotivo: ${motivo.substring(0, 100)}`, "info");
                    setTimeout(() => tr.style.background = "", 5000);
                }
            });
        }, 400);
    });
}

function irASolicitud(id) {
    cerrarNotifPanel();
    const linkSolicitudes = document.querySelector(".sidenav-link");
    if (linkSolicitudes) switchSection("solicitudes", linkSolicitudes);
    cargarSolicitudes().then(() => {
        setTimeout(() => {
            document.querySelectorAll("#tablaSolicitudes tr").forEach(tr => {
                if (tr.textContent.includes(`#${id}`)) {
                    tr.style.transition = "background 0.4s";
                    tr.style.background = "rgba(124,106,247,0.15)";
                    tr.scrollIntoView({ behavior: "smooth", block: "center" });
                    setTimeout(() => tr.style.background = "", 2500);
                }
            });
        }, 400);
    });
}

// ========== LOGOUT ==========
window.logout = function() {
    localStorage.clear();
    window.location.href = "/login";
};

// ========== EVENTOS MODALES ==========
document.getElementById("modalEditar")?.addEventListener("click", function(e) { if (e.target === this) cerrarModal(); });
document.getElementById("modalDetalles")?.addEventListener("click", function(e) { if (e.target === this) cerrarModalDetalles(); });
document.getElementById("modalAsignar")?.addEventListener("click", function(e) { if (e.target === this) cerrarModalAsignar(); });

// ========== INICIALIZACIÓN ==========
cargarSolicitudes();
iniciarNotificaciones();

if (tipo !== "1") {
    document.querySelectorAll("th").forEach(th => {
        if (th.textContent.trim() === "Asignado a") th.style.display = "none";
    });
}

// ========== CERRAR MENÚ DE ACCIONES AL CLIC FUERA ==========
document.addEventListener("click", function(event) {
    if (!event.target.closest(".btn-dots") && !event.target.closest(".dropdown-actions")) {
        document.querySelectorAll(".dropdown-actions.show").forEach(menu => menu.classList.remove("show"));
    }
});

// ========== SOLICITAR REASIGNACIÓN ==========
let solicitudReasignacionIdActual = null;

window.solicitarReasignacion = function(id) {
    solicitudReasignacionIdActual = id;
    document.getElementById("solicitudReasignacionId").value = id;
    document.getElementById("motivoReasignacion").value = "";
    document.getElementById("modalSolicitarReasignacion").classList.add("open");
};

window.cerrarModalSolicitarReasignacion = function() {
    document.getElementById("modalSolicitarReasignacion").classList.remove("open");
    solicitudReasignacionIdActual = null;
    document.getElementById("motivoReasignacion").value = "";
};

window.confirmarSolicitarReasignacion = async function() {
    const motivo = document.getElementById("motivoReasignacion").value.trim();
    const id = solicitudReasignacionIdActual;
    if (!motivo) {
        showToast("Debes proporcionar un motivo para la reasignación", "error");
        return;
    }
    if (motivo.length < 5) {
        showToast("El motivo debe tener al menos 5 caracteres", "error");
        return;
    }
    try {
        const res = await apiFetch(`/api/solicitar-reasignacion/${id}`, {
            method: "POST",
            body: JSON.stringify({ motivo: motivo })
        });
        if (res?.ok) {
            const data = await res.json();
            showToast(data.message || "✅ Solicitud de reasignación enviada", "success");
            cerrarModalSolicitarReasignacion();
        } else {
            const error = await res.json();
            showToast(error.error || "Error al solicitar reasignación", "error");
        }
    } catch (error) {
        showToast("Error de conexión", "error");
    }
};

document.getElementById("modalSolicitarReasignacion")?.addEventListener("click", function(e) {
    if (e.target === this) cerrarModalSolicitarReasignacion();
});

// ========== APROBAR/RECHAZAR REASIGNACIÓN ==========
let solicitudReasignacionActual = null;

async function abrirModalAprobarReasignacion(idSolicitud, tecnico, motivo, cliente, prioridad, tipo) {
    console.log("Abriendo modal de aprobación:", {idSolicitud, tecnico, motivo, cliente, prioridad, tipo});
    
    solicitudReasignacionActual = idSolicitud;
    
    // Cargar lista de técnicos
    try {
        const res = await apiFetch("/api/usuarios");
        if (res && res.ok) {
            const data = await res.json();
            // Filtrar técnicos (tipo 2 o que no sean admin tipo 1)
            const tecnicos = (data.usuarios || []).filter(u => {
                // Mostrar usuarios que son técnicos (tipo 2) o que no son admin
                // También mostrar el técnico actual aunque sea admin
                return u.tipo === 2 || u.tipo === "2" || u.nombre === tecnico;
            });
            
            const select = document.getElementById("selectNuevoTecnico");
            if (select) {
                select.innerHTML = '<option value="">Seleccionar técnico...</option>' +
                    tecnicos.map(t => `<option value="${escapeHtml(t.nombre)}">${escapeHtml(t.nombre)} - ${categoriaLabel[t.categoria] || 'Sin categoría'}</option>`).join('');
                
                // Debug: ver cuántos técnicos se encontraron
                console.log("Técnicos encontrados:", tecnicos.length);
                console.log("Lista de técnicos:", tecnicos);
            }
        }
    } catch (error) {
        console.error("Error cargando técnicos:", error);
        showToast("Error al cargar la lista de técnicos", "error");
    }
    
    // Mostrar información de la solicitud
    const infoDiv = document.getElementById("modalReasignacionInfo");
    if (infoDiv) {
        infoDiv.innerHTML = `
            <div style="margin-bottom: 12px;">
                <strong style="color: var(--accent);">📋 Solicitud #${idSolicitud}</strong>
            </div>
            <div style="display: grid; gap: 8px; font-size: 0.85rem;">
                <div><strong>🏢 Cliente:</strong> ${escapeHtml(cliente || 'N/A')}</div>
                <div><strong>👤 Técnico actual:</strong> ${escapeHtml(tecnico || 'N/A')}</div>
                <div><strong>⚡ Prioridad:</strong> <span class="badge badge-${prioridad || 'media'}">${prioridad || 'Media'}</span></div>
                <div><strong>🖥️ Tipo:</strong> ${escapeHtml(tipo || 'N/A')}</div>
                <div><strong>📝 Motivo:</strong> ${escapeHtml(motivo || 'Sin motivo')}</div>
            </div>
        `;
    }
    
    document.getElementById("modalAprobarReasignacion").classList.add("open");
}

function cerrarModalAprobarReasignacion() {
    document.getElementById("modalAprobarReasignacion").classList.remove("open");
    solicitudReasignacionActual = null;
}

async function confirmarReasignacionAdmin() {
    const select = document.getElementById("selectNuevoTecnico");
    const nuevoTecnico = select ? select.value : null;
    
    if (!nuevoTecnico) {
        showToast("Selecciona un técnico para reasignar", "error");
        return;
    }
    
    if (nuevoTecnico === document.getElementById("modalReasignacionInfo").innerHTML.match(/Técnico actual: ([^<]+)/)?.[1]?.trim()) {
        showToast("El técnico seleccionado es el mismo que el actual", "error");
        return;
    }
    
    try {
        const res = await apiFetch(`/api/reasignar/${solicitudReasignacionActual}`, {
            method: "PUT",
            body: JSON.stringify({ asignado_a: nuevoTecnico })
        });
        
        if (res?.ok) {
            showToast(`✅ Solicitud reasignada a ${nuevoTecnico}`, "success");
            cerrarModalAprobarReasignacion();
            await cargarSolicitudes();
            // Marcar notificaciones como leídas
            await apiFetch("/api/notificaciones/marcar-leidas", { method: "PUT" });
        } else {
            const error = await res.json();
            showToast(error.error || "Error al reasignar", "error");
        }
    } catch (error) {
        console.error("Error:", error);
        showToast("Error de conexión", "error");
    }
}

async function rechazarReasignacion() {
    if (!confirm("¿Estás seguro de que deseas rechazar esta solicitud de reasignación?")) return;
    
    try {
        const res = await apiFetch(`/api/rechazar-reasignacion/${solicitudReasignacionActual}`, {
            method: "POST",
            body: JSON.stringify({ motivo: "El administrador rechazó la solicitud" })
        });
        
        if (res?.ok) {
            showToast("❌ Solicitud de reasignación rechazada", "success");
            cerrarModalAprobarReasignacion();
            await cargarSolicitudes();
            // Marcar notificaciones como leídas
            await apiFetch("/api/notificaciones/marcar-leidas", { method: "PUT" });
        } else {
            const error = await res.json();
            showToast(error.error || "Error al rechazar", "error");
        }
    } catch (error) {
        console.error("Error:", error);
        showToast("Error de conexión", "error");
    }
}

// Cerrar modal al hacer clic fuera
document.getElementById("modalAprobarReasignacion")?.addEventListener("click", function(e) {
    if (e.target === this) {
        cerrarModalAprobarReasignacion();
    }
});