import { apiFetch } from './api.js';

export async function cargarComentarios(idSolicitud) {
    const res = await apiFetch(`/solicitudes/${idSolicitud}/comentarios`);
    if (!res) return [];
    const data = await res.json();
    return data.comentarios || [];
}

export async function enviarComentario(idSolicitud, mensaje) {
    const res = await apiFetch(`/solicitudes/${idSolicitud}/comentarios`, {
        method: 'POST',
        body: JSON.stringify({ mensaje })
    });
    return res?.ok || false;
}