export function showToast(msg, type = 'success') {
    const toast = document.getElementById('toast');
    if (!toast) return;
    
    toast.textContent = msg;
    toast.className = `toast ${type} show`;
    setTimeout(() => toast.classList.remove('show'), 3000);
}

export function formatFecha(fecha) {
    if (!fecha) return '—';
    return new Date(fecha).toLocaleDateString('es-CO', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
    });
}

export function formatFechaHora(fecha) {
    if (!fecha) return '—';
    return new Date(fecha).toLocaleString('es-CO', {
        day: '2-digit',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit'
    });
}

export function escapeHtml(text) {
    if (!text) return text;
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

export function getEstadoClass(estado) {
    switch(estado) {
        case 'pendiente': return 'pendiente';
        case 'en proceso': return 'proceso';
        case 'resuelto': return 'resuelto';
        default: return 'pendiente';
    }
}

export function getEstadoTexto(estado) {
    switch(estado) {
        case 'pendiente': return '⏳ Pendiente';
        case 'en proceso': return '🔄 En Proceso';
        case 'resuelto': return '✅ Resuelto';
        default: return estado;
    }
}