import { apiFetch } from './api.js';

export async function cargarUsuarios() {
    const res = await apiFetch('/usuarios');
    if (!res) return [];
    const data = await res.json();
    return data.usuarios || [];
}

export async function crearUsuario(data) {
    const res = await apiFetch('/usuarios', {
        method: 'POST',
        body: JSON.stringify(data)
    });
    if (!res) return false;
    const result = await res.json();
    return result.message ? true : false;
}

export async function actualizarUsuario(id, data) {
    const res = await apiFetch(`/usuarios/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
    });
    return res?.ok || false;
}

export async function eliminarUsuario(id) {
    const res = await apiFetch(`/usuarios/${id}`, {
        method: 'DELETE'
    });
    return res?.ok || false;
}