import { setRecaptchaKey, getRecaptchaToken, login } from './modules/auth.js';
import { showToast } from './modules/utils.js';

// Configurar la clave de reCAPTCHA desde el HTML (pasa como variable global o data attribute)
const recaptchaSiteKey = document.body.dataset.recaptchaKey || '{{ recaptcha_site_key }}';
setRecaptchaKey(recaptchaSiteKey);

function showError(message, isRateLimit = false) {
    const errorEl = document.getElementById("error");
    const rateLimitEl = document.getElementById("rate-limit-warning");
    
    if (isRateLimit) {
        rateLimitEl.textContent = message;
        rateLimitEl.style.display = "block";
        errorEl.style.display = "none";
        setTimeout(() => { rateLimitEl.style.display = "none"; }, 5000);
    } else {
        errorEl.textContent = message;
        errorEl.style.display = "block";
        rateLimitEl.style.display = "none";
    }
}

document.getElementById("loginForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    
    const usuario = document.getElementById("usuario").value.trim();
    const password = document.getElementById("password").value;
    const btnLogin = document.getElementById("btnLogin");
    const originalText = btnLogin.textContent;

    if (!usuario || !password) {
        showError("Ingresa usuario y contraseña");
        return;
    }

    btnLogin.textContent = "Verificando...";
    btnLogin.disabled = true;

    try {
        // Obtener token de reCAPTCHA si está disponible
        const recaptchaToken = await getRecaptchaToken();
        
        const result = await login(usuario, password, recaptchaToken);
        
        if (result.success) {
            window.location.href = "/";
        } else {
            showError(result.error, result.isRateLimit || false);
            btnLogin.textContent = originalText;
            btnLogin.disabled = false;
            document.getElementById("password").value = "";
        }
        
    } catch (error) {
        console.error("Error:", error);
        showError("Error de conexión. Intenta de nuevo.");
        btnLogin.textContent = originalText;
        btnLogin.disabled = false;
    }
});

// Limpiar mensajes de error al escribir
document.getElementById("usuario").addEventListener("input", () => {
    document.getElementById("error").style.display = "none";
    document.getElementById("rate-limit-warning").style.display = "none";
});

document.getElementById("password").addEventListener("input", () => {
    document.getElementById("error").style.display = "none";
    document.getElementById("rate-limit-warning").style.display = "none";
});