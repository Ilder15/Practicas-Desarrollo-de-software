import { apiFetch } from './api.js';

let notificacionesCache = [];

export async function cargarNotificaciones() {
    const res = await apiFetch('/notificaciones');
    if (!res) return [];
    const data = await res.json();
    notificacionesCache = data.notificaciones || [];
    return notificacionesCache;
}

export async function marcarComoLeidas() {
    await apiFetch('/notificaciones/marcar-leidas', { method: 'PUT' });
}

export async function limpiarNotificaciones() {
    await apiFetch('/notificaciones/limpiar', { method: 'DELETE' });
    notificacionesCache = [];
}

export function getNoLeidas() {
    return notificacionesCache.filter(n => !n.leida).length;
}

export function getNotificaciones() {
    return notificacionesCache;
}