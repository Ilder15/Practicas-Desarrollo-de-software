import { apiFetch } from './api.js';

export async function cargarSolicitudes() {
    const res = await apiFetch('/solicitudes');
    if (!res) return [];
    const data = await res.json();
    return data.registros || [];
}

export async function crearSolicitud(data) {
    const res = await apiFetch('/solicitudes', {
        method: 'POST',
        body: JSON.stringify(data)
    });
    if (!res) return false;
    const result = await res.json();
    return result;
}

export async function eliminarSolicitud(id) {
    const res = await apiFetch(`/solicitudes/${id}`, {
        method: 'DELETE'
    });
    return res?.ok || false;
}

export async function actualizarSolicitud(id, data) {
    const res = await apiFetch(`/solicitudes/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
    });
    return res?.ok || false;
}

export async function actualizarEstado(id, estado) {
    const res = await apiFetch(`/editar_solicitud/${id}`, {
        method: 'PUT',
        body: JSON.stringify({ estado })
    });
    return res?.ok || false;
}

export async function resolverSolicitud(id, asignado_a) {
    const res = await apiFetch(`/resolver/${id}`, {
        method: 'PUT',
        body: JSON.stringify({ asignado_a })
    });
    return res?.ok || false;
}

export async function asignarSolicitud(id, asignado_a) {
    const res = await apiFetch(`/asignar/${id}`, {
        method: 'PUT',
        body: JSON.stringify({ asignado_a })
    });
    return res?.ok || false;
}

export async function reasignarSolicitud(id, asignado_a) {
    const res = await apiFetch(`/reasignar/${id}`, {
        method: 'PUT',
        body: JSON.stringify({ asignado_a })
    });
    return res?.ok || false;
}