// static/js/nueva_solicitud.js
const RECAPTCHA_SITE_KEY = document.body.dataset.recaptchaKey || '';

function showToast(msg, type) {
    type = type || "success";
    var t = document.getElementById("toast");
    t.textContent = msg;
    t.className = "toast " + type + " show";
    setTimeout(function() { t.classList.remove("show"); }, 3000);
}

async function subirArchivosPublicos(idSolicitud, archivos, nombreUsuario) {
    if (!archivos || archivos.length === 0) {
        console.log("No hay archivos para subir");
        return true;
    }
    
    console.log("📤 Subiendo", archivos.length, "archivos para solicitud:", idSolicitud);
    var todosExitosos = true;
    
    for (var i = 0; i < archivos.length; i++) {
        var formData = new FormData();
        formData.append("archivo", archivos[i]);
        formData.append("usuario", nombreUsuario || "Público");
        
        console.log("📄 Subiendo:", archivos[i].name, archivos[i].size + " bytes");
        
        try {
            var response = await fetch("/api/public/archivos/" + idSolicitud, {
                method: "POST",
                body: formData
            });
            
            var data = await response.json();
            console.log("Respuesta:", response.status, data);
            
            if (response.ok) {
                console.log("✅ Archivo subido:", archivos[i].name);
            } else {
                todosExitosos = false;
                showToast("Error al subir " + archivos[i].name + ": " + (data.error || "Error desconocido"), "error");
            }
        } catch (error) {
            todosExitosos = false;
            console.error("❌ Error:", error);
            showToast("Error de conexión al subir " + archivos[i].name, "error");
        }
    }
    
    return todosExitosos;
}

window.enviar = async function() {
    var cliente = document.getElementById("f-cliente").value.trim();
    var persona = document.getElementById("f-persona").value.trim();
    var tipo = document.getElementById("f-tipo").value;
    var prioridad = document.getElementById("f-prioridad").value;
    var descripcion = document.getElementById("f-descripcion").value.trim();
    var archivosInput = document.getElementById("f-archivos");
    var archivos = archivosInput ? archivosInput.files : [];

    console.log("=== ENVIANDO SOLICITUD ===");
    console.log("Cliente:", cliente);
    console.log("Archivos:", archivos.length);

    if (!cliente || !tipo || !prioridad) {
        showToast("Completa todos los campos obligatorios", "error");
        return;
    }

    // Validar tamaño de archivos (16MB máximo)
    for (var i = 0; i < archivos.length; i++) {
        if (archivos[i].size > 16 * 1024 * 1024) {
            showToast("El archivo " + archivos[i].name + " supera el límite de 16MB", "error");
            return;
        }
    }

    var body = {
        cliente: cliente,
        persona_reporta: persona,
        tipo_soporte: tipo,
        prioridad: prioridad,
        descripcion: descripcion
    };

    // Verificar reCAPTCHA
    if (RECAPTCHA_SITE_KEY && RECAPTCHA_SITE_KEY !== 'None' && RECAPTCHA_SITE_KEY !== '') {
        var recaptchaResponse = grecaptcha.getResponse();
        if (!recaptchaResponse) {
            showToast("Por favor, completa el captcha", "error");
            return;
        }
        body.recaptcha_token = recaptchaResponse;
    }

    var btn = document.querySelector('.btn-primary');
    var originalText = btn.textContent;
    btn.textContent = "Enviando...";
    btn.disabled = true;

    try {
        console.log("📝 Creando solicitud...");
        var res = await fetch("/api/solicitud-publica", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
        });
        
        var data = await res.json();
        console.log("Respuesta:", data);
        
        if (res.ok && data.message) {
            var idSolicitud = data.id;
            console.log("✅ Solicitud creada con ID:", idSolicitud);
            showToast("Solicitud creada (ID: " + idSolicitud + ")", "success");
            
            // Subir archivos si hay
            if (archivos && archivos.length > 0) {
                console.log("📤 Subiendo archivos...");
                showToast("Subiendo " + archivos.length + " archivo(s)...", "success");
                await subirArchivosPublicos(idSolicitud, archivos, persona || "Público");
            }
            
            showToast("¡Solicitud enviada exitosamente! ✓", "success");
            
            // Limpiar formulario
            document.getElementById("f-cliente").value = "";
            document.getElementById("f-persona").value = "";
            document.getElementById("f-tipo").value = "";
            document.getElementById("f-prioridad").value = "";
            document.getElementById("f-descripcion").value = "";
            if (archivosInput) archivosInput.value = "";
            if (RECAPTCHA_SITE_KEY && RECAPTCHA_SITE_KEY !== 'None' && RECAPTCHA_SITE_KEY !== '') {
                grecaptcha.reset();
            }
            
            // Redirigir al seguimiento
            setTimeout(function() {
                window.location.href = "/seguimiento?id=" + idSolicitud;
            }, 2000);
            
        } else {
            console.error("Error:", data);
            showToast(data.error || "Error al enviar", "error");
            btn.textContent = originalText;
            btn.disabled = false;
            if (RECAPTCHA_SITE_KEY && RECAPTCHA_SITE_KEY !== 'None' && RECAPTCHA_SITE_KEY !== '') {
                grecaptcha.reset();
            }
        }
    } catch (e) {
        console.error("Error:", e);
        showToast("Error de conexión", "error");
        btn.textContent = originalText;
        btn.disabled = false;
    }
};

console.log("✅ nueva_solicitud.js cargado");