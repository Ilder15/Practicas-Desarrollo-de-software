# app.py
import os
from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

from config.settings import config
from config.database import close_db
from utils.decorators import register_error_handlers

# Cargar configuración
env = os.environ.get("FLASK_ENV", "development")
cfg = config[env]

app = Flask(__name__)
app.config.from_object(cfg)

# Extensiones
CORS(app, origins=cfg.ALLOWED_ORIGINS, supports_credentials=True)
jwt = JWTManager(app)

# Rate Limiting (opcional - comentar si no se quiere usar)
# try:
#     limiter = Limiter(
#         get_remote_address,
#         app=app,
#         default_limits=["200 per day", "50 per hour"],
#         storage_uri="memory://"
#     )
# except Exception as e:
#     print(f"⚠️ Rate limiting no disponible: {e}")
#     limiter = None

# Cerrar conexión DB
app.teardown_appcontext(close_db)

# Error handlers
register_error_handlers(app)

# Registrar rutas
from routes import (
    auth_routes,
    solicitud_routes,
    usuario_routes,
    comentario_routes,
    notificacion_routes,
    auditoria_routes,
    public_routes,
    archivo_routes
)

auth_routes.init_auth_routes(app)
solicitud_routes.init_solicitud_routes(app)
usuario_routes.init_usuario_routes(app)
comentario_routes.init_comentario_routes(app)
notificacion_routes.init_notificacion_routes(app)
auditoria_routes.init_auditoria_routes(app)
public_routes.init_public_routes(app)
archivo_routes.init_archivo_routes(app)

if __name__ == '__main__':
    app.run(debug=cfg.DEBUG)