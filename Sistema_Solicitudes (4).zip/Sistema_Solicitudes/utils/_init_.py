from utils.helpers import serializar_registro, format_fecha, escape_html
from utils.decorators import register_error_handlers, admin_required