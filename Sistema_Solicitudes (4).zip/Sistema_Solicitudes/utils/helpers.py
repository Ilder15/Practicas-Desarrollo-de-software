from datetime import date, datetime

def serializar_registro(row):
    if not row:
        return row
    
    result = {}
    for k, v in row.items():
        if isinstance(v, (date, datetime)):
            result[k] = v.isoformat()
        else:
            result[k] = v
    return result

def serializar_lista(rows):
    return [serializar_registro(r) for r in rows]

def format_fecha(fecha):
    if not fecha:
        return "—"
    return fecha.strftime("%d/%m/%Y %H:%M")

def escape_html(text):
    if not text:
        return text
    import html
    return html.escape(str(text))