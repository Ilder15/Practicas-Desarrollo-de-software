# utils/decorators.py
from functools import wraps
from flask import jsonify
from flask_jwt_extended import get_jwt
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        claims = get_jwt()
        if int(claims.get("tipo", 0)) != 1:
            return jsonify({"error": "No autorizado"}), 403
        return fn(*args, **kwargs)
    return wrapper

def rate_limit_login(fn):
    """Decorador para limitar intentos de login"""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        # Este decorador es solo una referencia - la limitación real
        # se maneja con @limiter.limit en la ruta
        return fn(*args, **kwargs)
    return wrapper

def register_error_handlers(app):
    
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({"error": "Recurso no encontrado"}), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        return jsonify({"error": "Error interno del servidor"}), 500
    
    @app.errorhandler(429)
    def rate_limit_exceeded(error):
        return jsonify({"error": "Demasiadas solicitudes. Espera un momento."}), 429