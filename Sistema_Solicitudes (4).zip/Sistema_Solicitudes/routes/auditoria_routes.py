# routes/auditoria_routes.py
from flask import jsonify
from flask_jwt_extended import jwt_required
from services.auditoria_service import AuditoriaService
from utils.decorators import admin_required
from utils.helpers import serializar_lista

# Rutas para manejar auditoria de acciones del sistema
def init_auditoria_routes(app):

    # Ruta para obtener todos los registros de auditoria (solo administradores)
    @app.route("/api/auditoria", methods=["GET"])
    @jwt_required()
    @admin_required
    def obtener_auditoria():
        registros = AuditoriaService.obtener_todas()
        return jsonify({"registros": serializar_lista(registros)}), 200