# routes/solicitud_routes.py
from flask import request, jsonify, Response
from flask_jwt_extended import jwt_required, get_jwt
from services.solicitud_service import SolicitudService
from services.historial_service import HistorialService
from services.notificacion_service import NotificacionService
from services.auditoria_service import AuditoriaService
from utils.helpers import serializar_lista
from utils.decorators import admin_required
import csv
import io
from datetime import datetime
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

def init_solicitud_routes(app):
    # ========== RUTAS BÁSICAS DE SOLICITUDES ==========
    
    @app.route("/api/solicitudes", methods=["GET"])
    @jwt_required()
    def obtener_solicitudes():
        claims = get_jwt()
        es_admin = int(claims.get("tipo", 0)) == 1
        nombre = claims.get("nombre")
        
        solicitudes = SolicitudService.obtener_todas(nombre, es_admin)
        return jsonify({"registros": serializar_lista(solicitudes)}), 200

    @app.route("/api/solicitudes", methods=["POST"])
    @jwt_required()
    def agregar_solicitud():
        claims = get_jwt()
        data = request.get_json(force=True)
        
        nueva_id, asignado = SolicitudService.crear(data, claims.get("nombre"))
        
        return jsonify({
            "message": "Solicitud creada exitosamente",
            "id": nueva_id,
            "asignado_a": asignado
        }), 201

    @app.route("/api/solicitudes/<int:id_solicitud>", methods=["PUT"])
    @jwt_required()
    def editar_solicitud(id_solicitud):
        claims = get_jwt()
        data = request.get_json(force=True)
        
        success = SolicitudService.actualizar(id_solicitud, data, claims.get("nombre"))
        
        if success:
            return jsonify({"message": "Solicitud actualizada correctamente"}), 200
        
        solicitud = SolicitudService.obtener_por_id(id_solicitud)
        if not solicitud:
            return jsonify({"error": "Solicitud no encontrada"}), 404
        if solicitud['estado'] == 'resuelto':
            return jsonify({"error": "No se puede editar una solicitud resuelta"}), 400
        
        return jsonify({"error": "No autorizado"}), 403

    @app.route("/api/solicitudes/<int:id_solicitud>", methods=["DELETE"])
    @jwt_required()
    @admin_required
    def eliminar_solicitud(id_solicitud):
        claims = get_jwt()
        
        if SolicitudService.eliminar(id_solicitud, claims.get("nombre")):
            return jsonify({"message": "Solicitud eliminada exitosamente"}), 200
        
        return jsonify({"error": "Solicitud no encontrada"}), 404

    @app.route("/api/editar_solicitud/<int:id_solicitud>", methods=["PUT"])
    @jwt_required()
    def editar_estado(id_solicitud):
        """Cambia el estado de una solicitud (pendiente, en proceso, resuelto)"""
        claims = get_jwt()
        data = request.get_json(force=True)
        estado = data.get("estado")
        
        if not estado:
            return jsonify({"error": "El campo 'estado' es obligatorio"}), 400
        
        if SolicitudService.actualizar_estado(id_solicitud, estado, claims.get("nombre")):
            return jsonify({"message": "Estado actualizado exitosamente"}), 200
        
        return jsonify({"error": "Solicitud no encontrada"}), 404

    @app.route("/api/resolver/<int:id_solicitud>", methods=["PUT"])
    @jwt_required()
    def resolver_solicitud(id_solicitud):
        """Marca una solicitud como resuelta"""
        claims = get_jwt()
        data = request.get_json(force=True)
        asignado_a = data.get("asignado_a")
        
        if not asignado_a:
            return jsonify({"error": "El campo 'asignado_a' es obligatorio"}), 400
        
        if SolicitudService.resolver(id_solicitud, asignado_a, claims.get("nombre")):
            return jsonify({"message": "Solicitud resuelta exitosamente"}), 200
        
        return jsonify({"error": "Solicitud no encontrada"}), 404

    @app.route("/api/asignar/<int:id>", methods=["PUT"])
    @jwt_required()
    def asignar_solicitud(id):
        """Asigna una solicitud a un usuario"""
        claims = get_jwt()
        data = request.get_json()
        asignado_a = data.get("asignado_a")
        
        if not asignado_a:
            return jsonify({"error": "Falta el campo asignado_a"}), 400
        
        es_admin = int(claims.get("tipo", 0)) == 1
        success, message = SolicitudService.asignar(id, asignado_a, claims.get("nombre"), es_admin)
        
        if success:
            return jsonify({"message": message}), 200
        return jsonify({"error": message}), 400 if "no encontrada" in message else 409

    @app.route("/api/reasignar/<int:id>", methods=["PUT"])
    @jwt_required()
    @admin_required
    def reasignar_solicitud(id):
        """Reasigna una solicitud de un usuario a otro (solo admin)"""
        claims = get_jwt()
        data = request.get_json()
        nuevo_asignado = data.get("asignado_a")
        
        if not nuevo_asignado:
            return jsonify({"error": "Falta el campo asignado_a"}), 400
        
        success, message = SolicitudService.reasignar(id, nuevo_asignado, claims.get("nombre"))
        
        if success:
            return jsonify({"message": message}), 200
        return jsonify({"error": message}), 404

    @app.route("/api/solicitudes/<int:id_solicitud>/historial", methods=["GET"])
    @jwt_required()
    def obtener_historial(id_solicitud):
        """Obtiene el historial de cambios de una solicitud"""
        try:
            historial = HistorialService.obtener_historial(id_solicitud)
            return jsonify({"historial": historial}), 200
        except Exception as e:
            print(f"Error obteniendo historial: {e}")
            return jsonify({"error": str(e)}), 500

    @app.route("/api/solicitudes/<int:id_solicitud>/sla", methods=["GET"])
    @jwt_required()
    def obtener_sla(id_solicitud):
        """Obtiene el estado del SLA de una solicitud"""
        sla_status = SolicitudService.obtener_sla_status(id_solicitud)
        if sla_status is None:
            return jsonify({"error": "SLA no configurado"}), 404
        
        return jsonify({"sla": sla_status}), 200

    # ========== RUTAS DE EXPORTACIÓN ==========
    
    @app.route("/api/solicitudes/exportar/csv", methods=["GET"])
    @jwt_required()
    def exportar_csv():
        """Exporta las solicitudes a CSV"""
        claims = get_jwt()
        es_admin = int(claims.get("tipo", 0)) == 1
        nombre = claims.get("nombre")
        
        solicitudes = SolicitudService.obtener_todas(nombre, es_admin)
        
        output = io.StringIO()
        writer = csv.writer(output, delimiter=';')
        
        writer.writerow([
            'ID', 'Cliente', 'Reportado por', 'Tipo de Soporte', 
            'Prioridad', 'Estado', 'Descripción', 'Fecha de Reporte', 
            'Fecha de Resolución', 'Asignado a', 'SLA Vencimiento', 'Estado SLA'
        ])
        
        for s in solicitudes:
            sla_estado = calcular_estado_sla(s)
            writer.writerow([
                s.get('id', ''), s.get('cliente', ''), s.get('persona_reporta', ''),
                s.get('tipo_soporte', ''), s.get('prioridad', ''), s.get('estado', ''),
                s.get('descripcion', ''), s.get('fecha_reporte', ''), s.get('fecha_resuelto', ''),
                s.get('asignado_a', ''), s.get('sla_vencimiento', ''), sla_estado
            ])
        
        output.seek(0)
        fecha_actual = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        return Response(
            output.getvalue().encode('utf-8-sig'),
            mimetype='text/csv; charset=utf-8-sig',
            headers={'Content-Disposition': f'attachment; filename=solicitudes_{fecha_actual}.csv'}
        )

    @app.route("/api/solicitudes/exportar/excel", methods=["GET"])
    @jwt_required()
    def exportar_excel():
        """Exporta las solicitudes a Excel"""
        claims = get_jwt()
        es_admin = int(claims.get("tipo", 0)) == 1
        nombre = claims.get("nombre")
        
        solicitudes = SolicitudService.obtener_todas(nombre, es_admin)
        
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Solicitudes"
        
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="7C6AF7", end_color="7C6AF7", fill_type="solid")
        header_alignment = Alignment(horizontal="center", vertical="center")
        border = Border(
            left=Side(style='thin'), right=Side(style='thin'),
            top=Side(style='thin'), bottom=Side(style='thin')
        )
        
        headers = ['ID', 'Cliente', 'Reportado por', 'Tipo de Soporte', 'Prioridad', 
                   'Estado', 'Descripción', 'Fecha de Reporte', 'Fecha de Resolución', 
                   'Asignado a', 'SLA Vencimiento', 'Estado SLA']
        
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
            cell.border = border
        
        for row, s in enumerate(solicitudes, 2):
            sla_estado = calcular_estado_sla(s)
            
            ws.cell(row=row, column=1, value=s.get('id', ''))
            ws.cell(row=row, column=2, value=s.get('cliente', ''))
            ws.cell(row=row, column=3, value=s.get('persona_reporta', ''))
            ws.cell(row=row, column=4, value=s.get('tipo_soporte', ''))
            ws.cell(row=row, column=5, value=s.get('prioridad', ''))
            ws.cell(row=row, column=6, value=s.get('estado', ''))
            ws.cell(row=row, column=7, value=s.get('descripcion', ''))
            
            fecha_reporte = s.get('fecha_reporte')
            if fecha_reporte:
                if isinstance(fecha_reporte, datetime):
                    ws.cell(row=row, column=8, value=fecha_reporte.strftime('%Y-%m-%d %H:%M:%S'))
                else:
                    ws.cell(row=row, column=8, value=str(fecha_reporte))
            
            fecha_resuelto = s.get('fecha_resuelto')
            if fecha_resuelto:
                if isinstance(fecha_resuelto, datetime):
                    ws.cell(row=row, column=9, value=fecha_resuelto.strftime('%Y-%m-%d %H:%M:%S'))
                else:
                    ws.cell(row=row, column=9, value=str(fecha_resuelto))
            
            ws.cell(row=row, column=10, value=s.get('asignado_a', ''))
            
            sla_vencimiento = s.get('sla_vencimiento')
            if sla_vencimiento:
                if isinstance(sla_vencimiento, datetime):
                    ws.cell(row=row, column=11, value=sla_vencimiento.strftime('%Y-%m-%d %H:%M:%S'))
                else:
                    ws.cell(row=row, column=11, value=str(sla_vencimiento))
            
            ws.cell(row=row, column=12, value=sla_estado)
            
            for col in range(1, 13):
                ws.cell(row=row, column=col).border = border
        
        for col in range(1, 13):
            ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = 20
        
        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        
        fecha_actual = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        return Response(
            output.getvalue(),
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            headers={'Content-Disposition': f'attachment; filename=solicitudes_{fecha_actual}.xlsx'}
        )

    @app.route("/api/solicitudes/exportar/filtrado", methods=["POST"])
    @jwt_required()
    def exportar_filtrado():
        """Exporta solicitudes filtradas a CSV o Excel"""
        claims = get_jwt()
        es_admin = int(claims.get("tipo", 0)) == 1
        nombre = claims.get("nombre")
        data = request.get_json(force=True)
        
        formato = data.get('formato', 'csv')
        filtros = data.get('filtros', {})
        
        todas = SolicitudService.obtener_todas(nombre, es_admin)
        filtradas = aplicar_filtros_exportacion(todas, filtros)
        
        if formato == 'excel':
            return exportar_a_excel(filtradas)
        else:
            return exportar_a_csv(filtradas)

    # ========== RUTAS PARA SOLICITAR Y RECHAZAR REASIGNACIÓN ==========
    
    @app.route("/api/solicitar-reasignacion/<int:id>", methods=["POST"])
    @jwt_required()
    def solicitar_reasignacion(id):
        """Un técnico solicita reasignar una solicitud a otro técnico"""
        try:
            claims = get_jwt()
            usuario_actual = claims.get("nombre")
            tipo_usuario = int(claims.get("tipo", 0))
            
            print(f"[DEBUG] === SOLICITUD REASIGNACIÓN ===")
            print(f"[DEBUG] ID: {id}, Usuario: {usuario_actual}, Tipo: {tipo_usuario}")
            
            if tipo_usuario == 1:
                return jsonify({"error": "Los administradores pueden reasignar directamente"}), 400
            
            data = request.get_json(force=True)
            print(f"[DEBUG] Data recibida: {data}")
            
            motivo = data.get("motivo", "")
            print(f"[DEBUG] Motivo: '{motivo}'")
            
            if not motivo:
                return jsonify({"error": "Debes proporcionar un motivo para la reasignación"}), 400
            
            success, message = SolicitudService.solicitar_reasignacion(id, usuario_actual, motivo)
            print(f"[DEBUG] Success: {success}, Message: {message}")
            
            if success:
                return jsonify({"message": message}), 200
            return jsonify({"error": message}), 400
            
        except Exception as e:
            print(f"[ERROR] Excepción en solicitar_reasignacion: {e}")
            import traceback
            traceback.print_exc()
            return jsonify({"error": f"Error interno: {str(e)}"}), 500

    @app.route("/api/rechazar-reasignacion/<int:id>", methods=["POST"])
    @jwt_required()
    @admin_required
    def rechazar_reasignacion(id):
        """Admin rechaza una solicitud de reasignación"""
        try:
            claims = get_jwt()
            admin = claims.get("nombre")
            data = request.get_json(force=True)
            motivo_rechazo = data.get("motivo", "Sin motivo especificado")
            
            solicitud = SolicitudService.obtener_por_id(id)
            if not solicitud:
                return jsonify({"error": "Solicitud no encontrada"}), 404
            
            tecnico_actual = solicitud.get('asignado_a')
            
            if tecnico_actual:
                NotificacionService.crear(
                    tecnico_actual,
                    id,
                    f"❌ Tu solicitud de reasignación fue rechazada por {admin}. Motivo: {motivo_rechazo}",
                    "reasignacion_rechazada"
                )
            
            AuditoriaService.registrar(
                admin,
                "rechazar_reasignacion",
                id,
                f"Rechazó solicitud de reasignación. Motivo: {motivo_rechazo[:100]}"
            )
            
            return jsonify({"message": "Solicitud de reasignación rechazada"}), 200
            
        except Exception as e:
            print(f"[ERROR] Error en rechazar_reasignacion: {e}")
            return jsonify({"error": str(e)}), 500


# ========== FUNCIONES AUXILIARES ==========

def calcular_estado_sla(solicitud):
    """Calcula el estado del SLA para una solicitud"""
    if solicitud.get('estado') == 'resuelto':
        if solicitud.get('sla_vencimiento') and solicitud.get('fecha_resuelto'):
            vencimiento = solicitud['sla_vencimiento']
            fecha_resuelto = solicitud['fecha_resuelto']
            if isinstance(vencimiento, str):
                try:
                    vencimiento = datetime.fromisoformat(vencimiento)
                except:
                    pass
            if isinstance(fecha_resuelto, str):
                try:
                    fecha_resuelto = datetime.fromisoformat(fecha_resuelto)
                except:
                    pass
            if hasattr(fecha_resuelto, '__gt__') and hasattr(vencimiento, '__gt__'):
                if fecha_resuelto > vencimiento:
                    diff = fecha_resuelto - vencimiento
                    horas = int(diff.total_seconds() // 3600)
                    minutos = int((diff.total_seconds() % 3600) // 60)
                    if horas > 0:
                        return f"Cumplido con retraso de {horas}h {minutos}m"
                    else:
                        return f"Cumplido con retraso de {minutos}m"
                else:
                    return "Cumplido a tiempo"
        return "Cumplido"
    elif solicitud.get('sla_vencimiento'):
        vencimiento = solicitud['sla_vencimiento']
        if isinstance(vencimiento, str):
            try:
                vencimiento = datetime.fromisoformat(vencimiento)
            except:
                return "Sin SLA"
        ahora = datetime.now()
        if ahora > vencimiento:
            diff = ahora - vencimiento
            horas = int(diff.total_seconds() // 3600)
            minutos = int((diff.total_seconds() % 3600) // 60)
            if horas > 0:
                return f"VENCIDO (retraso {horas}h {minutos}m)"
            else:
                return f"VENCIDO (retraso {minutos}m)"
        else:
            diff = vencimiento - ahora
            horas = int(diff.total_seconds() // 3600)
            minutos = int((diff.total_seconds() % 3600) // 60)
            if horas > 0:
                return f"A tiempo ({horas}h {minutos}m restantes)"
            else:
                return f"A tiempo ({minutos}m restantes)"
    return "Sin SLA"


def aplicar_filtros_exportacion(solicitudes, filtros):
    """Aplica filtros a las solicitudes para exportación"""
    resultado = list(solicitudes)
    
    if filtros.get('estado') and filtros['estado'] != 'todos':
        resultado = [s for s in resultado if s.get('estado') == filtros['estado']]
    
    if filtros.get('prioridad') and filtros['prioridad'] != 'todos':
        resultado = [s for s in resultado if s.get('prioridad') == filtros['prioridad']]
    
    if filtros.get('tipo_soporte') and filtros['tipo_soporte'] != 'todos':
        resultado = [s for s in resultado if s.get('tipo_soporte') == filtros['tipo_soporte']]
    
    if filtros.get('desde'):
        try:
            desde = datetime.fromisoformat(filtros['desde'])
            resultado = [s for s in resultado if s.get('fecha_reporte')]
            resultado = [s for s in resultado if isinstance(s.get('fecha_reporte'), datetime) and s['fecha_reporte'] >= desde]
        except:
            pass
    
    if filtros.get('hasta'):
        try:
            hasta = datetime.fromisoformat(filtros['hasta'])
            resultado = [s for s in resultado if s.get('fecha_reporte')]
            resultado = [s for s in resultado if isinstance(s.get('fecha_reporte'), datetime) and s['fecha_reporte'] <= hasta]
        except:
            pass
    
    if filtros.get('busqueda'):
        busqueda = filtros['busqueda'].lower()
        resultado = [s for s in resultado if 
                     busqueda in s.get('cliente', '').lower() or 
                     busqueda in s.get('persona_reporta', '').lower()]
    
    return resultado


def exportar_a_csv(solicitudes):
    """Exporta una lista de solicitudes a CSV"""
    output = io.StringIO()
    writer = csv.writer(output, delimiter=';')
    
    writer.writerow([
        'ID', 'Cliente', 'Reportado por', 'Tipo de Soporte', 
        'Prioridad', 'Estado', 'Descripción', 'Fecha de Reporte', 
        'Fecha de Resolución', 'Asignado a', 'SLA Vencimiento', 'Estado SLA'
    ])
    
    for s in solicitudes:
        sla_estado = calcular_estado_sla(s)
        writer.writerow([
            s.get('id', ''), s.get('cliente', ''), s.get('persona_reporta', ''),
            s.get('tipo_soporte', ''), s.get('prioridad', ''), s.get('estado', ''),
            s.get('descripcion', ''), s.get('fecha_reporte', ''), s.get('fecha_resuelto', ''),
            s.get('asignado_a', ''), s.get('sla_vencimiento', ''), sla_estado
        ])
    
    output.seek(0)
    fecha_actual = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    return Response(
        output.getvalue().encode('utf-8-sig'),
        mimetype='text/csv; charset=utf-8-sig',
        headers={'Content-Disposition': f'attachment; filename=solicitudes_export_{fecha_actual}.csv'}
    )


def exportar_a_excel(solicitudes):
    """Exporta una lista de solicitudes a Excel"""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Solicitudes Exportadas"
    
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="7C6AF7", end_color="7C6AF7", fill_type="solid")
    header_alignment = Alignment(horizontal="center", vertical="center")
    border = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin')
    )
    
    headers = ['ID', 'Cliente', 'Reportado por', 'Tipo de Soporte', 'Prioridad', 
               'Estado', 'Descripción', 'Fecha de Reporte', 'Fecha de Resolución', 
               'Asignado a', 'SLA Vencimiento', 'Estado SLA']
    
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_alignment
        cell.border = border
    
    for row, s in enumerate(solicitudes, 2):
        sla_estado = calcular_estado_sla(s)
        
        ws.cell(row=row, column=1, value=s.get('id', ''))
        ws.cell(row=row, column=2, value=s.get('cliente', ''))
        ws.cell(row=row, column=3, value=s.get('persona_reporta', ''))
        ws.cell(row=row, column=4, value=s.get('tipo_soporte', ''))
        ws.cell(row=row, column=5, value=s.get('prioridad', ''))
        ws.cell(row=row, column=6, value=s.get('estado', ''))
        ws.cell(row=row, column=7, value=s.get('descripcion', ''))
        
        fecha_reporte = s.get('fecha_reporte')
        if fecha_reporte:
            if isinstance(fecha_reporte, datetime):
                ws.cell(row=row, column=8, value=fecha_reporte.strftime('%Y-%m-%d %H:%M:%S'))
            else:
                ws.cell(row=row, column=8, value=str(fecha_reporte))
        
        fecha_resuelto = s.get('fecha_resuelto')
        if fecha_resuelto:
            if isinstance(fecha_resuelto, datetime):
                ws.cell(row=row, column=9, value=fecha_resuelto.strftime('%Y-%m-%d %H:%M:%S'))
            else:
                ws.cell(row=row, column=9, value=str(fecha_resuelto))
        
        ws.cell(row=row, column=10, value=s.get('asignado_a', ''))
        
        sla_vencimiento = s.get('sla_vencimiento')
        if sla_vencimiento:
            if isinstance(sla_vencimiento, datetime):
                ws.cell(row=row, column=11, value=sla_vencimiento.strftime('%Y-%m-%d %H:%M:%S'))
            else:
                ws.cell(row=row, column=11, value=str(sla_vencimiento))
        
        ws.cell(row=row, column=12, value=sla_estado)
        
        for col in range(1, 13):
            ws.cell(row=row, column=col).border = border
    
    for col in range(1, 13):
        ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = 20
    
    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    
    fecha_actual = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    return Response(
        output.getvalue(),
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        headers={'Content-Disposition': f'attachment; filename=solicitudes_export_{fecha_actual}.xlsx'}
    )