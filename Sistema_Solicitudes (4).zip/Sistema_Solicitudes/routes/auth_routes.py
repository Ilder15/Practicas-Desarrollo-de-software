from flask import request, jsonify
from services.auth_service import AuthService

# Rutas para manejar autenticacion y autorizacion de usuarios
def init_auth_routes(app):

    # Ruta para login de usuarios y obtencion de token JWT
    @app.route("/api/login", methods=["POST"])
    def login():
        try:
            data = request.get_json(force=True)
            usuario = data.get("usuario")
            password = data.get("password")
            
            if not usuario or not password:
                return jsonify({"error": "Credenciales obligatorias"}), 400
            
            token, nombre, tipo = AuthService.login(usuario, password)
            
            if token:
                return jsonify({
                    "token": token,
                    "nombre": nombre,
                    "tipo": tipo
                }), 200
            
            return jsonify({"error": "Usuario o contraseña incorrecto"}), 401
            
        except Exception as e:
            print("Error en login:", e)
            return jsonify({"error": "Error interno del servidor"}), 500