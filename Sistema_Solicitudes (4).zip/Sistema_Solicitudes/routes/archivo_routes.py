# routes/archivo_routes.py
import os
from flask import request, jsonify, send_file
from flask_jwt_extended import jwt_required, get_jwt
from services.archivo_service import ArchivoService
from utils.decorators import admin_required
from config.settings import config
import mimetypes

env = os.environ.get("FLASK_ENV", "development")
cfg = config[env]

def init_archivo_routes(app):
    # Rutas para manejar archivos adjuntos relacionados con solicitudes de vacaciones

    # Ruta para obtener todos los archivos de una solicitud
    @app.route("/api/solicitudes/<int:id_solicitud>/archivos", methods=["GET"])
    @jwt_required()
    def obtener_archivos(id_solicitud):
        """Obtiene todos los archivos de una solicitud"""
        archivos = ArchivoService.obtener_archivos_por_solicitud(id_solicitud)
        
        # Formatear para respuesta
        resultado = []
        for a in archivos:
            resultado.append({
                'id': a['id'],
                'nombre_original': a['nombre_original'],
                'tipo': a['tipo_mime'],
                'tamano': ArchivoService.formatear_tamano(a['tamano']),
                'tamano_bytes': a['tamano'],
                'fecha_subida': a['fecha_subida'].isoformat(),
                'url': f"/api/archivos/{a['id']}/descargar"
            })
        
        return jsonify({"archivos": resultado}), 200

    # Ruta para subir un nuevo archivo a una solicitud
    @app.route("/api/solicitudes/<int:id_solicitud>/archivos", methods=["POST"])
    @jwt_required()
    def subir_archivo(id_solicitud):
        """Sube un archivo a una solicitud"""
        claims = get_jwt()
        
        if 'archivo' not in request.files:
            return jsonify({"error": "No se encontró el archivo"}), 400
        
        file = request.files['archivo']
        
        success, message = ArchivoService.guardar_archivo(file, id_solicitud, claims.get("nombre"))
        
        if success:
            return jsonify({"message": message}), 201
        return jsonify({"error": message}), 400

    # Ruta para descargar un archivo por su ID
    # routes/archivo_routes.py
    @ app.route("/api/archivos/<int:id_archivo>/descargar", methods=["GET"])
    @jwt_required()
    def descargar_archivo(id_archivo):
        """Descarga un archivo adjunto"""
        from models.archivo import Archivo
        import os
        
        archivo = Archivo.get_by_id(id_archivo)
        if not archivo:
            return jsonify({"error": "Archivo no encontrado"}), 404
        
        ruta_fisica = os.path.join(cfg.UPLOAD_FOLDER, archivo['nombre_archivo'])
        
        if not os.path.exists(ruta_fisica):
            return jsonify({"error": "Archivo no encontrado en el servidor"}), 404
        
        # Enviar archivo con el nombre original
        return send_file(
            ruta_fisica,
            as_attachment=True,
            download_name=archivo['nombre_original'],
            mimetype=archivo['tipo_mime'] or 'application/octet-stream'
        )

    # Ruta para eliminar un archivo por su ID
    @app.route("/api/archivos/<int:id_archivo>", methods=["DELETE"])
    @jwt_required()
    def eliminar_archivo(id_archivo):
        """Elimina un archivo adjunto"""
        claims = get_jwt()
        
        success, message = ArchivoService.eliminar_archivo(id_archivo, claims.get("nombre"))
        
        if success:
            return jsonify({"message": message}), 200
        return jsonify({"error": message}), 404