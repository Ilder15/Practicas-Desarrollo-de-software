from flask import request, jsonify
from flask_jwt_extended import jwt_required, get_jwt
from services.usuario_service import UsuarioService
from utils.decorators import admin_required

# Rutas para manejar usuarios del sistema
def init_usuario_routes(app):

    # Ruta para obtener la lista de usuarios (solo administradores)
    @app.route("/api/usuarios", methods=["GET"])
    @jwt_required()
    @admin_required
    def obtener_usuarios():
        usuarios = UsuarioService.obtener_todos()
        return jsonify({"usuarios": usuarios}), 200

    # Ruta para registrar un nuevo usuario (admins)
    @app.route("/api/usuarios", methods=["POST"])
    @jwt_required()
    @admin_required
    def registrar_usuario():
        claims = get_jwt()
        data = request.get_json(force=True)
        
        usuario_data = {
            'usuario': data.get('usuario'),
            'password': data.get('password'),
            'nombre': data.get('nombre'),
            'tipo': int(data.get('tipo', 2)),
            'categoria': data.get('categoria')
        }
        
        success, message = UsuarioService.crear(usuario_data, claims.get("nombre"))
        
        if success:
            return jsonify({"message": message}), 201
        return jsonify({"error": message}), 400

    # Ruta para actualizar un usuario existente (admin)
    @app.route("/api/usuarios/<int:id_usuario>", methods=["PUT"])
    @jwt_required()
    @admin_required
    def actualizar_usuario(id_usuario):
        claims = get_jwt()
        data = request.get_json(force=True)
        
        usuario_data = {
            'nombre': data.get('nombre'),
            'usuario': data.get('usuario'),
            'tipo': data.get('tipo'),
            'categoria': data.get('categoria')
        }
        
        success, message = UsuarioService.actualizar(id_usuario, usuario_data, claims.get("nombre"))
        
        if success:
            return jsonify({"message": message}), 200
        return jsonify({"error": message}), 404

    # Ruta para eliminar un usuario (admin)
    @app.route("/api/usuarios/<int:id_usuario>", methods=["DELETE"])
    @jwt_required()
    @admin_required
    def eliminar_usuario(id_usuario):
        claims = get_jwt()
        
        success, message = UsuarioService.eliminar(id_usuario, claims.get("nombre"))
        
        if success:
            return jsonify({"message": message}), 200
        return jsonify({"error": message}), 404