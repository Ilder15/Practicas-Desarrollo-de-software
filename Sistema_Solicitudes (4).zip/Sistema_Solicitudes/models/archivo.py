# models/archivo.py
from datetime import datetime
from config.database import get_db

class Archivo:
    # Modelo para manejar archivos adjuntos relacionados con solicitudes de vacaciones
    # Metodo para obtener archivos por solicitud
    @staticmethod
    def get_by_solicitud(id_solicitud):
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "SELECT * FROM archivos_adjuntos WHERE id_solicitud = %s ORDER BY fecha_subida DESC",
            (id_solicitud,)
        )
        result = cursor.fetchall()
        cursor.close()
        return result

    # Metodo para obtener un archivo por su ID
    @staticmethod
    def get_by_id(id_archivo):
        db = get_db()
        cursor = db.cursor()
        cursor.execute("SELECT * FROM archivos_adjuntos WHERE id = %s", (id_archivo,))
        result = cursor.fetchone()
        cursor.close()
        return result

    # Metodo para crear un nuevo registro de archivo adjunto
    @staticmethod
    def create(id_solicitud, nombre_original, nombre_archivo, ruta, tipo_mime, tamano, usuario_subio):
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            """INSERT INTO archivos_adjuntos 
               (id_solicitud, nombre_original, nombre_archivo, ruta, tipo_mime, tamano, usuario_subio, fecha_subida)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
            (id_solicitud, nombre_original, nombre_archivo, ruta, tipo_mime, tamano, usuario_subio, datetime.now())
        )
        db.commit()
        nueva_id = cursor.lastrowid
        cursor.close()
        print(f"✅ Archivo guardado en BD: {nombre_original} (ID: {nueva_id})")
        return nueva_id

    # Metodo para eliminar un archivo adjunto por su ID
    @staticmethod
    def delete(id_archivo):
        db = get_db()
        cursor = db.cursor()
        cursor.execute("DELETE FROM archivos_adjuntos WHERE id = %s", (id_archivo,))
        db.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0