from datetime import datetime
from config.database import get_db

class Auditoria:
    # Modelo para manejar registros de auditoría de acciones realizadas en el sistema
    # Metodo para obtener los registros de auditoría más recientes
    @staticmethod
    def get_all(limit=200):
        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute("SELECT * FROM auditoria ORDER BY fecha DESC LIMIT %s", (limit,))
            result = cursor.fetchall()
            cursor.close()
            print(f"[DEBUG] Auditoria registros encontrados: {len(result) if result else 0}")
            return result if result else []
        except Exception as e:
            print(f"[ERROR] Error en Auditoria.get_all: {e}")
            return []

    # Metodo para crear un nuevo registro de auditoría
    @staticmethod
    def create(usuario, accion, id_solicitud=None, detalle=None):
        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute(
                "INSERT INTO auditoria (usuario, accion, id_solicitud, detalle, fecha) VALUES (%s, %s, %s, %s, %s)",
                (usuario, accion, id_solicitud, detalle, datetime.now())
            )
            db.commit()
            cursor.close()
            print(f"[DEBUG] Auditoria registrada: {accion} por {usuario}")
            return True
        except Exception as e:
            print(f"[ERROR] Error en Auditoria.create: {e}")
            return False