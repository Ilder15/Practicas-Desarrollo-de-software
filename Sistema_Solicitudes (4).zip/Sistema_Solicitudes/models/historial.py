# models/historial.py
from datetime import datetime
from config.database import get_db

class Historial:

# Modelo para manejar el historial de acciones realizadas sobre las solicitudes de vacaciones
# Cada vez que se realice una acción relevante (creación, aprobación, rechazo, edición), se registrará un nuevo evento en el historial con detalles de la acción, el usuario que la realizó y la fecha.
    @staticmethod
    def registrar(id_solicitud, accion, descripcion, usuario, datos_anteriores=None, datos_nuevos=None):
        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute(
                """INSERT INTO historial_solicitudes 
                   (id_solicitud, accion, descripcion, usuario, fecha, datos_anteriores, datos_nuevos)
                   VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                (id_solicitud, accion, descripcion, usuario, datetime.now(), datos_anteriores, datos_nuevos)
            )
            db.commit()
            cursor.close()
            print(f"[HISTORIAL] {accion}: {descripcion}")  # Log para depuración
            return True
        except Exception as e:
            print(f"Error registrando historial: {e}")
            return False
        
    # Metodo para obtener el historial de una solicitud específica
    @staticmethod
    def get_by_solicitud(id_solicitud, limit=100):
        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute(
                """SELECT * FROM historial_solicitudes 
                   WHERE id_solicitud = %s 
                   ORDER BY fecha DESC 
                   LIMIT %s""",
                (id_solicitud, limit)
            )
            result = cursor.fetchall()
            cursor.close()
            return result
        except Exception as e:
            print(f"Error obteniendo historial: {e}")
            return []