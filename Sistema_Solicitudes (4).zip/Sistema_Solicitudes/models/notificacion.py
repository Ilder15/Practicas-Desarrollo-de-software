from datetime import datetime
from config.database import get_db

class Notificacion:
    
    @staticmethod
    def get_by_usuario(usuario):
        """Obtiene todas las notificaciones de un usuario"""
        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute(
                "SELECT id, id_solicitud, mensaje, leida, fecha, tipo FROM notificaciones WHERE usuario = %s ORDER BY fecha DESC LIMIT 50",
                (usuario,)
            )
            result = cursor.fetchall()
            cursor.close()
            return result if result else []
        except Exception as e:
            print(f"Error en Notificacion.get_by_usuario: {e}")
            return []
    
    @staticmethod
    def create(usuario, id_solicitud, mensaje, tipo="info"):
        """Crea una nueva notificación"""
        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute(
                "INSERT INTO notificaciones (usuario, id_solicitud, mensaje, fecha, tipo) VALUES (%s, %s, %s, %s, %s)",
                (usuario, id_solicitud, mensaje, datetime.now(), tipo)
            )
            db.commit()
            nueva_id = cursor.lastrowid
            cursor.close()
            print(f"✅ Notificación creada ID {nueva_id} para {usuario} - Tipo: {tipo}")
            return nueva_id
        except Exception as e:
            print(f"Error en Notificacion.create: {e}")
            return None
    
    @staticmethod
    def count_no_leidas(usuario):
        """Cuenta las notificaciones no leídas de un usuario"""
        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute(
                "SELECT COUNT(*) as total FROM notificaciones WHERE usuario = %s AND leida = 0",
                (usuario,)
            )
            result = cursor.fetchone()
            cursor.close()
            return result['total'] if result else 0
        except Exception as e:
            print(f"Error en Notificacion.count_no_leidas: {e}")
            return 0
    
    @staticmethod
    def mark_all_as_read(usuario):
        """Marca todas las notificaciones de un usuario como leídas"""
        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute(
                "UPDATE notificaciones SET leida = 1 WHERE usuario = %s AND leida = 0",
                (usuario,)
            )
            db.commit()
            affected = cursor.rowcount
            cursor.close()
            print(f"✅ Marcadas {affected} notificaciones como leídas para {usuario}")
            return affected
        except Exception as e:
            print(f"Error en Notificacion.mark_all_as_read: {e}")
            return 0
    
    @staticmethod
    def delete_all(usuario):
        """Elimina todas las notificaciones de un usuario"""
        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute("DELETE FROM notificaciones WHERE usuario = %s", (usuario,))
            db.commit()
            affected = cursor.rowcount
            cursor.close()
            print(f"✅ Eliminadas {affected} notificaciones para {usuario}")
            return affected > 0
        except Exception as e:
            print(f"Error en Notificacion.delete_all: {e}")
            return False