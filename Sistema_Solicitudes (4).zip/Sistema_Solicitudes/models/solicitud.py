from datetime import datetime
from config.database import get_db

class Solicitud:
    # Modelo para manejar solicitudes de soporte técnico

    # Metodo para obtener todas las solicitudes, con opción de filtrar por usuario asignado o mostrar todas para admin
    @staticmethod
    def get_all(usuario=None, es_admin=False):
        db = get_db()
        cursor = db.cursor()
        
        if es_admin:
            cursor.execute("SELECT * FROM solicitudes ORDER BY fecha_reporte DESC")
        else:
            cursor.execute(
                "SELECT * FROM solicitudes WHERE asignado_a=%s ORDER BY fecha_reporte DESC",
                (usuario,)
            )
        result = cursor.fetchall()
        cursor.close()
        return result

    # Metodo para obtener una solicitud por su ID
    @staticmethod
    def get_by_id(id_solicitud):
        db = get_db()
        cursor = db.cursor()
        cursor.execute("SELECT * FROM solicitudes WHERE id=%s", (id_solicitud,))
        result = cursor.fetchone()
        cursor.close()
        return result

    # Metodo para crear una nueva solicitud
    @staticmethod
    def create(data):
        db = get_db()
        cursor = db.cursor()
        
        cursor.execute(
            """INSERT INTO solicitudes
               (cliente, persona_reporta, tipo_soporte, descripcion, prioridad, fecha_reporte, estado)
               VALUES (%s, %s, %s, %s, %s, %s, %s)""",
            (data['cliente'], data.get('persona_reporta'), data['tipo_soporte'],
             data.get('descripcion'), data['prioridad'], datetime.now(), data.get('estado', 'pendiente'))
        )
        db.commit()
        nueva_id = cursor.lastrowid
        cursor.close()
        return nueva_id

    #Metodo para actualizar una solicitud por su ID
    @staticmethod
    def update(id_solicitud, data):
        db = get_db()
        cursor = db.cursor()
        
        cursor.execute(
            """UPDATE solicitudes 
               SET cliente=%s, descripcion=%s, tipo_soporte=%s, prioridad=%s
               WHERE id=%s""",
            (data['cliente'], data.get('descripcion'), data['tipo_soporte'], data['prioridad'], id_solicitud)
        )
        db.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0

    # Metodo para actualizar el estado de una solicitud por ID
    @staticmethod
    def update_estado(id_solicitud, estado):
        db = get_db()
        cursor = db.cursor()
        cursor.execute("UPDATE solicitudes SET estado=%s WHERE id=%s", (estado, id_solicitud))
        db.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0

    # Metodo para asignar la solicitud a un técnico por su ID
    @staticmethod
    def update_asignado(id_solicitud, asignado_a):
        db = get_db()
        cursor = db.cursor()
        cursor.execute("UPDATE solicitudes SET asignado_a=%s WHERE id=%s", (asignado_a, id_solicitud))
        db.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0

    # Metodo para marcar como resuelta una solicitud por su ID
    @staticmethod
    def resolver(id_solicitud, asignado_a):
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "UPDATE solicitudes SET estado=%s, fecha_resuelto=NOW(), asignado_a=%s WHERE id=%s",
            ("resuelto", asignado_a, id_solicitud)
        )
        db.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0

    # Metodo para eliminar una solicitud por ID
    @staticmethod
    def delete(id_solicitud):
        db = get_db()
        cursor = db.cursor()
        cursor.execute("DELETE FROM solicitudes WHERE id=%s", (id_solicitud,))
        db.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0 
    
    # Metodo para obtener las solicitudes sin asignar para que el admin las vea en su dashboard y las asigne
    @staticmethod
    def get_sin_asignar():
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "SELECT * FROM solicitudes WHERE asignado_a IS NULL AND estado != 'resuelto' ORDER BY fecha_reporte ASC"
        )
        result = cursor.fetchall()
        cursor.close()
        return result

# Metodo para actualizar la fecha de vencimiento de una solicidad segun el dia que se reportó y la prioridad que tenga
    @staticmethod
    def actualizar_sla(id_solicitud, prioridad, fecha_reporte=None):
        """Actualiza la fecha de vencimiento SLA según la prioridad"""
        if fecha_reporte is None:
            solicitud = Solicitud.get_by_id(id_solicitud)
            if solicitud:
                fecha_reporte = solicitud['fecha_reporte']
        
        # Calcular vencimiento según prioridad
        from datetime import timedelta
        if prioridad == 'alta':
            vencimiento = fecha_reporte + timedelta(hours=6)
        elif prioridad == 'media':
            vencimiento = fecha_reporte + timedelta(hours=12)
        else:  # baja
            vencimiento = fecha_reporte + timedelta(hours=24)
        
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "UPDATE solicitudes SET sla_vencimiento = %s WHERE id = %s",
            (vencimiento, id_solicitud)
        )
        db.commit()
        cursor.close()
        return vencimiento

# Metodo para verificar si una solicitud cumple con el tiempo establecido para considerar si esta vencido o no
    @staticmethod
    def verificar_sla(id_solicitud):
        """Verifica si la solicitud cumple con el SLA"""
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "SELECT sla_vencimiento, estado, fecha_resuelto FROM solicitudes WHERE id = %s",
            (id_solicitud,)
        )
        solicitud = cursor.fetchone()
        cursor.close()
        
        if not solicitud:
            return None
        
        from datetime import datetime
        ahora = datetime.now()
        vencimiento = solicitud['sla_vencimiento']
        
        if solicitud['estado'] == 'resuelto':
            fecha_resuelto = solicitud['fecha_resuelto']
            if fecha_resuelto and vencimiento:
                return fecha_resuelto <= vencimiento
            return True
        else:
            # Pendiente o en proceso
            if vencimiento:
                return ahora <= vencimiento
            return True

# Metodo para obtener el estado detallado de la solicitud, indicando si está a tiempo, vencida o cumlida con retraso, y mostrando el tiempo restante o excedido
    @staticmethod
    def obtener_sla_status(id_solicitud):
        """Obtiene el estado detallado del SLA"""
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "SELECT sla_vencimiento, estado, fecha_resuelto FROM solicitudes WHERE id = %s",
            (id_solicitud,)
        )
        solicitud = cursor.fetchone()
        cursor.close()
        
        if not solicitud or not solicitud['sla_vencimiento']:
            return None
        
        from datetime import datetime
        ahora = datetime.now()
        vencimiento = solicitud['sla_vencimiento']
        fecha_resuelto = solicitud['fecha_resuelto']
        estado = solicitud['estado']
        
        # Si está resuelta, calcular si hubo retraso
        if estado == 'resuelto' and fecha_resuelto:
            if fecha_resuelto > vencimiento:
                tiempo_excedido = fecha_resuelto - vencimiento
                horas = int(tiempo_excedido.total_seconds() // 3600)
                minutos = int((tiempo_excedido.total_seconds() % 3600) // 60)
                
                if horas > 0:
                    mensaje = f"Cumplido con retraso de {horas}h {minutos}m"
                else:
                    mensaje = f"Cumplido con retraso de {minutos}m"
                
                return {
                    'estado': 'con_retraso',
                    'mensaje': mensaje,
                    'vencimiento': vencimiento.isoformat(),
                    'fecha_resuelto': fecha_resuelto.isoformat(),
                    'cumple': False,
                    'horas_retraso': horas,
                    'minutos_retraso': minutos
                }
            else:
                # Resuelto a tiempo
                return {
                    'estado': 'cumplido',
                    'mensaje': 'Cumplido a tiempo',
                    'vencimiento': vencimiento.isoformat(),
                    'fecha_resuelto': fecha_resuelto.isoformat(),
                    'cumple': True
                }
        
        # Si no está resuelta, calcular tiempo restante o vencido
        if vencimiento > ahora:
            tiempo_restante = vencimiento - ahora
            horas = int(tiempo_restante.total_seconds() // 3600)
            minutos = int((tiempo_restante.total_seconds() % 3600) // 60)
            segundos = int(tiempo_restante.total_seconds() % 60)
            
            if horas > 0:
                mensaje = f"A tiempo - {horas}h {minutos}m restantes"
            elif minutos > 0:
                mensaje = f"A tiempo - {minutos}m {segundos}s restantes"
            else:
                mensaje = f"A tiempo - {segundos}s restantes"
            
            return {
                'estado': 'a_tiempo',
                'mensaje': mensaje,
                'vencimiento': vencimiento.isoformat(),
                'cumple': True,
                'horas_restantes': horas,
                'minutos_restantes': minutos,
                'segundos_restantes': segundos
            }
        else:
            tiempo_excedido = ahora - vencimiento
            horas = int(tiempo_excedido.total_seconds() // 3600)
            minutos = int((tiempo_excedido.total_seconds() % 3600) // 60)
            
            if horas > 0:
                mensaje = f"VENCIDA - Retraso de {horas}h {minutos}m"
            else:
                mensaje = f"VENCIDA - Retraso de {minutos}m"
            
            return {
                'estado': 'vencida',
                'mensaje': mensaje,
                'vencimiento': vencimiento.isoformat(),
                'cumple': False,
                'horas_retraso': horas,
                'minutos_retraso': minutos
            }