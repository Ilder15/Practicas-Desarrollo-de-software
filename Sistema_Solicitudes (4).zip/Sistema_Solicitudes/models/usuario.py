from config.database import get_db
import bcrypt

class Usuario:
    # Modelo para manejar usuarios del sistema (Tecnicos, Administradores)

    # Metodo para obtener todos los usuarios
    @staticmethod
    def get_all():
        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute("SELECT id, nombre, usuario, tipo, categoria FROM usuarios")
            result = cursor.fetchall()
            cursor.close()
            print(f"[DEBUG] Usuarios encontrados: {len(result) if result else 0}")
            return result if result else []
        except Exception as e:
            print(f"[ERROR] Error en Usuario.get_all: {e}")
            return []

    #Metodo para obtener usuarios por ID
    @staticmethod
    def get_by_id(id_usuario):
        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute("SELECT id, nombre, usuario, tipo, categoria FROM usuarios WHERE id=%s", (id_usuario,))
            result = cursor.fetchone()
            cursor.close()
            return result
        except Exception as e:
            print(f"[ERROR] Error en Usuario.get_by_id: {e}")
            return None

    # Metodo para obtener un usuario por su usuario
    @staticmethod
    def get_by_username(usuario):
        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute("SELECT * FROM usuarios WHERE usuario = %s", (usuario,))
            result = cursor.fetchone()
            cursor.close()
            return result
        except Exception as e:
            print(f"[ERROR] Error en Usuario.get_by_username: {e}")
            return None

    # Metodo para crear un nuevo usuario
    @staticmethod
    def create(data):
        try:
            db = get_db()
            cursor = db.cursor()
            
            hashed = bcrypt.hashpw(data['password'].encode("utf-8"), bcrypt.gensalt(rounds=10))
            
            cursor.execute(
                "INSERT INTO usuarios (usuario, password, tipo, nombre, categoria) VALUES (%s, %s, %s, %s, %s)",
                (data['usuario'], hashed.decode("utf-8"), data['tipo'], data['nombre'], data.get('categoria'))
            )
            db.commit()
            nueva_id = cursor.lastrowid
            cursor.close()
            print(f"[DEBUG] Usuario creado: {data['usuario']} (ID: {nueva_id})")
            return nueva_id
        except Exception as e:
            print(f"[ERROR] Error en Usuario.create: {e}")
            return None

    # Metodo para actualizar un usuario por ID
    @staticmethod
    def update(id_usuario, data):
        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute(
                "UPDATE usuarios SET tipo=%s, nombre=%s, usuario=%s, categoria=%s WHERE id=%s",
                (data['tipo'], data['nombre'], data['usuario'], data.get('categoria'), id_usuario)
            )
            db.commit()
            affected = cursor.rowcount
            cursor.close()
            print(f"[DEBUG] Usuario actualizado ID {id_usuario}, afectados: {affected}")
            return affected > 0
        except Exception as e:
            print(f"[ERROR] Error en Usuario.update: {e}")
            return False

    # Metodo para eliminar un usuario por ID
    @staticmethod
    def delete(id_usuario):
        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute("DELETE FROM usuarios WHERE id=%s", (id_usuario,))
            db.commit()
            affected = cursor.rowcount
            cursor.close()
            print(f"[DEBUG] Usuario eliminado ID {id_usuario}, afectados: {affected}")
            return affected > 0
        except Exception as e:
            print(f"[ERROR] Error en Usuario.delete: {e}")
            return False

    # Metodo para verificar la contraseña de un usuario
    @staticmethod
    def verify_password(usuario, password):
        try:
            user = Usuario.get_by_username(usuario)
            if user and bcrypt.checkpw(password.encode("utf-8"), user["password"].encode("utf-8")):
                return user
            return None
        except Exception as e:
            print(f"[ERROR] Error en Usuario.verify_password: {e}")
            return None

    # Metodo para obtener el tecnico con menos solicitudes activas en una categoria en especifico
    @staticmethod
    def get_tecnico_by_categoria(categoria):
        try:
            db = get_db()
            cursor = db.cursor()
            cursor.execute("""
                SELECT u.nombre, COUNT(s.id) as activas
                FROM usuarios u
                LEFT JOIN solicitudes s ON s.asignado_a = u.nombre AND s.estado != 'resuelto'
                WHERE u.categoria = %s AND u.tipo = 2
                GROUP BY u.nombre
                ORDER BY activas ASC
                LIMIT 1
            """, (categoria,))
            result = cursor.fetchone()
            cursor.close()
            return result['nombre'] if result else None
        except Exception as e:
            print(f"[ERROR] Error en Usuario.get_tecnico_by_categoria: {e}")
            return None