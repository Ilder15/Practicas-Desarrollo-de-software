from models.auditoria import Auditoria

class AuditoriaService:
    
    @staticmethod
    def obtener_todas(limit=200):
        return Auditoria.get_all(limit)
    
    @staticmethod
    def registrar(usuario, accion, id_solicitud=None, detalle=None):
        Auditoria.create(usuario, accion, id_solicitud, detalle)