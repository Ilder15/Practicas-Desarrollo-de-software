# services/archivo_service.py
import os
import uuid
from werkzeug.utils import secure_filename
from config.settings import config
from models.archivo import Archivo

env = os.environ.get("FLASK_ENV", "development")
cfg = config[env]

class ArchivoService:
    
    ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'xls', 'xlsx', 'txt', 'zip'}
    
    @staticmethod
    def allowed_file(filename):
        """Verifica si la extensión del archivo está permitida"""
        if not filename or '.' not in filename:
            return False
        extension = filename.rsplit('.', 1)[1].lower()
        return extension in ArchivoService.ALLOWED_EXTENSIONS
    
    @staticmethod
    def guardar_archivo_publico(file, id_solicitud, nombre_usuario="Público"):
        """Guarda un archivo adjunto (sin autenticación)"""
        print(f"[DEBUG] Iniciando guardado de archivo para solicitud {id_solicitud}")
        
        if not file or file.filename == '':
            return False, "No se seleccionó ningún archivo"
        
        if not ArchivoService.allowed_file(file.filename):
            return False, f"Tipo de archivo no permitido. Permitidos: {', '.join(ArchivoService.ALLOWED_EXTENSIONS)}"
        
        try:
            # Crear nombre único para el archivo
            original_nombre = secure_filename(file.filename)
            extension = original_nombre.rsplit('.', 1)[1].lower()
            nuevo_nombre = f"{uuid.uuid4().hex}.{extension}"
            
            # Crear carpeta si no existe
            os.makedirs(cfg.UPLOAD_FOLDER, exist_ok=True)
            print(f"[DEBUG] Carpeta de uploads: {cfg.UPLOAD_FOLDER}")
            
            # Guardar archivo físicamente
            ruta_completa = os.path.join(cfg.UPLOAD_FOLDER, nuevo_nombre)
            file.save(ruta_completa)
            print(f"[DEBUG] Archivo guardado físicamente: {ruta_completa}")
            
            # Obtener tamaño
            tamano = os.path.getsize(ruta_completa)
            
            # Guardar en BD
            nueva_id = Archivo.create(
                id_solicitud,
                original_nombre,
                nuevo_nombre,
                f"/uploads/solicitudes/{nuevo_nombre}",
                file.content_type,
                tamano,
                nombre_usuario
            )
            
            print(f"[DEBUG] Archivo registrado en BD con ID: {nueva_id}")
            return True, "Archivo subido correctamente"
            
        except Exception as e:
            print(f"[ERROR] Error guardando archivo: {e}")
            import traceback
            traceback.print_exc()
            return False, f"Error al guardar archivo: {str(e)}"
    
    @staticmethod
    def obtener_archivos_por_solicitud(id_solicitud):
        """Obtiene todos los archivos de una solicitud"""
        return Archivo.get_by_solicitud(id_solicitud)
    
    @staticmethod
    def formatear_tamano(bytes):
        """Formatea el tamaño de archivo en KB/MB/GB"""
        if bytes < 1024:
            return f"{bytes} B"
        elif bytes < 1024 * 1024:
            return f"{bytes / 1024:.1f} KB"
        elif bytes < 1024 * 1024 * 1024:
            return f"{bytes / (1024 * 1024):.1f} MB"
        else:
            return f"{bytes / (1024 * 1024 * 1024):.1f} GB"