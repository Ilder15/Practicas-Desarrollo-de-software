from models.usuario import Usuario
from services.auditoria_service import AuditoriaService

class UsuarioService:
    
    @staticmethod
    def obtener_todos():
        return Usuario.get_all()
    
    @staticmethod
    def obtener_por_id(id_usuario):
        return Usuario.get_by_id(id_usuario)
    
    @staticmethod
    def crear(data, usuario_creador):
        # Verificar si ya existe
        existing = Usuario.get_by_username(data['usuario'])
        if existing:
            return False, "El usuario ya existe"
        
        Usuario.create(data)
        AuditoriaService.registrar(usuario_creador, "crear_usuario", detalle=f"usuario creado: {data['usuario']}")
        return True, "Usuario registrado exitosamente"
    
    @staticmethod
    def actualizar(id_usuario, data, usuario_editor):
        if Usuario.update(id_usuario, data):
            AuditoriaService.registrar(usuario_editor, "editar_usuario", detalle=f"usuario editado: ID {id_usuario}")
            return True, "Usuario actualizado exitosamente"
        return False, "Usuario no encontrado"
    
    @staticmethod
    def eliminar(id_usuario, usuario_eliminador):
        usuario = Usuario.get_by_id(id_usuario)
        if not usuario:
            return False, "Usuario no encontrado"
        
        if Usuario.delete(id_usuario):
            AuditoriaService.registrar(
                usuario_eliminador, "eliminar_usuario",
                detalle=f"usuario eliminado: {usuario['usuario']} ({usuario['nombre']})"
            )
            return True, "Usuario eliminado exitosamente"
        return False, "Error al eliminar"
    
    @staticmethod
    def auto_asignar(categoria):
        return Usuario.get_tecnico_by_categoria(categoria)