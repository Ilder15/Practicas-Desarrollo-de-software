from flask_jwt_extended import create_access_token
from models.usuario import Usuario

class AuthService:
    
    @staticmethod
    def login(usuario, password):
        user = Usuario.verify_password(usuario, password)
        
        if not user:
            return None, None, None
        
        token = create_access_token(
            identity=usuario,
            additional_claims={"tipo": user["tipo"], "nombre": user["nombre"]}
        )
        
        return token, user["nombre"], user["tipo"]