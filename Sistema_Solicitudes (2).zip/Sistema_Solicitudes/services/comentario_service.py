from models.comentario import Comentario
from services.auditoria_service import AuditoriaService

class ComentarioService:
    
    @staticmethod
    def obtener_por_solicitud(id_solicitud):
        return Comentario.get_by_solicitud(id_solicitud)
    
    @staticmethod
    def crear(id_solicitud, usuario, mensaje):
        Comentario.create(id_solicitud, usuario, mensaje)
        AuditoriaService.registrar(usuario, "comentario_agregado", id_solicitud, mensaje[:50])
        return True