from models.notificacion import Notificacion

class NotificacionService:
    
    @staticmethod
    def obtener_por_usuario(usuario):
        return Notificacion.get_by_usuario(usuario)
    
    @staticmethod
    def crear(usuario, id_solicitud, mensaje):
        Notificacion.create(usuario, id_solicitud, mensaje)
    
    @staticmethod
    def contar_no_leidas(usuario):
        return Notificacion.count_no_leidas(usuario)
    
    @staticmethod
    def marcar_todas_como_leidas(usuario):
        Notificacion.mark_all_as_read(usuario)
    
    @staticmethod
    def limpiar_todas(usuario):
        Notificacion.delete_all(usuario)