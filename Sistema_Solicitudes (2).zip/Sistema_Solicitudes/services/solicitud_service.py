from models.solicitud import Solicitud
from models.usuario import Usuario
from services.auditoria_service import AuditoriaService
from services.notificacion_service import NotificacionService

class SolicitudService:
    
    @staticmethod
    def obtener_todas(usuario, es_admin):
        return Solicitud.get_all(usuario if not es_admin else None, es_admin)
    
    @staticmethod
    def obtener_por_id(id_solicitud):
        return Solicitud.get_by_id(id_solicitud)
    
    @staticmethod
    def obtener_sin_asignar():
        return Solicitud.get_sin_asignar()
    
    @staticmethod
    def crear(data, usuario_creador):
        # Crear solicitud
        nueva_id = Solicitud.create(data)
        
        # Registrar auditoría
        AuditoriaService.registrar(
            usuario_creador, 
            "crear_solicitud", 
            nueva_id,
            f"Cliente: {data['cliente']}"
        )
        
        # Auto-asignar si es necesario
        asignado = Usuario.get_tecnico_by_categoria(data['tipo_soporte'])
        
        if asignado:
            Solicitud.update_asignado(nueva_id, asignado)
            AuditoriaService.registrar(asignado, "asignar", nueva_id, "auto-asignado por categoría")
            NotificacionService.crear(
                asignado, 
                nueva_id,
                f"Nueva solicitud asignada: {data['cliente']} ({data['tipo_soporte']} · {data['prioridad']})"
            )
        
        return nueva_id, asignado
    
    @staticmethod
    def actualizar(id_solicitud, data, usuario):
        solicitud = Solicitud.get_by_id(id_solicitud)
        if not solicitud:
            return False
        
        if solicitud['estado'] == 'resuelto':
            return False
        
        if Solicitud.update(id_solicitud, data):
            AuditoriaService.registrar(
                usuario, "editar_solicitud", id_solicitud,
                f"cliente: {data['cliente']} · {data['tipo_soporte']} · {data['prioridad']}"
            )
            return True
        return False
    
    @staticmethod
    def actualizar_estado(id_solicitud, estado, usuario):
        if Solicitud.update_estado(id_solicitud, estado):
            AuditoriaService.registrar(usuario, "editar_estado", id_solicitud, f"nuevo estado: {estado}")
            return True
        return False
    
    @staticmethod
    def resolver(id_solicitud, asignado_a, usuario):
        if Solicitud.resolver(id_solicitud, asignado_a):
            AuditoriaService.registrar(usuario, "resolver", id_solicitud)
            return True
        return False
    
    @staticmethod
    def asignar(id_solicitud, asignado_a, usuario, es_admin=False):
        solicitud = Solicitud.get_by_id(id_solicitud)
        if not solicitud:
            return False, "Solicitud no encontrada"
        
        if solicitud['asignado_a']:
            return False, "Esta solicitud ya tiene un responsable asignado"
        
        if not es_admin and asignado_a != usuario:
            return False, "No autorizado"
        
        if Solicitud.update_asignado(id_solicitud, asignado_a):
            AuditoriaService.registrar(usuario, "asignar", id_solicitud, f"asignado a: {asignado_a}")
            NotificacionService.crear(
                asignado_a, id_solicitud,
                f"Nueva solicitud asignada: {solicitud['cliente']} ({solicitud['tipo_soporte']} · {solicitud['prioridad']})"
            )
            return True, "Asignado correctamente"
        return False, "Error al asignar"
    
    @staticmethod
    def reasignar(id_solicitud, nuevo_asignado, usuario):
        solicitud = Solicitud.get_by_id(id_solicitud)
        if not solicitud:
            return False, "Solicitud no encontrada"
        
        anterior = solicitud['asignado_a'] or "Sin asignar"
        
        if Solicitud.update_asignado(id_solicitud, nuevo_asignado):
            AuditoriaService.registrar(
                usuario, "reasignar", id_solicitud,
                f"reasignado de {anterior} a {nuevo_asignado}"
            )
            NotificacionService.crear(
                nuevo_asignado, id_solicitud,
                f"Solicitud reasignada: {solicitud['cliente']} ({solicitud['tipo_soporte']} · {solicitud['prioridad']})"
            )
            return True, f"Reasignado a {nuevo_asignado}"
        return False, "Error al reasignar"
    
    @staticmethod
    def eliminar(id_solicitud, usuario):
        if Solicitud.delete(id_solicitud):
            AuditoriaService.registrar(usuario, "eliminar", id_solicitud)
            return True
        return False