from datetime import datetime
from config.database import get_db

class Solicitud:
    
    @staticmethod
    def get_all(usuario=None, es_admin=False):
        db = get_db()
        cursor = db.cursor()
        
        if es_admin:
            cursor.execute("SELECT * FROM solicitudes ORDER BY fecha_reporte DESC")
        else:
            cursor.execute(
                "SELECT * FROM solicitudes WHERE asignado_a=%s ORDER BY fecha_reporte DESC",
                (usuario,)
            )
        result = cursor.fetchall()
        cursor.close()
        return result
    
    @staticmethod
    def get_by_id(id_solicitud):
        db = get_db()
        cursor = db.cursor()
        cursor.execute("SELECT * FROM solicitudes WHERE id=%s", (id_solicitud,))
        result = cursor.fetchone()
        cursor.close()
        return result
    
    @staticmethod
    def create(data):
        db = get_db()
        cursor = db.cursor()
        
        cursor.execute(
            """INSERT INTO solicitudes
               (cliente, persona_reporta, tipo_soporte, descripcion, prioridad, fecha_reporte, estado)
               VALUES (%s, %s, %s, %s, %s, %s, %s)""",
            (data['cliente'], data.get('persona_reporta'), data['tipo_soporte'],
             data.get('descripcion'), data['prioridad'], datetime.now(), data.get('estado', 'pendiente'))
        )
        db.commit()
        nueva_id = cursor.lastrowid
        cursor.close()
        return nueva_id
    
    @staticmethod
    def update(id_solicitud, data):
        db = get_db()
        cursor = db.cursor()
        
        cursor.execute(
            """UPDATE solicitudes 
               SET cliente=%s, descripcion=%s, tipo_soporte=%s, prioridad=%s
               WHERE id=%s""",
            (data['cliente'], data.get('descripcion'), data['tipo_soporte'], data['prioridad'], id_solicitud)
        )
        db.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0
    
    @staticmethod
    def update_estado(id_solicitud, estado):
        db = get_db()
        cursor = db.cursor()
        cursor.execute("UPDATE solicitudes SET estado=%s WHERE id=%s", (estado, id_solicitud))
        db.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0
    
    @staticmethod
    def update_asignado(id_solicitud, asignado_a):
        db = get_db()
        cursor = db.cursor()
        cursor.execute("UPDATE solicitudes SET asignado_a=%s WHERE id=%s", (asignado_a, id_solicitud))
        db.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0
    
    @staticmethod
    def resolver(id_solicitud, asignado_a):
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "UPDATE solicitudes SET estado=%s, fecha_resuelto=NOW(), asignado_a=%s WHERE id=%s",
            ("resuelto", asignado_a, id_solicitud)
        )
        db.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0
    
    @staticmethod
    def delete(id_solicitud):
        db = get_db()
        cursor = db.cursor()
        cursor.execute("DELETE FROM solicitudes WHERE id=%s", (id_solicitud,))
        db.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0
    
    @staticmethod
    def get_sin_asignar():
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "SELECT * FROM solicitudes WHERE asignado_a IS NULL AND estado != 'resuelto' ORDER BY fecha_reporte ASC"
        )
        result = cursor.fetchall()
        cursor.close()
        return result