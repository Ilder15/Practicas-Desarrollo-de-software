from config.database import get_db
import bcrypt

class Usuario:
    
    @staticmethod
    def get_all():
        db = get_db()
        cursor = db.cursor()
        cursor.execute("SELECT id, nombre, usuario, tipo, categoria FROM usuarios")
        result = cursor.fetchall()
        cursor.close()
        return result
    
    @staticmethod
    def get_by_id(id_usuario):
        db = get_db()
        cursor = db.cursor()
        cursor.execute("SELECT id, nombre, usuario, tipo, categoria FROM usuarios WHERE id=%s", (id_usuario,))
        result = cursor.fetchone()
        cursor.close()
        return result
    
    @staticmethod
    def get_by_username(usuario):
        db = get_db()
        cursor = db.cursor()
        cursor.execute("SELECT * FROM usuarios WHERE usuario = %s", (usuario,))
        result = cursor.fetchone()
        cursor.close()
        return result
    
    @staticmethod
    def create(data):
        db = get_db()
        cursor = db.cursor()
        
        hashed = bcrypt.hashpw(data['password'].encode("utf-8"), bcrypt.gensalt(rounds=10))
        
        cursor.execute(
            "INSERT INTO usuarios (usuario, password, tipo, nombre, categoria) VALUES (%s, %s, %s, %s, %s)",
            (data['usuario'], hashed.decode("utf-8"), data['tipo'], data['nombre'], data.get('categoria'))
        )
        db.commit()
        nueva_id = cursor.lastrowid
        cursor.close()
        return nueva_id
    
    @staticmethod
    def update(id_usuario, data):
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "UPDATE usuarios SET tipo=%s, nombre=%s, usuario=%s, categoria=%s WHERE id=%s",
            (data['tipo'], data['nombre'], data['usuario'], data.get('categoria'), id_usuario)
        )
        db.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0
    
    @staticmethod
    def delete(id_usuario):
        db = get_db()
        cursor = db.cursor()
        cursor.execute("DELETE FROM usuarios WHERE id=%s", (id_usuario,))
        db.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0
    
    @staticmethod
    def verify_password(usuario, password):
        user = Usuario.get_by_username(usuario)
        if user and bcrypt.checkpw(password.encode("utf-8"), user["password"].encode("utf-8")):
            return user
        return None
    
    @staticmethod
    def get_tecnico_by_categoria(categoria):
        """Retorna el técnico con menos solicitudes activas en la categoría"""
        db = get_db()
        cursor = db.cursor()
        cursor.execute("""
            SELECT u.nombre, COUNT(s.id) as activas
            FROM usuarios u
            LEFT JOIN solicitudes s ON s.asignado_a = u.nombre AND s.estado != 'resuelto'
            WHERE u.categoria = %s AND u.tipo = 2
            GROUP BY u.nombre
            ORDER BY activas ASC
            LIMIT 1
        """, (categoria,))
        result = cursor.fetchone()
        cursor.close()
        return result['nombre'] if result else None