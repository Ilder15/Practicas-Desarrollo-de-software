from datetime import datetime
from config.database import get_db

class Comentario:
    
    @staticmethod
    def get_by_solicitud(id_solicitud):
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "SELECT * FROM comentarios WHERE id_solicitud = %s ORDER BY fecha ASC",
            (id_solicitud,)
        )
        result = cursor.fetchall()
        cursor.close()
        return result
    
    @staticmethod
    def create(id_solicitud, usuario, mensaje):
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "INSERT INTO comentarios (id_solicitud, usuario, mensaje, fecha) VALUES (%s, %s, %s, %s)",
            (id_solicitud, usuario, mensaje, datetime.now())
        )
        db.commit()
        nueva_id = cursor.lastrowid
        cursor.close()
        return nueva_id