from datetime import datetime
from config.database import get_db

class Notificacion:
    
    @staticmethod
    def get_by_usuario(usuario):
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "SELECT id, id_solicitud, mensaje, leida, fecha FROM notificaciones WHERE usuario = %s ORDER BY fecha DESC LIMIT 30",
            (usuario,)
        )
        result = cursor.fetchall()
        cursor.close()
        return result
    
    @staticmethod
    def create(usuario, id_solicitud, mensaje):
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "INSERT INTO notificaciones (usuario, id_solicitud, mensaje, fecha) VALUES (%s, %s, %s, %s)",
            (usuario, id_solicitud, mensaje, datetime.now())
        )
        db.commit()
        cursor.close()
    
    @staticmethod
    def count_no_leidas(usuario):
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "SELECT COUNT(*) as total FROM notificaciones WHERE usuario = %s AND leida = 0",
            (usuario,)
        )
        result = cursor.fetchone()
        cursor.close()
        return result['total'] if result else 0
    
    @staticmethod
    def mark_all_as_read(usuario):
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "UPDATE notificaciones SET leida = 1 WHERE usuario = %s AND leida = 0",
            (usuario,)
        )
        db.commit()
        cursor.close()
    

    @staticmethod
    def delete_all(usuario):
        db = get_db()
        cursor = db.cursor()
        cursor.execute("DELETE FROM notificaciones WHERE usuario = %s", (usuario,))
        db.commit()
        affected = cursor.rowcount
        cursor.close()
        print(f"✅ Eliminadas {affected} notificaciones para {usuario}")
        return affected > 0