from datetime import datetime
from config.database import get_db

class Auditoria:
    
    @staticmethod
    def get_all(limit=200):
        db = get_db()
        cursor = db.cursor()
        cursor.execute("SELECT * FROM auditoria ORDER BY fecha DESC LIMIT %s", (limit,))
        result = cursor.fetchall()
        cursor.close()
        return result
    
    @staticmethod
    def create(usuario, accion, id_solicitud=None, detalle=None):
        db = get_db()
        cursor = db.cursor()
        cursor.execute(
            "INSERT INTO auditoria (usuario, accion, id_solicitud, detalle, fecha) VALUES (%s, %s, %s, %s, %s)",
            (usuario, accion, id_solicitud, detalle, datetime.now())
        )
        db.commit()
        cursor.close()