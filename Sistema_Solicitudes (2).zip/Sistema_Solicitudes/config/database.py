import pymysql
from dbutils.pooled_db import PooledDB
from flask import g
from config.settings import config
import os

env = os.environ.get("FLASK_ENV", "development")
cfg = config[env]

pool = PooledDB(
    creator=pymysql,
    maxconnections=10,
    mincached=3,
    blocking=True,
    host=cfg.DB_HOST,
    user=cfg.DB_USER,
    password=cfg.DB_PASSWORD,
    db=cfg.DB_NAME,
    cursorclass=pymysql.cursors.DictCursor
)

def get_db():
    if 'db' not in g:
        g.db = pool.connection()
    return g.db

def close_db(error):
    db = g.pop('db', None)
    if db is not None:
        db.close()