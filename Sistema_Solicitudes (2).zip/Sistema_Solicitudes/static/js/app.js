// ========== VARIABLES GLOBALES ==========
let idSolicitudActiva = null;
let editandoSolicitudId = null;
let editandoId = null;
let asignandoId = null;
let notifPanelAbierto = false;
let solicitudesData = [];

const token = localStorage.getItem("token");
const nombre = localStorage.getItem("nombre");
const tipo = localStorage.getItem("tipo");

const categoriaLabel = {
    software: "Software",
    hardware: "Hardware",
    visitas_tecnicas: "Visitas Técnicas",
};

if (!token) window.location.href = "/login";

// ========== CONFIGURACIÓN UI ==========
if (nombre) {
    document.getElementById("nombreAdmin").textContent = nombre;
    document.getElementById("avatarInitial").textContent = nombre.charAt(0).toUpperCase();
}

const roles = { 1: "Administrador", 2: "Tecnico" };
const rolEl = document.querySelector(".user-role");
if (rolEl) rolEl.textContent = roles[tipo] || "Tecnico";

// Ocultar secciones si no es admin
if (tipo !== "1") {
    document.querySelectorAll(".sidenav-link").forEach((link) => {
        const texto = link.querySelector("span")?.textContent.trim();
        if (["Usuarios", "Reportes", "Auditoria", "Configuración"].includes(texto)) {
            link.style.display = "none";
        }
    });
}

// ========== FUNCIONES UTILITY ==========
function escapeHtml(text) {
    if (!text) return text;
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showToast(msg, type = "success") {
    const t = document.getElementById("toast");
    t.textContent = msg;
    t.className = `toast ${type} show`;
    setTimeout(() => t.classList.remove("show"), 3000);
}

function formatFecha(fecha) {
    if (!fecha) return "—";
    return new Date(fecha).toLocaleDateString("es-CO", {
        day: "2-digit",
        month: "short",
        year: "numeric",
    });
}

// ========== API FETCH ==========
async function apiFetch(url, options = {}) {
    try {
        const res = await fetch(url, {
            ...options,
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token,
                ...options.headers,
            },
        });
        
        if (res.status === 401) {
            localStorage.clear();
            window.location.href = "/login";
            return null;
        }
        return res;
    } catch (error) {
        console.error("Error en apiFetch:", error);
        return null;
    }
}

// ========== SIDENAV ==========
function toggleSidenav() {
    document.getElementById("sidenav").classList.toggle("collapsed");
}

const sectionTitles = {
    solicitudes: "Solicitudes",
    usuarios: "Usuarios",
    reportes: "Reportes",
    configuracion: "Configuración",
    auditoria: "Auditoría",
};

window.switchSection = function(name, btn) {
    document.querySelectorAll(".page-section").forEach(s => s.classList.remove("active"));
    document.querySelectorAll(".sidenav-link").forEach(l => l.classList.remove("active"));
    document.getElementById("sec-" + name).classList.add("active");
    btn.classList.add("active");
    document.getElementById("topbarTitle").textContent = sectionTitles[name] || name;

    if (name === "usuarios") cargarUsuarios();
    if (name === "auditoria") cargarAuditoria();
};

// ========== TABS ==========
window.switchTab = function(name, btn) {
    document.querySelectorAll(".sub-section").forEach(s => s.classList.remove("active"));
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.getElementById("sec-" + name).classList.add("active");
    btn.classList.add("active");
};

// ========== SOLICITUDES ==========
async function cargarSolicitudes() {
    try {
        const res = await apiFetch("/api/solicitudes");
        if (!res) return;
        const data = await res.json();
        solicitudesData = data.registros || [];
        renderTabla(solicitudesData);
        actualizarStats(solicitudesData);
        renderRecientes(solicitudesData);

        const recientesCard = document.querySelector(".recientes-card");
        if (recientesCard) recientesCard.style.display = tipo === "1" ? "block" : "none";
    } catch (e) {
        document.getElementById("tablaSolicitudes").innerHTML = `<td colspan="8"><div class="empty-state">❌ Error al cargar datos</div></td>`;
    }
}

function actualizarStats(data) {
    document.getElementById("statTotal").textContent = data.length;
    document.getElementById("statPendiente").textContent = data.filter(s => s.estado === "pendiente").length;
    document.getElementById("statResuelto").textContent = data.filter(s => s.estado === "resuelto").length;
    document.getElementById("statProceso").textContent = data.filter(s => s.estado === "en proceso").length;
}

function renderTabla(data) {
    const tbody = document.getElementById("tablaSolicitudes");
    if (!data.length) {
        tbody.innerHTML = `<td colspan="8"><div class="empty-state">📭 No hay solicitudes</div></td>`;
        return;
    }
    
    tbody.innerHTML = data.map(s => {
        const noResuelto = s.estado !== "resuelto";
        return `
            <tr>
                <td style="color:var(--muted)">#${s.id}</td>
                <td><strong>${escapeHtml(s.cliente)}</strong></td>
                <td>${escapeHtml(s.persona_reporta || "—")}</td>
                <td>${s.tipo_soporte}</td>
                <td><span class="badge badge-${s.prioridad}">${s.prioridad}</span></td>
                <td><span class="badge badge-${s.estado === "en proceso" ? "proceso" : s.estado}">${s.estado}</span></td>
                ${tipo === "1" ? `<td style="color:var(--muted);">${s.asignado_a || "—"}</td>` : ""}
                <td class="action-cell">
                    <div class="menu-container">
                        <button class="btn-dots" onclick="toggleActionMenu(event, ${s.id})">⋮</button>
                        <div id="menu-${s.id}" class="dropdown-actions">
                            <button onclick="verDetalles(${s.id})">Ver Detalles</button>
                            ${noResuelto ? `<button onclick="abrirEditarEstado(${s.id}, '${s.estado}')">Editar Estado</button>` : ""}
                            ${noResuelto ? `<div class="divider"></div>` : ""}
                            ${tipo === "1" ? `<button onclick="abrirEditarSolicitud(${s.id})">Editar</button>` : ""}
                            ${noResuelto && !s.asignado_a ? `<button onclick="asignarme(${s.id})">Asignarme</button>` : ""}
                            ${noResuelto && !s.asignado_a && tipo === "1" ? `<button onclick="asignarA(${s.id})">Asignar a...</button>` : ""}
                            ${tipo === "1" && s.asignado_a ? `<button onclick="reasignarA(${s.id})">Reasignar</button>` : ""}
                            ${noResuelto ? `<button class="resolve-opt" onclick="resolver(${s.id})">Resolver</button>` : ""}
                            ${tipo === "1" ? `<div class="divider"></div><button class="delete-opt" onclick="borrarSolicitud(${s.id})">Eliminar</button>` : ""}
                        </div>
                    </div>
                </td>
            </tr>
        `;
    }).join("");
}

function renderRecientes(data) {
    const sinAsignar = data.filter(s => !s.asignado_a && s.estado !== "resuelto").slice(0, 5);
    const total = data.filter(s => !s.asignado_a && s.estado !== "resuelto").length;
    
    document.getElementById("recientesCount").textContent = `${total} pendientes`;
    const lista = document.getElementById("recientesLista");
    
    if (!sinAsignar.length) {
        lista.innerHTML = `<div class="reciente-empty">✅ Todas las solicitudes están asignadas</div>`;
        return;
    }
    
    lista.innerHTML = sinAsignar.map(s => `
        <div class="reciente-item">
            <div class="reciente-info">
                <span class="reciente-cliente">${escapeHtml(s.cliente)}</span>
                <span class="reciente-meta">${s.tipo_soporte} · ${formatFecha(s.fecha_reporte)}</span>
            </div>
            <div class="reciente-right">
                <span class="badge badge-${s.prioridad}">${s.prioridad}</span>
                <button class="btn-action" onclick="verDetalles(${s.id})">Ver</button>
                <button class="btn-action" onclick="asignarA(${s.id})">Asignar</button>
                <button class="btn-action" onclick="asignarme(${s.id})">Asignarme</button>
            </div>
        </div>
    `).join("");
}

// ========== CREAR SOLICITUD ==========
window.crearSolicitud = async function() {
    const body = {
        cliente: document.getElementById("f-cliente").value.trim(),
        persona_reporta: nombre,
        tipo_soporte: document.getElementById("f-tipo").value,
        prioridad: document.getElementById("f-prioridad").value,
        estado: document.getElementById("f-estado").value,
        descripcion: document.getElementById("f-descripcion").value.trim(),
    };
    
    if (!body.cliente || !body.tipo_soporte || !body.prioridad) {
        showToast("Completa todos los campos obligatorios", "error");
        return;
    }
    
    const btn = document.querySelector('#sec-crear .btn-primary');
    const originalText = btn.textContent;
    btn.textContent = "Enviando...";
    btn.disabled = true;
    
    try {
        const res = await apiFetch("/api/solicitudes", {
            method: "POST",
            body: JSON.stringify(body),
        });
        if (!res) return;
        
        const data = await res.json();
        if (res.ok) {
            showToast(`Solicitud creada ✓`, "success");
            
            document.getElementById("f-cliente").value = "";
            document.getElementById("f-descripcion").value = "";
            document.getElementById("f-tipo").value = "";
            document.getElementById("f-prioridad").value = "";
            
            switchTab("lista", document.querySelector(".tab"));
            await cargarSolicitudes();
        } else {
            showToast(data.error || "Error al crear", "error");
        }
    } catch (e) {
        showToast("Error de conexión", "error");
    } finally {
        btn.textContent = originalText;
        btn.disabled = false;
    }
};

// ========== ELIMINAR SOLICITUD ==========
window.borrarSolicitud = async function(id) {
    if (!confirm("¿Eliminar esta solicitud?")) return;
    const res = await apiFetch(`/api/solicitudes/${id}`, { method: "DELETE" });
    if (res?.ok) {
        showToast("Solicitud eliminada ✓", "success");
        await cargarSolicitudes();
    } else {
        showToast("Error al eliminar", "error");
    }
};

// ========== EDITAR SOLICITUD ==========
window.abrirEditarSolicitud = function(id) {
    const s = solicitudesData.find(s => s.id === id);
    if (!s) return;
    editandoSolicitudId = id;
    idSolicitudActiva = id;
    
    document.getElementById("es-cliente").value = s.cliente || "";
    document.getElementById("es-descripcion").value = s.descripcion || "";
    document.getElementById("es-tipo").value = s.tipo_soporte || "";
    document.getElementById("es-prioridad").value = s.prioridad || "";
    document.getElementById("modalEditarSolicitud").classList.add("open");
};

window.cerrarModalEditarSolicitud = function() {
    document.getElementById("modalEditarSolicitud").classList.remove("open");
    editandoSolicitudId = null;
};

window.guardarEdicionSolicitud = async function() {
    const cliente = document.getElementById("es-cliente").value.trim();
    const descripcion = document.getElementById("es-descripcion").value.trim();
    const tipo = document.getElementById("es-tipo").value;
    const prioridad = document.getElementById("es-prioridad").value;
    
    if (!cliente || !tipo || !prioridad) {
        showToast("Cliente, tipo y prioridad son obligatorios", "error");
        return;
    }
    
    const res = await apiFetch(`/api/solicitudes/${editandoSolicitudId}`, {
        method: "PUT",
        body: JSON.stringify({ cliente, descripcion, tipo_soporte: tipo, prioridad })
    });
    
    if (res?.ok) {
        showToast("Solicitud actualizada ✓", "success");
        cerrarModalEditarSolicitud();
        await cargarSolicitudes();
    } else {
        showToast("Error al actualizar", "error");
    }
};

// ========== EDITAR ESTADO ==========
window.abrirEditarEstado = function(id, estadoActual) {
    editandoId = id;
    document.getElementById("modal-estado").value = estadoActual;
    document.getElementById("modalEditar").classList.add("open");
};

window.cerrarModal = function() {
    document.getElementById("modalEditar").classList.remove("open");
    editandoId = null;
};

window.guardarEdicionEstado = async function() {
    const estado = document.getElementById("modal-estado").value;
    const res = await apiFetch(`/api/editar_solicitud/${editandoId}`, {
        method: "PUT",
        body: JSON.stringify({ estado })
    });
    
    if (res?.ok) {
        showToast("Estado actualizado ✓", "success");
        cerrarModal();
        await cargarSolicitudes();
    } else {
        showToast("Error al actualizar", "error");
    }
};

// ========== RESOLVER ==========
window.resolver = async function(id) {
    const res = await apiFetch(`/api/resolver/${id}`, {
        method: "PUT",
        body: JSON.stringify({ asignado_a: nombre })
    });
    if (res?.ok) {
        showToast("Solicitud resuelta ✓", "success");
        await cargarSolicitudes();
    } else {
        showToast("Error al resolver", "error");
    }
};

// ========== ASIGNAR ==========
window.asignarme = async function(id) {
    const res = await apiFetch(`/api/asignar/${id}`, {
        method: "PUT",
        body: JSON.stringify({ asignado_a: nombre })
    });
    if (res?.ok) {
        showToast("Solicitud asignada ✓", "success");
        await cargarSolicitudes();
    } else {
        showToast("Error al asignar", "error");
    }
};

window.asignarA = async function(id) {
    asignandoId = id;
    const res = await apiFetch("/api/usuarios");
    if (!res) return;
    const data = await res.json();
    const select = document.getElementById("modal-usuario-asignar");
    select.innerHTML = (data.usuarios || []).map(u => {
        const cat = categoriaLabel[u.categoria] || "Sin categoría";
        return `<option value="${escapeHtml(u.nombre)}">${escapeHtml(u.nombre)} — ${cat}</option>`;
    }).join('');
    document.getElementById("modalAsignar").dataset.modo = "asignar";
    document.getElementById("modalAsignar").classList.add("open");
};

window.reasignarA = async function(id) {
    asignandoId = id;
    const res = await apiFetch("/api/usuarios");
    if (!res) return;
    const data = await res.json();
    const select = document.getElementById("modal-usuario-asignar");
    select.innerHTML = (data.usuarios || []).map(u => {
        const cat = categoriaLabel[u.categoria] || "Sin categoría";
        return `<option value="${escapeHtml(u.nombre)}">${escapeHtml(u.nombre)} — ${cat}</option>`;
    }).join('');
    document.getElementById("modalAsignar").dataset.modo = "reasignar";
    document.getElementById("modalAsignar").classList.add("open");
};

window.cerrarModalAsignar = function() {
    document.getElementById("modalAsignar").classList.remove("open");
    asignandoId = null;
};

window.confirmarAsignar = async function() {
    const usuario = document.getElementById("modal-usuario-asignar").value;
    if (!usuario) return;
    const modo = document.getElementById("modalAsignar").dataset.modo;
    const url = modo === "reasignar" ? `/api/reasignar/${asignandoId}` : `/api/asignar/${asignandoId}`;
    const res = await apiFetch(url, {
        method: "PUT",
        body: JSON.stringify({ asignado_a: usuario })
    });
    if (res?.ok) {
        showToast(`${modo === "reasignar" ? "Reasignado" : "Asignado"} a ${usuario} ✓`, "success");
        cerrarModalAsignar();
        await cargarSolicitudes();
    } else {
        showToast("Error al asignar", "error");
    }
};

// ========== VER DETALLES ==========
window.verDetalles = function(id) {
    const s = solicitudesData.find(s => s.id === id);
    if (!s) {
        showToast("Solicitud no encontrada", "error");
        return;
    }
    
    idSolicitudActiva = id;
    const estadoBadge = s.estado === "en proceso" ? "proceso" : s.estado;
    
    document.getElementById("modal-detalles").innerHTML = `
        <div class="detalle-grid">
            <div class="detalle-item"><span class="detalle-label">ID</span><span class="detalle-valor">#${s.id}</span></div>
            <div class="detalle-item"><span class="detalle-label">Estado</span><span class="badge badge-${estadoBadge}">${s.estado}</span></div>
            <div class="detalle-item"><span class="detalle-label">Cliente</span><span class="detalle-valor">${escapeHtml(s.cliente)}</span></div>
            <div class="detalle-item"><span class="detalle-label">Reportado por</span><span class="detalle-valor">${escapeHtml(s.persona_reporta || "—")}</span></div>
            <div class="detalle-item"><span class="detalle-label">Tipo</span><span class="detalle-valor">${s.tipo_soporte}</span></div>
            <div class="detalle-item"><span class="detalle-label">Prioridad</span><span class="badge badge-${s.prioridad}">${s.prioridad}</span></div>
            <div class="detalle-item"><span class="detalle-label">Fecha</span><span class="detalle-valor">${formatFecha(s.fecha_reporte)}</span></div>
            <div class="detalle-item"><span class="detalle-label">Resuelta</span><span class="detalle-valor">${formatFecha(s.fecha_resuelto)}</span></div>
            ${s.asignado_a ? `<div class="detalle-item full"><span class="detalle-label">Asignado</span><span class="detalle-valor">${escapeHtml(s.asignado_a)}</span></div>` : ""}
            <div class="detalle-item full"><span class="detalle-label">Descripción</span><span class="detalle-valor">${escapeHtml(s.descripcion || "—")}</span></div>
        </div>
    `;
    
    cargarComentarios(id);
    cargarArchivosModal(id);
    document.getElementById("modalDetalles").classList.add("open");
};

window.cerrarModalDetalles = function() {
    document.getElementById("modalDetalles").classList.remove("open");
    idSolicitudActiva = null;
};

// ========== COMENTARIOS ==========
async function cargarComentarios(id) {
    const res = await apiFetch(`/api/solicitudes/${id}/comentarios`);
    if (!res) return;
    const data = await res.json();
    const box = document.getElementById("chatBox");
    if (!box) return;
    
    if (!data.comentarios?.length) {
        box.innerHTML = '<div style="text-align:center; padding:20px;">💬 No hay comentarios aún.</div>';
        return;
    }
    
    box.innerHTML = data.comentarios.map(c => `
        <div class="chat-msg ${c.usuario === nombre ? 'me' : 'other'}">
            <div class="msg-header">
                <span class="msg-user">${escapeHtml(c.usuario)}</span>
                <span class="msg-time">${new Date(c.fecha).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</span>
            </div>
            <div class="msg-body">${escapeHtml(c.mensaje)}</div>
        </div>
    `).join('');
    box.scrollTop = box.scrollHeight;
}

window.enviarComentario = async function() {
    const input = document.getElementById("inputComentario");
    const mensaje = input.value.trim();
    if (!mensaje || !idSolicitudActiva) return;
    
    const res = await apiFetch(`/api/solicitudes/${idSolicitudActiva}/comentarios`, {
        method: "POST",
        body: JSON.stringify({ mensaje })
    });
    if (res?.ok) {
        input.value = "";
        await cargarComentarios(idSolicitudActiva);
    }
};

// ========== ARCHIVOS EN MODAL ==========
function mostrarSubirArchivoModal() {
    const form = document.getElementById("form-subir-archivo-modal");
    if (form) form.style.display = "block";
}

function ocultarSubirArchivoModal() {
    const form = document.getElementById("form-subir-archivo-modal");
    const input = document.getElementById("archivo-input-modal");
    if (form) form.style.display = "none";
    if (input) input.value = "";
}

async function subirArchivoModal() {
    const fileInput = document.getElementById("archivo-input-modal");
    const file = fileInput?.files[0];
    if (!file) {
        showToast("Selecciona un archivo", "error");
        return;
    }
    if (file.size > 16 * 1024 * 1024) {
        showToast("El archivo no puede superar 16MB", "error");
        return;
    }
    
    const formData = new FormData();
    formData.append("archivo", file);
    
    const btn = event.target;
    const originalText = btn.textContent;
    btn.textContent = "Subiendo...";
    btn.disabled = true;
    
    try {
        const res = await fetch(`/api/solicitudes/${idSolicitudActiva}/archivos`, {
            method: "POST",
            headers: { "Authorization": "Bearer " + token },
            body: formData
        });
        const data = await res.json();
        if (res.ok) {
            showToast("Archivo subido ✓", "success");
            ocultarSubirArchivoModal();
            await cargarArchivosModal(idSolicitudActiva);
        } else {
            showToast(data.error || "Error al subir", "error");
        }
    } catch (error) {
        showToast("Error de conexión", "error");
    } finally {
        btn.textContent = originalText;
        btn.disabled = false;
    }
}

async function cargarArchivosModal(idSolicitud) {
    const container = document.getElementById("lista-archivos-modal");
    if (!container) return;
    
    container.innerHTML = '<div style="text-align:center; padding:20px;">⏳ Cargando...</div>';
    
    try {
        const res = await fetch(`/api/solicitudes/${idSolicitud}/archivos`, {
            headers: { "Authorization": "Bearer " + token }
        });
        if (!res.ok) throw new Error();
        
        const data = await res.json();
        if (!data.archivos?.length) {
            container.innerHTML = '<div style="text-align:center; padding:20px;">📎 No hay archivos</div>';
            return;
        }
        
        const esAdmin = tipo === "1";
        container.innerHTML = data.archivos.map(a => `
            <div class="archivo-item" style="display:flex; justify-content:space-between; align-items:center; padding:8px; border-bottom:1px solid var(--border);">
                <div style="display:flex; align-items:center; gap:10px;">
                    <span>${getIconoArchivo(a.tipo)}</span>
                    <div>
                        <div style="font-weight:500;">${escapeHtml(a.nombre_original)}</div>
                        <div style="font-size:0.7rem; color:var(--muted);">${a.tamano || '?'} · ${formatFecha(a.fecha_subida)}</div>
                    </div>
                </div>
                <div style="display:flex; gap:8px;">
                    <button class="btn-action" onclick="descargarArchivoModal(${a.id})">📥 Descargar</button>
                    ${esAdmin ? `<button class="btn-action delete" onclick="eliminarArchivoModal(${a.id})">🗑 Eliminar</button>` : ""}
                </div>
            </div>
        `).join('');
    } catch (error) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">❌ Error al cargar</div>';
    }
}

function getIconoArchivo(tipo) {
    if (!tipo) return "📎";
    if (tipo.includes("image")) return "🖼️";
    if (tipo.includes("pdf")) return "📄";
    if (tipo.includes("word") || tipo.includes("document")) return "📝";
    if (tipo.includes("excel") || tipo.includes("sheet")) return "📊";
    if (tipo.includes("zip") || tipo.includes("compressed")) return "🗜️";
    return "📎";
}

async function descargarArchivoModal(idArchivo) {
    try {
        const res = await fetch(`/api/archivos/${idArchivo}/descargar`, {
            headers: { "Authorization": "Bearer " + token }
        });
        if (!res.ok) {
            const data = await res.json();
            showToast(data.error || "Error", "error");
            return;
        }
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "archivo";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        showToast("Descargando...", "success");
    } catch (error) {
        showToast("Error al descargar", "error");
    }
}

async function eliminarArchivoModal(idArchivo) {
    if (!confirm("¿Eliminar este archivo?")) return;
    const res = await fetch(`/api/archivos/${idArchivo}`, {
        method: "DELETE",
        headers: { "Authorization": "Bearer " + token }
    });
    if (res.ok) {
        showToast("Archivo eliminado ✓", "success");
        await cargarArchivosModal(idSolicitudActiva);
    } else {
        showToast("Error al eliminar", "error");
    }
}

// ========== USUARIOS ==========
async function cargarUsuarios() {
    const lista = document.getElementById("usuariosLista");
    const res = await apiFetch("/api/usuarios");
    if (!res) return;
    const data = await res.json();
    const usuarios = data.usuarios || [];
    
    document.getElementById("usuariosCount").textContent = `${usuarios.length} usuarios`;
    
    if (!usuarios.length) {
        lista.innerHTML = `<div class="reciente-empty">✅ No hay usuarios</div>`;
        return;
    }
    
    lista.innerHTML = usuarios.map(u => {
        const esAdmin = u.tipo === 1 || u.tipo === "1";
        const cat = categoriaLabel[u.categoria] || u.categoria || "Sin categoría";
        return `
            <div class="reciente-item">
                <div class="usuario-avatar">${u.nombre.charAt(0).toUpperCase()}</div>
                <div class="reciente-info">
                    <span class="reciente-cliente">${escapeHtml(u.nombre)}</span>
                    <span class="reciente-meta">@${escapeHtml(u.usuario)} · ID #${u.id} · ${cat}</span>
                </div>
                <div class="reciente-right">
                    <span class="badge ${esAdmin ? "badge-alta" : "badge-proceso"}">${esAdmin ? "Admin" : "Tecnico"}</span>
                    <button class="btn-action" onclick="editarUsuario(${u.id}, '${escapeHtml(u.nombre)}', '${escapeHtml(u.usuario)}', ${u.tipo}, '${u.categoria || ""}')">Editar</button>
                    <button class="btn-action delete" onclick="eliminarUsuario(${u.id})">Eliminar</button>
                </div>
            </div>
        `;
    }).join("");
}

window.editarUsuario = function(id, nombre, usuario, tipo, categoria) {
    document.getElementById("edit-u-id").value = id;
    document.getElementById("edit-u-nombre").value = nombre;
    document.getElementById("edit-u-usuario").value = usuario;
    document.getElementById("edit-u-tipo").value = tipo;
    document.getElementById("edit-u-categoria").value = categoria || "";
    document.getElementById("modalEditarUsuario").classList.add("open");
};

window.cerrarModalUsuario = function() {
    document.getElementById("modalEditarUsuario").classList.remove("open");
};

window.guardarUsuario = async function() {
    const id = document.getElementById("edit-u-id").value;
    const nombre = document.getElementById("edit-u-nombre").value.trim();
    const usuario = document.getElementById("edit-u-usuario").value.trim();
    const tipo = document.getElementById("edit-u-tipo").value;
    const categoria = document.getElementById("edit-u-categoria").value || null;
    
    if (!nombre || !usuario) {
        showToast("Completa todos los campos", "error");
        return;
    }
    
    const res = await apiFetch(`/api/usuarios/${id}`, {
        method: "PUT",
        body: JSON.stringify({ nombre, usuario, tipo, categoria })
    });
    if (res?.ok) {
        showToast("Usuario actualizado ✓", "success");
        cerrarModalUsuario();
        await cargarUsuarios();
    } else {
        showToast("Error al actualizar", "error");
    }
};

window.eliminarUsuario = async function(id) {
    if (!confirm("¿Eliminar este usuario?")) return;
    const res = await apiFetch(`/api/usuarios/${id}`, { method: "DELETE" });
    if (res?.ok) {
        showToast("Usuario eliminado ✓", "success");
        await cargarUsuarios();
    } else {
        showToast("Error al eliminar", "error");
    }
};

window.registrarUsuario = async function() {
    const nombre = document.getElementById("nuevo-nombre").value.trim();
    const usuario = document.getElementById("nuevo-usuario").value.trim();
    const password = document.getElementById("nuevo-password").value;
    const tipo = document.getElementById("nuevo-tipo").value;
    
    if (!nombre || !usuario || !password) {
        showToast("Completa todos los campos", "error");
        return;
    }
    if (password.length < 6) {
        showToast("La contraseña debe tener al menos 6 caracteres", "error");
        return;
    }
    
    const res = await apiFetch("/api/usuarios", {
        method: "POST",
        body: JSON.stringify({ nombre, usuario, password, tipo: parseInt(tipo) })
    });
    if (res?.ok) {
        showToast("Usuario creado ✓", "success");
        document.getElementById("nuevo-nombre").value = "";
        document.getElementById("nuevo-usuario").value = "";
        document.getElementById("nuevo-password").value = "";
        await cargarUsuarios();
    } else {
        const d = await res.json();
        showToast(d.error || "Error al crear", "error");
    }
};

// ========== AUDITORIA ==========
const etiquetas = {
    crear_solicitud: "🟢 Crear solicitud",
    editar_estado: "🔵 Editar estado",
    asignar: "🟡 Asignar",
    resolver: "✅ Resolver",
    eliminar: "🔴 Eliminar solicitud",
    crear_usuario: "🟢 Crear usuario",
    eliminar_usuario: "🔴 Eliminar usuario",
};

async function cargarAuditoria() {
    const lista = document.getElementById("auditoriaLista");
    const res = await apiFetch("/api/auditoria");
    if (!res) return;
    const data = await res.json();
    const registros = data.registros || [];
    
    document.getElementById("auditoriaCount").textContent = `${registros.length} registros`;
    
    if (!registros.length) {
        lista.innerHTML = `<div class="reciente-empty">📭 Sin registros de auditoría</div>`;
        return;
    }
    
    lista.innerHTML = registros.map(r => `
        <div class="reciente-item">
            <div class="reciente-info">
                <span class="reciente-cliente">${etiquetas[r.accion] || r.accion} — Solicitud #${r.id_solicitud || "—"}</span>
                <span class="reciente-meta">${r.detalle || ""}</span>
            </div>
            <div class="reciente-right">
                <span style="color:var(--muted);">${escapeHtml(r.usuario)}</span>
                <span style="color:var(--muted);">${formatFecha(r.fecha)}</span>
            </div>
        </div>
    `).join("");
}

// ========== FILTROS ==========
let filtroEstadoActual = "todos";
let filtroPrioridadActual = "todos";
let filtroTipoActual = "todos";

window.filtrarTabla = function() { aplicarFiltros(); };
window.limpiarFechas = function() {
    document.getElementById("filtroDesde").value = "";
    document.getElementById("filtroHasta").value = "";
    aplicarFiltros();
};

function aplicarFiltros() {
    const q = document.getElementById("searchInput").value.toLowerCase();
    const desde = document.getElementById("filtroDesde").value;
    const hasta = document.getElementById("filtroHasta").value;
    let filtrado = [...solicitudesData];
    
    if (filtroEstadoActual !== "todos") filtrado = filtrado.filter(s => s.estado === filtroEstadoActual);
    if (filtroPrioridadActual !== "todos") filtrado = filtrado.filter(s => s.prioridad === filtroPrioridadActual);
    if (filtroTipoActual !== "todos") filtrado = filtrado.filter(s => s.tipo_soporte === filtroTipoActual);
    if (desde) filtrado = filtrado.filter(s => s.fecha_reporte && new Date(s.fecha_reporte) >= new Date(desde));
    if (hasta) {
        const hastaFin = new Date(hasta);
        hastaFin.setDate(hastaFin.getDate() + 1);
        filtrado = filtrado.filter(s => s.fecha_reporte && new Date(s.fecha_reporte) < hastaFin);
    }
    if (q) filtrado = filtrado.filter(s => s.cliente.toLowerCase().includes(q) || (s.persona_reporta || "").toLowerCase().includes(q));
    
    renderTabla(filtrado);
}

window.toggleDropdown = function() {
    document.getElementById("filtroOptions").classList.toggle("open");
    document.getElementById("filtroOptionsPrioridad").classList.remove("open");
    document.getElementById("tipoOptions").classList.remove("open");
};

window.seleccionarFiltro = function(valor, label) {
    document.getElementById("filtroLabel").textContent = label;
    document.getElementById("filtroOptions").classList.remove("open");
    filtroEstadoActual = valor;
    aplicarFiltros();
};

window.toggleDropdownPrioridad = function() {
    document.getElementById("filtroOptionsPrioridad").classList.toggle("open");
    document.getElementById("filtroOptions").classList.remove("open");
    document.getElementById("tipoOptions").classList.remove("open");
};

window.seleccionarFiltroPrioridad = function(valor, label) {
    document.getElementById("filtroLabelPrioridad").textContent = label;
    document.getElementById("filtroOptionsPrioridad").classList.remove("open");
    filtroPrioridadActual = valor;
    aplicarFiltros();
};

window.toggleDropdownTipo = function() {
    document.getElementById("tipoOptions").classList.toggle("open");
    document.getElementById("filtroOptions").classList.remove("open");
    document.getElementById("filtroOptionsPrioridad").classList.remove("open");
};

window.seleccionarFiltroTipo = function(valor, label) {
    document.getElementById("tipoLabel").textContent = label;
    document.getElementById("tipoOptions").classList.remove("open");
    filtroTipoActual = valor;
    aplicarFiltros();
};

document.addEventListener("click", function(e) {
    if (!e.target.closest(".custom-select")) {
        document.getElementById("filtroOptions")?.classList.remove("open");
        document.getElementById("filtroOptionsPrioridad")?.classList.remove("open");
        document.getElementById("tipoOptions")?.classList.remove("open");
    }
});

// ========== DROPDOWN ACCIONES ==========
window.toggleActionMenu = function(event, id) {
    event.stopPropagation();
    document.querySelectorAll(".dropdown-actions.show").forEach(menu => {
        if (menu.id !== `menu-${id}`) menu.classList.remove("show");
    });
    document.getElementById(`menu-${id}`).classList.toggle("show");
};

window.addEventListener("click", function(e) {
    if (!e.target.closest(".btn-dots")) {
        document.querySelectorAll(".dropdown-actions").forEach(menu => menu.classList.remove("show"));
    }
});

// ========== NOTIFICACIONES ==========
if ("Notification" in window && Notification.permission === "default") {
    Notification.requestPermission();
}
// ========== NOTIFICACIONES CON BACKOFF EXPONENCIAL ==========
let intentosFallidos = 0;
let intervaloNotificaciones = null;
let tiempoBase = 60000; // 60 segundos base

if ("Notification" in window && Notification.permission === "default") {
    Notification.requestPermission();
}

async function cargarNotificacionesConBackoff() {
    try {
        const res = await apiFetch("/api/notificaciones");
        
        if (!res) return;
        
        if (res.status === 429) {
            intentosFallidos++;
            const tiempoEspera = Math.min(300000, tiempoBase * Math.pow(1.5, intentosFallidos));
            console.log(`⚠️ Rate limit (429), próximo intento en ${Math.round(tiempoEspera/1000)}s`);
            
            if (intervaloNotificaciones) clearInterval(intervaloNotificaciones);
            intervaloNotificaciones = setInterval(cargarNotificacionesConBackoff, tiempoEspera);
            return;
        }
        
        // Éxito - resetear contador
        if (intentosFallidos > 0) {
            console.log("✅ Conexión recuperada");
            intentosFallidos = 0;
            if (intervaloNotificaciones) clearInterval(intervaloNotificaciones);
            intervaloNotificaciones = setInterval(cargarNotificacionesConBackoff, tiempoBase);
        }
        
        if (!res.ok) {
            console.log("❌ Error cargando notificaciones:", res.status);
            return;
        }
        
        const data = await res.json();
        const notifs = data.notificaciones || [];
        
        const noLeidas = notifs.filter(n => !n.leida).length;
        actualizarBadge(noLeidas);
        renderNotifPanel(notifs);
        
    } catch (e) {
        console.error("❌ Error en cargarNotificaciones:", e);
        intentosFallidos++;
    }
}

// Iniciar notificaciones (reemplazar las líneas antiguas)
function iniciarNotificaciones() {
    if (intervaloNotificaciones) clearInterval(intervaloNotificaciones);
    intervaloNotificaciones = setInterval(cargarNotificacionesConBackoff, tiempoBase);
    cargarNotificacionesConBackoff();
}

// Reemplazar la inicialización antigua
// cargarNotificaciones();  // Comentar o eliminar
// setInterval(cargarNotificaciones, 30000); // Comentar o eliminar

// Usar el nuevo sistema
iniciarNotificaciones();

window.limpiarNotificaciones = async function() {
    try {
        const res = await apiFetch("/api/notificaciones/limpiar", { method: "DELETE" });
        if (!res) return;
        
        if (res.ok) {
            const notifLista = document.getElementById("notifLista");
            if (notifLista) {
                notifLista.innerHTML = '<div class="notif-empty">Sin notificaciones nuevas</div>';
            }
            actualizarBadge(0);
            showToast("Notificaciones limpiadas ✓", "success");
        } else {
            const data = await res.json();
            showToast(data?.error || "Error al limpiar", "error");
        }
    } catch (error) {
        console.error("Error limpiando notificaciones:", error);
        showToast("Error de conexión", "error");
    }
};

window.toggleNotifPanel = function() {
    notifPanelAbierto = !notifPanelAbierto;
    const panel = document.getElementById("notifPanel");
    if (panel) panel.classList.toggle("open", notifPanelAbierto);
    if (notifPanelAbierto) {
        actualizarBadge(0);
        apiFetch("/api/notificaciones/marcar-leidas", { method: "PUT" });
    }
};

function cerrarNotifPanel() {
    notifPanelAbierto = false;
    const panel = document.getElementById("notifPanel");
    if (panel) panel.classList.remove("open");
}

function actualizarBadge(cantidad) {
    const badge = document.getElementById("notifBadge");
    const btn = document.getElementById("notifBtn");
    if (cantidad > 0) {
        badge.textContent = cantidad > 99 ? "99+" : cantidad;
        badge.style.display = "flex";
        btn?.classList.add("has-notif");
    } else {
        badge.style.display = "none";
        btn?.classList.remove("has-notif");
    }
}

function renderNotifPanel(notifs) {
    const lista = document.getElementById("notifLista");
    if (!lista) return;
    
    if (!notifs?.length) {
        lista.innerHTML = `<div class="notif-empty">Sin notificaciones nuevas</div>`;
        return;
    }
    
    lista.innerHTML = notifs.map(n => `
        <div class="notif-item ${n.leida ? "" : "no-leida"}" onclick="irASolicitud(${n.id_solicitud})">
            <div class="notif-dot ${n.leida ? "" : "asignada"}"></div>
            <div class="notif-item-body">
                <div class="notif-item-titulo">${escapeHtml(n.mensaje)}</div>
                <div class="notif-item-meta">${formatFecha(n.fecha)}</div>
            </div>
        </div>
    `).join("");
}

function irASolicitud(id) {
    cerrarNotifPanel();
    const linkSolicitudes = document.querySelector(".sidenav-link");
    if (linkSolicitudes) switchSection("solicitudes", linkSolicitudes);
    cargarSolicitudes().then(() => {
        setTimeout(() => {
            document.querySelectorAll("#tablaSolicitudes tr").forEach(tr => {
                if (tr.textContent.includes(`#${id}`)) {
                    tr.style.transition = "background 0.4s";
                    tr.style.background = "rgba(124,106,247,0.15)";
                    tr.scrollIntoView({ behavior: "smooth", block: "center" });
                    setTimeout(() => tr.style.background = "", 2500);
                }
            });
        }, 400);
    });
}

document.addEventListener("click", function(e) {
    if (notifPanelAbierto && !e.target.closest("#notifWrapper")) {
        cerrarNotifPanel();
    }
});

// ========== LOGOUT ==========
window.logout = function() {
    localStorage.clear();
    window.location.href = "/login";
};

// ========== EVENTOS MODALES ==========
document.getElementById("modalEditar")?.addEventListener("click", function(e) {
    if (e.target === this) cerrarModal();
});
document.getElementById("modalDetalles")?.addEventListener("click", function(e) {
    if (e.target === this) cerrarModalDetalles();
});
document.getElementById("modalAsignar")?.addEventListener("click", function(e) {
    if (e.target === this) cerrarModalAsignar();
});

// ========== INICIALIZACIÓN ==========
cargarSolicitudes();
cargarNotificacionesConBackoff();
setInterval(cargarNotificacionesConBackoff, 30000); // Cambiado a 30 segundos

if (tipo !== "1") {
    document.querySelectorAll("th").forEach(th => {
        if (th.textContent.trim() === "Asignado a") th.style.display = "none";
    });
}