from flask import request, jsonify
from flask_jwt_extended import jwt_required, get_jwt
from services.solicitud_service import SolicitudService
from utils.helpers import serializar_lista
from utils.decorators import admin_required

def init_solicitud_routes(app):
    
    @app.route("/api/solicitudes", methods=["GET"])
    @jwt_required()
    def obtener_solicitudes():
        claims = get_jwt()
        es_admin = int(claims.get("tipo", 0)) == 1
        nombre = claims.get("nombre")
        
        solicitudes = SolicitudService.obtener_todas(nombre, es_admin)
        return jsonify({"registros": serializar_lista(solicitudes)}), 200
    
    @app.route("/api/solicitudes", methods=["POST"])
    @jwt_required()
    def agregar_solicitud():
        claims = get_jwt()
        data = request.get_json(force=True)
        
        nueva_id, asignado = SolicitudService.crear(data, claims.get("nombre"))
        
        return jsonify({
            "message": "Solicitud creada exitosamente",
            "id": nueva_id,
            "asignado_a": asignado
        }), 201
    
    @app.route("/api/solicitudes/<int:id_solicitud>", methods=["PUT"])
    @jwt_required()
    def editar_solicitud(id_solicitud):
        claims = get_jwt()
        data = request.get_json(force=True)
        
        success = SolicitudService.actualizar(id_solicitud, data, claims.get("nombre"))
        
        if success:
            return jsonify({"message": "Solicitud actualizada correctamente"}), 200
        
        solicitud = SolicitudService.obtener_por_id(id_solicitud)
        if not solicitud:
            return jsonify({"error": "Solicitud no encontrada"}), 404
        if solicitud['estado'] == 'resuelto':
            return jsonify({"error": "No se puede editar una solicitud resuelta"}), 400
        
        return jsonify({"error": "No autorizado"}), 403
    
    @app.route("/api/solicitudes/<int:id_solicitud>", methods=["DELETE"])
    @jwt_required()
    @admin_required
    def eliminar_solicitud(id_solicitud):
        claims = get_jwt()
        
        if SolicitudService.eliminar(id_solicitud, claims.get("nombre")):
            return jsonify({"message": "Solicitud eliminada exitosamente"}), 200
        
        return jsonify({"error": "Solicitud no encontrada"}), 404
    
    @app.route("/api/editar_solicitud/<int:id_solicitud>", methods=["PUT"])
    @jwt_required()
    def editar_estado(id_solicitud):
        claims = get_jwt()
        data = request.get_json(force=True)
        estado = data.get("estado")
        
        if SolicitudService.actualizar_estado(id_solicitud, estado, claims.get("nombre")):
            return jsonify({"message": "Estado actualizado exitosamente"}), 200
        
        return jsonify({"error": "Solicitud no encontrada"}), 404
    
    @app.route("/api/resolver/<int:id_solicitud>", methods=["PUT"])
    @jwt_required()
    def resolver_solicitud(id_solicitud):
        claims = get_jwt()
        data = request.get_json(force=True)
        asignado_a = data.get("asignado_a")
        
        if not asignado_a:
            return jsonify({"error": "El campo 'asignado_a' es obligatorio"}), 400
        
        if SolicitudService.resolver(id_solicitud, asignado_a, claims.get("nombre")):
            return jsonify({"message": "Solicitud resuelta exitosamente"}), 200
        
        return jsonify({"error": "Solicitud no encontrada"}), 404
    
    @app.route("/api/asignar/<int:id>", methods=["PUT"])
    @jwt_required()
    def asignar_solicitud(id):
        claims = get_jwt()
        data = request.get_json()
        asignado_a = data.get("asignado_a")
        
        if not asignado_a:
            return jsonify({"error": "Falta el campo asignado_a"}), 400
        
        es_admin = int(claims.get("tipo", 0)) == 1
        success, message = SolicitudService.asignar(id, asignado_a, claims.get("nombre"), es_admin)
        
        if success:
            return jsonify({"message": message}), 200
        return jsonify({"error": message}), 400 if "no encontrada" in message else 409
    
    @app.route("/api/reasignar/<int:id>", methods=["PUT"])
    @jwt_required()
    @admin_required
    def reasignar_solicitud(id):
        claims = get_jwt()
        data = request.get_json()
        nuevo_asignado = data.get("asignado_a")
        
        if not nuevo_asignado:
            return jsonify({"error": "Falta el campo asignado_a"}), 400
        
        success, message = SolicitudService.reasignar(id, nuevo_asignado, claims.get("nombre"))
        
        if success:
            return jsonify({"message": message}), 200
        return jsonify({"error": message}), 404