from flask import jsonify
from flask_jwt_extended import jwt_required, get_jwt
from services.notificacion_service import NotificacionService
from utils.helpers import serializar_lista

def init_notificacion_routes(app):
    
    @app.route("/api/notificaciones", methods=["GET"])
    @jwt_required()
    def obtener_notificaciones():
        claims = get_jwt()
        notificaciones = NotificacionService.obtener_por_usuario(claims.get("nombre"))
        return jsonify({"notificaciones": serializar_lista(notificaciones)}), 200
    
    @app.route("/api/notificaciones/no-leidas", methods=["GET"])
    @jwt_required()
    def contar_no_leidas():
        claims = get_jwt()
        total = NotificacionService.contar_no_leidas(claims.get("nombre"))
        return jsonify({"total": total}), 200
    
    @app.route("/api/notificaciones/marcar-leidas", methods=["PUT"])
    @jwt_required()
    def marcar_leidas():
        claims = get_jwt()
        NotificacionService.marcar_todas_como_leidas(claims.get("nombre"))
        return jsonify({"message": "Marcadas como leídas"}), 200
    
    @app.route("/api/notificaciones/limpiar", methods=["DELETE"])
    @jwt_required()
    def limpiar_notificaciones():
        claims = get_jwt()
        NotificacionService.limpiar_todas(claims.get("nombre"))
        return jsonify({"message": "Notificaciones eliminadas"}), 200