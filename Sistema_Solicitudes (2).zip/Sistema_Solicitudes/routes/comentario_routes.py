from flask import request, jsonify
from flask_jwt_extended import jwt_required, get_jwt
from services.comentario_service import ComentarioService
from utils.helpers import serializar_lista

def init_comentario_routes(app):
    
    @app.route("/api/solicitudes/<int:id>/comentarios", methods=["GET"])
    def obtener_comentarios(id):
        comentarios = ComentarioService.obtener_por_solicitud(id)
        return jsonify({"comentarios": serializar_lista(comentarios)}), 200
    
    @app.route("/api/solicitudes/<int:id>/comentarios", methods=["POST"])
    @jwt_required()
    def agregar_comentario(id):
        claims = get_jwt()
        data = request.get_json()
        mensaje = data.get("mensaje")
        
        if not mensaje:
            return jsonify({"error": "El mensaje es obligatorio"}), 400
        
        ComentarioService.crear(id, claims.get("nombre"), mensaje)
        return jsonify({"message": "Comentario agregado"}), 201