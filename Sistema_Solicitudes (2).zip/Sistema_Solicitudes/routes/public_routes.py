# routes/public_routes.py
import os
from flask import render_template, request, jsonify, send_file
from config.database import get_db
from config.settings import config
from services.solicitud_service import SolicitudService
from utils.helpers import serializar_lista
import requests

env = os.environ.get("FLASK_ENV", "development")
cfg = config[env]

def init_public_routes(app):
    
    @app.route("/")
    def index():
        return render_template("index.html")
    
    @app.route("/login")
    def login_page():
        return render_template("login.html", recaptcha_site_key=cfg.RECAPTCHA_SITE_KEY or "")
    
    @app.route("/dashboard")
    def dashboard_page():
        return render_template("index.html")
    
    @app.route("/nueva-solicitud")
    def solicitud_page():
        return render_template("nueva_solicitud.html", recaptcha_site_key=cfg.RECAPTCHA_SITE_KEY or "")
    
    @app.route("/seguimiento")
    def seguimiento_page():
        return render_template("seguimiento.html")
    
    @app.route("/api/solicitud-publica", methods=["POST"])
    def crear_solicitud_publica():
        try:
            data = request.get_json(force=True)
            
            # Verificar reCAPTCHA v2 si está configurado
            if cfg.RECAPTCHA_SECRET_KEY and cfg.RECAPTCHA_SECRET_KEY != "None":
                recaptcha_token = data.get("recaptcha_token")
                if not recaptcha_token:
                    return jsonify({"error": "Verificación de seguridad requerida"}), 400
                
                url = "https://www.google.com/recaptcha/api/siteverify"
                payload = {
                    'secret': cfg.RECAPTCHA_SECRET_KEY,
                    'response': recaptcha_token
                }
                response = requests.post(url, data=payload, timeout=5)
                result = response.json()
                
                if not result.get('success', False):
                    return jsonify({"error": "Verificación de seguridad fallida"}), 400
            
            cliente = data.get("cliente")
            persona_reporta = data.get("persona_reporta")
            tipo_soporte = data.get("tipo_soporte")
            descripcion = data.get("descripcion")
            prioridad = data.get("prioridad")

            if not cliente or not tipo_soporte or not prioridad:
                return jsonify({"error": "Completa todos los campos obligatorios"}), 400

            solicitud_data = {
                'cliente': cliente,
                'persona_reporta': persona_reporta,
                'tipo_soporte': tipo_soporte,
                'descripcion': descripcion,
                'prioridad': prioridad,
                'estado': 'pendiente'
            }
            
            nueva_id, asignado = SolicitudService.crear(solicitud_data, persona_reporta or "Público")
            
            # IMPORTANTE: Devolver el ID para que el frontend pueda subir archivos
            return jsonify({
                "message": "Solicitud enviada exitosamente",
                "id": nueva_id
            }), 201

        except Exception as e:
            print("Error en crear_solicitud_publica:", e)
            return jsonify({"error": str(e)}), 500
    
    @app.route("/api/buscar-solicitudes", methods=["GET"])
    def buscar_solicitudes_publicas():
        try:
            from models.solicitud import Solicitud
            
            nombre = request.args.get("nombre", "").strip()
            solicitud_id = request.args.get("id", "").strip()
            
            if solicitud_id and solicitud_id.isdigit():
                solicitud = Solicitud.get_by_id(int(solicitud_id))
                resultados = [solicitud] if solicitud else []
            elif nombre:
                db = get_db()
                cursor = db.cursor()
                cursor.execute(
                    "SELECT * FROM solicitudes WHERE LOWER(persona_reporta) LIKE %s ORDER BY fecha_reporte DESC LIMIT 20",
                    (f"%{nombre.lower()}%",)
                )
                resultados = cursor.fetchall()
                cursor.close()
            else:
                resultados = []
            
            return jsonify({"solicitudes": serializar_lista(resultados)}), 200
            
        except Exception as e:
            print("Error en buscar_solicitudes:", e)
            return jsonify({"error": str(e)}), 500
    
# routes/public_routes.py - Agregar estos endpoints dentro de init_public_routes(app)

    @app.route("/api/public/archivos/<int:id_solicitud>", methods=["POST"])
    def subir_archivo_publico(id_solicitud):
        """Endpoint público para subir archivos a una solicitud"""
        try:
            from services.archivo_service import ArchivoService
            
            print(f"📨 [DEBUG] Subiendo archivo para solicitud: {id_solicitud}")
            print(f"📨 [DEBUG] Files: {request.files}")
            
            if 'archivo' not in request.files:
                return jsonify({"error": "No se encontró el archivo"}), 400
            
            file = request.files['archivo']
            nombre_usuario = request.form.get('usuario', 'Público')
            
            print(f"📄 [DEBUG] Archivo: {file.filename}, Usuario: {nombre_usuario}")
            
            success, message = ArchivoService.guardar_archivo_publico(file, id_solicitud, nombre_usuario)
            
            if success:
                return jsonify({"message": message, "id_solicitud": id_solicitud}), 201
            return jsonify({"error": message}), 400
            
        except Exception as e:
            print(f"❌ Error subiendo archivo público: {e}")
            import traceback
            traceback.print_exc()
            return jsonify({"error": str(e)}), 500

    @app.route("/api/public/solicitudes/<int:id_solicitud>/archivos", methods=["GET"])
    def obtener_archivos_publicos(id_solicitud):
        """Endpoint público para obtener archivos de una solicitud"""
        try:
            from models.archivo import Archivo
            from services.archivo_service import ArchivoService
            
            print(f"📋 [DEBUG] Obteniendo archivos para solicitud: {id_solicitud}")
            
            archivos = Archivo.get_by_solicitud(id_solicitud)
            
            resultado = []
            for a in archivos:
                resultado.append({
                    'id': a['id'],
                    'nombre_original': a['nombre_original'],
                    'tipo': a['tipo_mime'],
                    'tamano': ArchivoService.formatear_tamano(a['tamano']),
                    'fecha_subida': a['fecha_subida'].isoformat(),
                    'usuario': a.get('usuario_subio', 'Desconocido')
                })
            
            return jsonify({"archivos": resultado}), 200
            
        except Exception as e:
            print(f"❌ Error obteniendo archivos públicos: {e}")
            return jsonify({"error": str(e)}), 500

    @app.route("/api/public/archivos/<int:id_archivo>/descargar", methods=["GET"])
    def descargar_archivo_publico(id_archivo):
        """Endpoint público para descargar un archivo"""
        try:
            from models.archivo import Archivo
            from flask import send_file
            
            archivo = Archivo.get_by_id(id_archivo)
            if not archivo:
                return jsonify({"error": "Archivo no encontrado"}), 404
            
            ruta_fisica = os.path.join(cfg.UPLOAD_FOLDER, archivo['nombre_archivo'])
            
            if not os.path.exists(ruta_fisica):
                return jsonify({"error": "Archivo no encontrado en el servidor"}), 404
            
            return send_file(
                ruta_fisica,
                as_attachment=True,
                download_name=archivo['nombre_original'],
                mimetype=archivo['tipo_mime']
            )
            
        except Exception as e:
            print(f"❌ Error descargando archivo público: {e}")
            return jsonify({"error": str(e)}), 500